# Artwork SDK Linux alpha.2

This prerelease candidate gives an artist and coding Agent the same guide and
single-Work example as the macOS alpha.2 distribution. It uses the published
`artwork-linux-alpha.1` package archives and bootstrap consumer lock.

Start with the [artist guide](GUIDE.md) or [install the example](INSTALL.md).
One synthetic Work preserves the exact offered SVG, an attributed contribution
and Receipt, an optional stated intention, a later reflection, and the app's
derived SVG. The evidence account shows permitted material and denial of an
unselected reflection.

| Component | Exact version |
| --- | --- |
| Artwork SDK | `@agent-art/artwork-sdk@0.0.0-planned-transfer.2` |
| Evidence-account module | `@agent-art/participation-account@0.0.0-account-linux.1` |
| Intended runtime | Ubuntu 24.04.5 arm64, guest-local ext4, Node 22.23.4, SQLite 3.53.4, npm 10.9.9 |

The example uses the existing recording and inspection APIs and makes scripted
contributions. Audiences interpret what the attributed statement means. The
Linux qualification of these exact bundle bytes is pending. Live participation,
Signatures adoption, recovery and two-Work reuse have separate scopes.
