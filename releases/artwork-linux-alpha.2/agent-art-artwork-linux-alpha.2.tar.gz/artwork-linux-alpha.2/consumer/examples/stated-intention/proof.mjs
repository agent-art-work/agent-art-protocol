import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { test } from 'node:test';
import { LIMITS, TYPES, payloadReference, recordReference } from '@agent-art/artwork-sdk';
import { ParticipationOwner } from '@agent-art/artwork-sdk/owner';
import { collectSelectedSnapshot, PLAN_SCHEMA, PERMISSION_SCHEMA } from '@agent-art/participation-account/collect';
import { createLocalInspectionSource, SCOPE_SCHEMA } from '@agent-art/participation-account/local-inspection';

const json = JSON.stringify;
const ref = record => recordReference(json(record));
const known = value => ({ state: 'known', value });
const carrier = (value, type) => ({ ref: payloadReference(value, type), encoding: 'utf8', value });
const scope = 'urn:fixture:signatures-stated-intention';
const artist = `${scope}:artist`;
const principal = `${scope}:curator`;
const receiver = `${scope}:receiver`;
const epoch = Date.parse('2026-11-19T00:00:00.000Z');
const at = offset => new Date(epoch + offset).toISOString();
const expires = at(3_600_000);
const svg = paths => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">${paths}</svg>\n`;
const handleShape = '<path d="M8 4v24m0-12h16m0-12v24" fill="none" stroke="#222"/>';
const accentShape = '<path d="M8 29h16" fill="none" stroke="#526477"/>';
const baseline = carrier(svg(handleShape), 'image/svg+xml');
const output = carrier(svg(handleShape + accentShape), 'image/svg+xml');
const invitation = carrier('Choose an accent for the offered mark. You may state what you are trying to do.', 'text/plain');
const reflectionInvitation = carrier('Anything you would like to say now about your earlier accent choice?', 'text/plain');
const firstStatement = 'I wanted the underline to feel like a loose thread.';
const laterStatement = 'Looking back, the line makes the mark feel anchored.';
const definition = carrier('Synthetic handle glyph. The artist rule adds the selected accent to the exact offered glyph.', 'text/plain');
const rule = name => ({ id: `${scope}:rule:${name}`, revision: 'v1', definition: definition.ref });

test('selected evidence follows the offered mark, contribution, statements and derived result', async () => {
  const scratch = mkdtempSync(join(process.cwd(), '.stated-intention-'));
  let now = 1, workRef, owner;
  const clock = () => at(now);
  const record = (type, id, body) => ({
    schema: 'aap.record.draft1', type, identity: { namespace: scope, id, revision: 'v1' },
    ...(!['work', 'binding'].includes(type) ? { scope: { work: workRef } } : {}),
    issuer: artist, issuedAt: clock(),
    provenance: { mode: 'declaration', source: known(artist), material: [], coverage: [], gaps: ['synthetic-fixture'] },
    body,
  });
  const capabilities = ['record', 'exchange', 'inspect'];
  const mapping = rule('expression');
  const policy = rule('authority');
  const disclosure = rule('disclosure');
  const work = record('work', 'work', { framing: [definition.ref], actMappings: [mapping], appRules: [rule('derive')],
    policies: { authority: policy, retention: rule('retention'), disclosure }, capabilities });
  workRef = ref(work);
  const agent = record('participant', 'agent', { party: `${scope}:agent`, kind: 'agent', roles: ['participant'],
    controllers: known([principal]), description: [] });
  const binding = record('binding', 'binding', {
    serialization: 'aap-json-jcs-draft1', capabilities, recordTypes: [...TYPES], encodings: ['utf8'], extensions: [],
    limits: structuredClone(LIMITS), authorization: policy,
    ...Object.fromEntries(['transport', 'authentication', 'persistence', 'recovery', 'retention', 'inspection'].map(key => [key, rule(key)])),
  });
  const setup = { work, binding, owner: artist, receiver, mappingRules: [mapping], relationRules: [], bootstrapUntil: expires,
    policy: { writeMs: 300000, recordsMs: 3600000, dataMs: 3600000, recoveryMs: 604800000, maxActive: 4, maxEntries: 20 } };
  const manifestFor = (id, records, carriers) => record('manifest', id, {
    records: records.map(ref), data: carriers.map(item => item.ref), coverage: [], omissions: [], availability: [], policy: disclosure,
  });
  const offer = subject => ({ mode: 'exact', subject });
  const publishContext = (id, offered, additionalRecords, additionalCarriers) => {
    const context = record('context', id, { offered: offered.map(offer), conditions: [], gaps: ['synthetic-fixture'] });
    const records = [work, agent, context, ...additionalRecords];
    const carriers = [definition, ...additionalCarriers];
    owner.publishContext(json({ package: { work: workRef, context: ref(context),
      manifest: manifestFor(`${id}-manifest`, records, carriers), records, carriers }, readers: [principal], until: expires }));
    return context;
  };

  try {
    owner = ParticipationOwner.initialize({ directory: join(scratch, 'work'), setupJson: json(setup), clock });
    owner.enroll(json({ principal, participant: agent, terms: rule('fixture-enrollment'), notAfter: expires }));
    const auth = who => json({ verified: true, principal: who, notAfter: expires });
    const session = owner.bind(() => auth(principal));
    const submit = (id, context, item) => {
      const { returnHandle, reservation } = session.prepare(json({ context: ref(context), prepareId: id })).value;
      const receipt = session.submit(returnHandle, json({ form: 'material', mediaType: item.ref.mediaType, text: item.value }),
        json(reservation)).value.receipt.value;
      const act = owner.inspectRecord(json(receipt.body.recorded[0])).record;
      assert.equal(receipt.body.outcome, 'committed');
      assert.deepEqual(receipt.body.retained, [item.ref]);
      assert.deepEqual(act.body.contributor, ref(agent));
      assert.deepEqual(act.body.basis, known([ref(context)]));
      assert.deepEqual(owner.inspectData(json(item.ref)).original, Buffer.from(item.value));
      return { act, receipt };
    };

    const offered = publishContext('offered-mark', [baseline.ref, invitation.ref], [], [baseline, invitation]);
    const packet = session.readContext().value;
    assert.deepEqual(packet.carriers.find(item => item.ref.mediaType === 'image/svg+xml'), baseline);
    assert.deepEqual(packet.records.find(item => item.type === 'context').body.offered, [offer(baseline.ref), offer(invitation.ref)]);

    now = 10;
    const input = carrier(json({ accent: 'underline', statedIntention: firstStatement }), 'application/json');
    const contribution = submit('contribution', offered, input);
    const withoutStatement = carrier(json({ accent: 'none' }), 'application/json');
    const optionalControl = submit('without-statement', offered, withoutStatement);
    assert.ok(!Object.hasOwn(JSON.parse(withoutStatement.value), 'statedIntention'));
    assert.notDeepEqual(ref(optionalControl.act), ref(contribution.act));

    now = 20;
    const source = packet.carriers.find(item => item.ref.mediaType === 'image/svg+xml');
    // The artist's fixture renderer uses the selected accent and the offered glyph.
    const render = material => JSON.parse(material.value).accent === 'underline'
      ? source.value.replace('</svg>', accentShape + '</svg>') : source.value;
    assert.equal(render(input), output.value);
    assert.equal(render(withoutStatement), baseline.value);
    assert.notDeepEqual(baseline.ref, output.ref);
    const derivation = record('report', 'derived-mark', { category: 'transformation',
      subjects: [ref(contribution.act), baseline.ref, input.ref], actor: known(artist), rule: known(rule('derive')),
      outcome: 'derived', outputs: [output.ref], basis: [ref(offered), ref(contribution.act)], supersedes: [] });
    owner.appendAppReport(json(derivation), expires);

    now = 30;
    const reflect = publishContext('reflection-offer', [ref(contribution.act), output.ref, reflectionInvitation.ref],
      [contribution.act], [input, output, reflectionInvitation]);
    now = 40;
    const reflection = carrier(laterStatement, 'text/plain');
    const later = submit('reflection', reflect, reflection);
    const about = record('relation', 'reflection-about-contribution', { vocabulary: rule('statement-about'),
      members: [{ role: 'statement', subject: ref(later.act) }, { role: 'contribution', subject: ref(contribution.act) }],
      agreement: known([]) });
    publishContext('continue-work', [ref(about), ref(later.act), ref(contribution.act)],
      [about, later.act, contribution.act], [reflection, input]);
    assert.ok(later.act.issuedAt > contribution.act.issuedAt);
    assert.equal(about.issuer, artist);

    const sharedRecords = [work, agent, offered, contribution.act, contribution.receipt, derivation];
    const sharedCarriers = [definition, baseline, invitation, input, output];
    const select = (id, records, carriers) => {
      const manifest = manifestFor(id, records, carriers);
      owner.publishInspection(json({ selection: id, manifest, readers: [principal], until: at(60000) }));
      return ref(manifest);
    };
    const limited = select('contribution-selection', sharedRecords, sharedCarriers);
    const expanded = select('reflection-selection', [...sharedRecords, reflect, later.act, later.receipt, about],
      [...sharedCarriers, reflectionInvitation, reflection]);
    const inspect = (selection, manifest) => collectSelectedSnapshot(json({ schema: PLAN_SCHEMA,
      source: 'inspection', work: workRef, selection, manifest, recipient: `${scope}:audience`, deadline: at(60000), omissions: [],
    }), { clock, signal: new AbortController().signal, source: createLocalInspectionSource({
      scopeJson: json({ schema: SCOPE_SCHEMA, work: workRef, selection, manifest }), inspect: raw => session.inspect(raw),
    }), gate: () => json({ schema: PERMISSION_SCHEMA, state: 'allow', principal, source: artist, notAfter: at(60000) }) });

    const restricted = await inspect('contribution-selection', limited);
    assert.equal(restricted.state, 'collected');
    assert.ok(!restricted.result.account.records.some(item => item.identity.id === later.act.identity.id));
    assert.ok(!restricted.result.account.carriers.some(item => item.value === laterStatement));
    assert.throws(() => session.inspect(json({ selection: 'contribution-selection', data: reflection.ref })),
      { code: 'inspection_denied' });
    const selected = await inspect('reflection-selection', expanded);
    assert.equal(selected.state, 'collected');
    const { account, projection } = selected.result;
    const selectedCarrier = expected => account.carriers.find(item => item.ref.digest.value === expected.ref.digest.value);
    for (const item of [baseline, output, input, reflection]) assert.deepEqual(selectedCarrier(item), item);
    assert.equal(JSON.parse(selectedCarrier(input).value).statedIntention, firstStatement);
    assert.deepEqual(account.records.find(item => item.type === 'report'), derivation);
    assert.deepEqual(account.records.find(item => item.type === 'relation'), about);
    const { links, limits } = JSON.parse(projection.value);
    assert.ok(links.some(link => link.from.identity.id === about.identity.id && link.to.identity?.id === later.act.identity.id && link.check === 'matched'));
    assert.ok(links.some(link => link.from.identity.id === about.identity.id && link.to.identity?.id === contribution.act.identity.id && link.check === 'matched'));
    for (const item of [baseline, output]) assert.ok(links.some(link => link.from.identity.id === derivation.identity.id
      && link.to.digest.value === item.ref.digest.value && link.check === 'matched'));
    assert.ok(limits.includes('model-origin-unverified'));
    const reader = `${scope}:unselected-reader`;
    const other = record('participant', 'other', { party: `${scope}:other-agent`, kind: 'agent', roles: ['participant'],
      controllers: known([reader]), description: [] });
    owner.enroll(json({ principal: reader, participant: other, terms: rule('fixture-enrollment'), notAfter: expires }));
    assert.throws(() => owner.bind(() => auth(reader)).inspect(json({ selection: 'reflection-selection' })),
      { code: 'inspection_denied' });
  } finally {
    owner?.close();
    rmSync(scratch, { recursive: true, force: true });
  }
});
