# Bundled third-party notices

Original SDK code is MIT. Dependencies retain their own included terms.

## ajv@8.20.0

License metadata: MIT.

- [node_modules/ajv/LICENSE](node_modules/ajv/LICENSE)

## ajv-formats@3.0.1

License metadata: MIT.

- [node_modules/ajv-formats/LICENSE](node_modules/ajv-formats/LICENSE)

## canonicalize@5.1.0

License metadata: Apache-2.0.

- [node_modules/canonicalize/LICENSE](node_modules/canonicalize/LICENSE)

## fast-deep-equal@3.1.3

License metadata: MIT.

- [node_modules/fast-deep-equal/LICENSE](node_modules/fast-deep-equal/LICENSE)

## fast-uri@3.1.8

License metadata: BSD-3-Clause.

- [node_modules/fast-uri/LICENSE](node_modules/fast-uri/LICENSE)

## json-schema-traverse@1.0.0

License metadata: MIT.

- [node_modules/json-schema-traverse/LICENSE](node_modules/json-schema-traverse/LICENSE)

## jsonc-parser@3.3.1

License metadata: MIT.

- [node_modules/jsonc-parser/LICENSE.md](node_modules/jsonc-parser/LICENSE.md)

## require-from-string@2.0.2

License metadata: MIT.

- [node_modules/require-from-string/license](node_modules/require-from-string/license)
