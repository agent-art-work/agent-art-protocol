// Raw tools/list and tools/call methods, with no server, transport or identity provider.
export { createParticipationAdapter, TOOL_CATALOG, ADAPTER_INFO } from '../../../artwork-contracts/mcp-participation/mcp/adapter.mjs';
