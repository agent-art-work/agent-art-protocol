// Trusted application administration and scoped participation over one Work owner.
export { ParticipationOwner, validateSetup } from '../../../artwork-contracts/mcp-participation/durable/owner.mjs';
