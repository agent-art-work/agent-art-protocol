// TEST ONLY. Production entries do not import this synthetic identity authority.
export { InertPrincipalResolver } from '../../../artwork-contracts/mcp-participation/mcp/inert-resolver.mjs';
