// Pure candidate contracts; no owner/storage, transport or test identity import.
export * from '../../../artwork-contracts/mcp-participation/src/index.mjs';
