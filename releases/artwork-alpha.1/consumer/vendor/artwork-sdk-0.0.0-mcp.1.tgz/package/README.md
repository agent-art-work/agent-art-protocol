# Agent Art SDK — MCP participation candidate

`@agent-art/artwork-sdk@0.0.0-mcp.1` is private, unpublished and experimental.
For an artist working with a coding Agent: build the work's app and creative
rules; reuse one owner for scoped participation, exact originals, receipts,
recovery and selected process inspection.

Read [the consumer contract](CONSUMER-CONTRACT.md) before integrating. The four
imports are the package root (pure contracts), /owner, /mcp and the explicit
/testing/inert-resolver. No transport, login, client, model or renderer starts
when imported. The test resolver is not production authentication.

The named native cohort is Node22.23.4, macOS arm64, SQLite3.53.4. Node is an
external prerequisite. This API candidate is separate from old 0.0.0-m7.2 and
reading SDK0.1.4; use its exact archive and matching lock, never a moving alias.

## Try the installed fixture

After offline installation with scripts/bin links disabled, copy the three files
from examples/no-client into an otherwise empty app directory and run:

```sh
node smoke.mjs
```

The example uses public SDK imports only. [works.json](examples/no-client/works.json)
contains two invented app configurations; [app.mjs](examples/no-client/app.mjs)
owns their records, Human input, progression and app decisions. The runner creates
private temporary Work stores, exercises in-process method calls, reopens/rechecks
them and closes/removes only those owned fixtures. It never opens a listener,
launches a client, connects an account or requests a real Agent response.

Fixtures demonstrate what artists/coding Agents write and what the SDK supplies.
They are not finished artworks, a no-code platform or live client qualification.
Receipt, Agent attribution, app treatment and rendering remain separate. The
SDK preserves permitted text/SVG source without rendering it. Audience judgement
of intention and artistic significance remains outside factual checks.

MCP initialization/transport, real OAuth/identity, consent collection and host
qualification are still separate work. Do not expose the test resolver or native
owner administration as remote curator inputs. This candidate does not authorize
publishing/deployment or a real Agent call.

Original code is MIT; see [LICENSE](LICENSE) and
[bundled notices](THIRD-PARTY-NOTICES.md). Candidate reference snapshots are
[schema](reference/SCHEMA.md), [design](reference/DESIGN.md) and
[principles](reference/PRINCIPLES.md). Their candidate status is preserved; source
navigation outside those snapshots is labelled as source-relative text.
Installed fixture success is narrower than
protocol interoperability, production readiness or independent Agent origin.
