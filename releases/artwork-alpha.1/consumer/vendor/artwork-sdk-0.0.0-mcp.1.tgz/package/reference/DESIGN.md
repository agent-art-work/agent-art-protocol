> Candidate reference snapshot. Technical prose retained; navigation outside the three bundled references is labelled source-relative text.
> Original source: `spec/DESIGN.md`; SHA-256 `090f97147871e016484bde95b72ff82fe5f205b968ba03f8bff4f8f1e0cf8f14`.

# Agent Art Protocol: working design baseline

**Working baseline adopted 2026-10-27; agnostic contract consolidated 2026-11-12.**
This is the authoritative current semantic draft. It separates protocol receipt,
Act attribution, artist/app acceptance and rendering. Detailed wire/API and
operational requirements remain candidate. This is not a released standard,
successor SDK implementation or new client qualification. Here,
"requires" describes proposed conformance to an advertised capability; it does
not mean a condition of Agent Art or a claim that current software implements it.

Start with the README position (source reference: `../README.md#position-and-scope`) and
[core principles](PRINCIPLES.md). The earlier v0.1 contract (source reference: `0.1/CONTRACT.md`),
dated architecture (source reference: `../ARCHITECTURE.md`) and experimental packages retain their
original scope. The format ownership review (source reference: `artwork/FORMAT-OWNERSHIP-REVIEW.md`)
maps the current implementation's coupling; this document specifies the successor
meaning without reinterpreting those earlier records or outcomes.
The conformance plan (source reference: `CONFORMANCE.md`) describes checks still to implement/run.

The [agnostic schema draft](SCHEMA.md) now proposes concrete logical fields,
references, JSON/hash domains, payload carriage, receipts/reports and binding
obligations. It is independently specified; no SDK/runtime source is normative.
It supplies no executable validator or new implementation/qualification.
The independent-implementability review and correction (source reference: `SCHEMA-REVIEW.md`) record
closure of SR1–SR4: occurrence references and authority stay distinct; current
heads have a declared atomic policy; byte totals count commissioned descriptors;
and exact terminal Receipts have finite, private recovery promises independent
of artwork retention. The original reviewed draft is retained byte-for-byte.
The corrected schema remains a protocol proposal; separate SDK binding design
is now recorded in SDK-BINDING.md (source reference: `SDK-BINDING.md`) as a bounded local UTF-8
successor. It maps actual reusable owner/store/return/pairing facilities and
necessary codec/runtime/Receipt/inspection changes without implementation.
No architectural replacement or actual deployment policy is selected.

The integrated stack proposal (source reference: `STACK.md`) now connects this semantic baseline
to a candidate SDK/runtime (source reference: `SDK.md`), MCP interface (source reference: `MCP.md`) and
creation plugin (source reference: `PLUGIN.md`). It proposes a project-scoped local first pilot,
record encoding and concrete operational boundaries. These companion designs
remain bounded implementation proposals. A particular host, carrier, encoding or
media profile in them does not become a universal protocol requirement. Actual
implemented/qualified paths are recorded in PLAN.md (source reference: `../PLAN.md`).

## 1. Purpose and boundary

One protocol connects Agent environments with applications and makes the
evidenced portion of participation inspectable. It supports recording,
preservation, exchange, export, checking and audience accounts without deciding
what an artwork means, measuring pure intention or certifying Agent Art.

The sole first-class SDK user is an artist working with a coding Agent. This
user and the purpose of lowering the barrier to entering Agent Art creation
were adopted on 2026-10-27. The SDK should help that collaboration progress from
an artistic idea to a supported work, rather than require the artist to arrive
with a development team. Experienced developers can use it, but are not a
separate first-class design persona. Named local implementations have bounded
results; the agnostic successor described here is not yet implemented or qualified.

Agent Art Work's [manifesto](https://agentart.work/) and
[definition](https://agentart.work/agent-art/) concern the broader artistic field.
This protocol supplies optional digital infrastructure. A physical result can
be associated with a digital participation account without making protocol use
a condition of that artwork. No particular medium, separate curator, paid Agent,
public transcript, cloud platform, blockchain or mint is universally required.

THOUGHT supplies a text reference; DF exposes the current SVG/format coupling.
Neither artwork's creative sequence, format rules or interface defines the core.
The current reading SDK remains usable without artwork obligations. New
implementation and live trials need their own scope; this slice changes documents.

### Agnostic scope and retained responsibilities

The evidence model is independent of artistic medium, participation surface,
Agent host/model, initiator and round count. A website, desktop conversation,
application, permitted import or other supported integration can supply process
material. There is no mandatory website→desktop Agent→backend route, local
inference, separate curator, alternating dialogue or final Result.

Artists/apps own artistic formats, interaction and progression, usability checks,
acceptance, composition, rendering and presentation. The core identifies exact
permitted data and process, authority, attribution, declared connections and
supporting evidence. It checks its own envelope, representation, integrity and
finite operational budgets. A media label is a declaration, not a successful
format check, rendering permission or proof of model perception.

An integration records only what it is permitted and able to access. A live
observation, capability-holder return, selected import and app report preserve
their different sources, control and coverage. Private context, surrounding chat
and hidden reasoning are not automatically collected. Semantic independence
does not advertise universal media carriage, client support or execution proof;
each binding states its supported encoding, limits, observations and trust.

## 2. One model, optional roles

| Primitive | Meaning and responsibility |
| --- | --- |
| Work (source reference: `primitives/WORK.md`) | An identifiable frame for participation, offered context and applicable conditions. Distinguish its declaration, a particular occurrence where needed, developing context and results. |
| Participant (source reference: `primitives/PARTICIPANT.md`) | A party identified for involvement and attribution. Contributor identity, role, principal, client/runtime and evidence remain distinguishable. |
| Act (source reference: `primitives/ACT.md`) | An expression, decision or contribution attributed to a Participant within a Work. Receipt, attribution, app acceptance, selection and effect are different claims. |
| Relation (source reference: `primitives/RELATION.md`) | An attributed declaration of how identified participation material connects. A declared response, revision or combination does not imply endorsement, awareness or demonstrated consequence. |

Evidence (source reference: `primitives/EVIDENCE.md`) crosses all four. It is material offered to
support or challenge claims, separate from assessments of that material.

Artist, curator, operator, transmitter, observer and verifier are responsibilities,
not a fixed roster. One human can frame, authorize, operate and contribute with
their Agent; those operations keep their actual authority and attribution.
There is no need to create a duplicate curator identity. A service or witness
need not become an artistic Participant merely to issue an observation.

Several Participants can share one controller, account or model. That neither
collapses their attribution nor proves independent control. The same shared
protocol also permits repeated Acts by one Participant, Agent-Agent encounters,
parallel branches and continuing or unresolved Works.

## 3. Capabilities instead of role-based protocols

Every use identifies a Work descriptor. Additional capability families are
composable. The labels below are design names, not new released API strings.

| Capability | Advertised obligation | Dependencies and limits |
| --- | --- | --- |
| Handoff | Make the identified invitation/context available and prepare a supported client route or Copy fallback | Can be entirely static/client-side. No Participant enrollment, return, storage or sending/reading claim is implied. Handoff is not a prerequisite to Agent-initiated access. |
| Record | Capture/import attributed Acts, Relations and supporting process material; retain and retrieve exact identified versions under an explicit policy | A recorded import or manual relay keeps its actual source and transmitter. Recording does not establish live Agent-controlled return or app acceptance. |
| Exchange | Authorize access, offer/read identified context, receive permitted submissions and resolve their recording outcomes | Requires retained records and authoritative outcomes/recovery. Durable receipt and Act attribution remain separate from app acceptance; promised preservation cannot be omitted. |
| Inspect | Export permitted process/evidence material and expose an audience-readable account linked to its basis and limits | Can consume an offline bundle or a live record source; no mandatory central service. Inspection grants do not confer contribution or publication authority. |
| Check | Evaluate named claims using supported methods, actual material and explicit external trust/policy | Methods and coverage are advertised individually. No universal execution-proof method, global authenticity verdict or artistic-quality assessment. |

Media/resource exchange and update notifications are separately advertised
features with concrete limits. They do not silently follow from a generic
capability name. A text-only path cannot claim graphic acquisition or perception.

Implementations advertise what they support; a Work states what it requires;
the caller's grant states what this principal may do. Use their compatible
intersection, including versions, content types, evidence methods and limits.
If a required feature is unavailable, return that limitation. Do not silently
downgrade direct exchange to manual relay or execution proof to a local receipt.
A caller can deliberately choose a narrower fallback with its actual meaning.

| Use | Possible composition |
| --- | --- |
| Ask your Agent reading | Work + Handoff; optional bounded browser receipts. Zero observed Participants/Acts/Relations, no evidence store or answer callback. |
| Artist records an exchange with their own Agent | Work + Record + Inspect; declared manual/imported provenance is permitted. Check adds only the advertised claims. |
| Artist's Agent contributes through a live return path | Work + Record + Exchange; Inspect/Check as promised by the work. No separate curator is needed. |
| Invited curators and their Agents | The same capabilities with additional scoped principals, grants and disclosure boundaries. |
| Agent-first, parallel or Agent-Agent work | The same record/exchange model; standing access can precede creative initiative without inventing a human Act. |

These are examples, not separate protocol editions or exhaustive artistic forms.

## 4. Descriptor, references and retained records

### Work descriptor and profile

A descriptor identifies the Work, applicable declaration revision, purpose,
offered context, profile/version, capability requirements, access/disclosure
policy and relevant locators/limits. It may be an inline object or static public
document. Public reading requires no visitor-specific occurrence or registry.

A work profile declares how material or a bound choice is attributed as an
expression/decision, who may make that attribution, and any contribution/Relation
requirements. It separately supplies artistic acceptance, selection/composition,
available Agent choices/refusal, media/usability restrictions and claimed effects.
Context/staleness, authority, evidence, disclosure, retention and lifecycle rules
state their applicable scope. Descriptive intent is distinct from rules actually
enforced. A profile uses the core; it is not an authority over Agent Art.

### Exact references and change

A logical identity, exact record/version reference, mutable locator and content
digest have different meanings. An exact reference must not silently resolve to
changed content. A digest binds available bytes under its specified method; it
does not uniquely identify an Act, prove origin or reconstruct missing material.
Deliberately repeated identical expressions can have different Act identities.

For retained records, this draft proposes immutable identified versions. Changed
expressions are retained as new Acts with attributed revision links. Corrections,
reviews and disputes identify their earlier subjects rather than overwriting
them. A Work may evolve through attributable revisions; profiles decide adoption
authority, effective scope and whether a change needs a new occurrence or Work.
Earlier participation retains its applicable basis until availability policy
limits access. No universal permanently frozen Work is imposed.

### Minimum information when retained

These groups define semantics; exact field names and wire encoding are not frozen.

| Record | Information required for its advertised claim |
| --- | --- |
| Work | Identified frame/revision and, where needed, occurrence; relevant conditions/context and amendment authority |
| Participant | Scoped reference and attribution basis; role/control/association claims distinguished from authenticated principal or execution evidence |
| Act | Distinct expression/decision reference; Work scope/revision and declared attribution mapping; attributed contributor and responsible attribution source; original permitted material or bound choice/options; declared context basis; actual transmitter/importer and handling references |
| Relation | Distinct declaration reference; scoped meaning/vocabulary; identified referents with their roles; actual declarer and authority; any agreement claimed and its basis |

An import can lack the original declared context or transmitter identity. Mark
those as unknown/unavailable while identifying the actual importer/recording
source. Do not invent missing information or reject all partial records merely
to make a complete-looking history. Stronger claims remain unestablished until
their required basis is available.

Minimum Relation support covers connections among retained Acts and the Work.
Each profile declares its vocabulary, referent roles/cardinality and allowed
targets. There is no universal single predecessor, mandatory binary edge or
acyclic creative graph. A retained unaccepted proposal can be a target where
permitted; app acceptance of the target is not a universal prerequisite. Cross-Work,
resource or Relation-to-Relation targets require explicit additional support.

Supporting material includes context snapshots, grants, operation outcomes,
resource manifests, observations, artifacts and evidence/assessment records.
They are not additional participation primitives or compulsory records in reading.
An issuer/source, contributor, declarer and transmitting principal are never
implicitly interchangeable. Reported event time, observation time and assessment
time are distinct; timestamps do not establish a complete creative chronology.

### Receipt, Act attribution, app acceptance and rendering

These are separate claim categories, not new primitives, a required four-step
sequence or wire status names. A batch may record several together, but its
response and later inspection must identify which claims it actually supports.
Receipt here concerns recording. Existing reading/browser receipts retain their
own launch/copy claim and impose no durable-store obligation on reading.

| Category | Meaning and required basis | What does not follow |
| --- | --- | --- |
| Protocol receipt/preservation | An identified issuer reports the outcome of its scoped recording operation, binding exact permitted material/choice, authority, Work/basis, recorded references and retention/coverage. A durable receipt claims a completed commit; staging or network arrival alone cannot support it. | Receipt alone establishes Act attribution, app acceptance, Agent execution or content validity/safe rendering. Those require their own basis. |
| Act attribution | An identified source attributes an expression/decision to a Participant under the applicable Work mapping, binding its original material/options, declared context, actual transmitter/importer and evidence basis. | Attribution alone establishes model authorship, app acceptance, consequence or private intention. An upload, tool call or receipt alone is not an Act. |
| Artist/app acceptance and treatment | An authorized artist/app records its validation, acceptance, rejection, selection or withholding of exact subjects under an identified rule/version, method, result and scope. An artistic decision can be an Act where the Work maps it as such; administrative handling need not be. | Recording the report independently verifies it, changes the Agent's original, or turns its format rules into core protocol rules. |
| Rendering, transformation and display | An identified producer/observer reports exact inputs, rule/version or method, resulting derivative or presentation, and its actual coverage/outcome. | A derivative is the Agent original; successful computation establishes exhibition; a report establishes what an unobserved audience saw. |

A Work makes the expression/decision mapping explicit rather than equating all
permitted uploads with participation. If the declared mapping is met, app format
or artistic rejection is recorded as treatment of that Act, not as a reason to
erase it or silently change its attribution. Where material is retained only as
a submission attempt or imported assertion, that narrower classification remains
visible. A later classification/correction identifies its source and earlier
subject; missing attribution or evidence is not invented to fill a record.

Recording an Act does not require positive artistic acceptance. Once recorded,
later rejection, withholding, failed rendering or changed app rules cannot erase
its earlier recorded meaning or replace its original. Declared access/retention,
withdrawal and deletion policies still apply; unavailable material narrows later
claims rather than becoming silently absent history. Rejection alone must not
retroactively convert receipt-only material into an Agent Act.

Generic envelope, authorization, encoding, integrity or quota failures can stop
an operation before a durable receipt or Act exists. They do not require retaining
unauthorized/over-budget bodies. Any retained attempt/failure observation names
its permitted scope and actual source. Silence, timeout, app rejection and
permission denial cannot become the Agent's refusal; an explicit attributed
refusal can be recorded under the Work mapping without a positive artwork result.

## 5. Authority and context

A grant binds an actual principal to permitted operations, relevant Work scope,
attribution/role constraints where applicable, expiry/revocation policy and
disclosure rights. No role label automatically grants all powers. Work framing,
contribution, Relation declaration, review, inspection/export and publication
authority remain distinguishable. One person may legitimately hold several.

The carrier handles credentials through its supported security mechanism;
grants and exported process records contain references, not reusable secrets.
Work content and returned media are data, not permission to access unrelated
files, accounts or tools. Each binding requires its own security/compatibility
specification; no particular transport or login scheme is selected here.

Context access returns the identified basis offered for the operation: relevant
conditions, records, state and resources, with omissions and availability limits.
It need not expose the entire history or private Agent context. Distinguish
offered, client-acquired, execution-supplied, declared-used and comprehended.

A submission carries its declared historical basis separately from any required
current-state precondition. The profile chooses whether stale contributions are
rejected at the recording boundary, retained as branches or otherwise treated.
Separately identify app treatment of stale material. If an applied rule differs
from the declared historical basis, record both and the relevant outcome. Never
silently rebase an Agent's expression onto newer conditions or infer awareness
from order.

## 6. Logical operations

Operation names describe a contract; they are not fixed URLs, MCP tool names
or new SDK imports. Several may be local functions or static reads.

| Operation family | Contract |
| --- | --- |
| Describe / resolve | Identify descriptor, profile, revisions, capabilities and permitted exact records/resources. Report access and availability limits honestly. |
| Prepare handoff | Prepare the identified invitation, supported route and manual fallback. Launch acknowledgment does not establish draft arrival, Send or Agent execution. |
| Authorize / revoke | Establish or limit scoped authority under the actual issuer's policy, separately from creative participation and identity/origin claims. |
| Capture / read / list | Retain permitted originals/imports and their source, retrieve exact versions and expose a stated query/retention boundary. Capture alone establishes neither an Act nor app acceptance. |
| Submit / status | Offer scoped material and any proposed Acts/Relations under an identified basis; return or recover the authoritative recording outcome and exact recorded references. Identify any separately available app treatment by its own subject/source/version. |
| Cancel, where supported | Fence an uncommitted recording operation so late delivery cannot commit it; do not silently undo a completed receipt, Act or app decision. |
| Amend / relate / review | Attribute subsequent Work changes, links, selections, corrections, revisions or withdrawals under their actual powers. Classify artistic versus administrative actions explicitly. |
| Export / inspect | Produce a scoped bundle and readable account linking displayed statements to permitted source material, assessments and gaps. |
| Assess | Evaluate exact claims/material under supported methods and externally selected trust; identify performed and unperformed checks. |

Permission denial may intentionally conceal whether a subject exists. A read
can report unavailable-to-this-caller without claiming nonexistent. A lagging
view, empty query or missing private material is not an authoritative absence.
List operations identify their scope/watermark and any consistency/retention
limits; service order is not artistic causality or complete private history.

## 7. Admission, recovery and concurrency

These requirements apply when Exchange promises authoritative recording. In this
section, technical admission means admitting permitted evidence records to the
authoritative store. App acceptance has the separate meaning in section 4; a
binding using the word "accepted" must identify which outcome it denotes.
These requirements are not the definition of an Act or an artistic lifecycle.

### Commit boundary

A submission can offer material, proposed Acts/Relations and supporting reports.
The service checks actual recording authority, Work/profile/version bindings,
its protocol envelope and encoding, byte identity, finite budgets and applicable
recording preconditions. Proposed Acts/Relations must meet the declared mapping
and their structural/attribution requirements; a receipt-only operation claims
no Act. Artist format parsing is not a prerequisite for byte identity, canonical
record validation, storage reopening or evidence inspection in this successor.

The declared required recording batch commits its originals, records and
authoritative outcome consistently, or none of that batch is reported committed.
A binding specifies whether receipt-only material and later attribution are
separate operations or one atomic batch; it must not silently report partial
commit as a full success. Required material must be secured before a durable
receipt is issued. Staged uploads are not yet a durable receipt or Act. This
allows attribution and receipt to commit together without forcing every Work
to use the same operation layout.

Success identifies exact recorded values/references, attribution classifications
where any, applied recording policy/authority and retention scope. A format or
artistic rejection of otherwise permitted material is separate app treatment;
it does not turn a completed recording into technical failure. If the app stops
an encounter before any permitted receipt operation occurs, report that actual
boundary rather than claiming this service received the material. If a protocol
or claim-specific evidence requirement is unmet, its claim remains unmet; app
reports cannot substitute for the required evidence.

App validation/acceptance may run before, alongside or after recording. Its
issuer, subjects, rule and outcome remain explicit in every arrangement.
Rendering, selection, checks and external publication likewise have their own
outcomes. The protocol does not schedule them as compulsory subsequent rounds.

### Outcomes and exact retries

Distinguish recording committed, recording rejected, pending where supported,
and caller uncertainty. Authentication/transport failures are distinct from a
durable recorded outcome; response timeout alone does not prove no commit.
Act attribution and app acceptance/rejection/pending/unreported remain separate
dimensions, not one aggregate success flag. Logical labels here freeze no enum.

An operation identity is scoped to the actual principal, Work scope and operation,
and binds the complete recording payload, including basis, content/resource
identities, proposed Acts/Relations and required evidence. Exact retries resolve
the same recording outcome/references without creating more contributions or
rerunning/replacing artistic decisions. Separately queried app treatment may
evolve through new identified reports; that does not change the original receipt.
Reusing the operation identity with changed payload conflicts. A deliberately
new repeated expression has a separate identity and declared participation basis.
An operation identity is not an Agent identity, inference identity or artistic round.

Exchange declares a recovery window and bounded request-validity/fencing policy.
Deduplication must remain effective while an old request can still commit.
After validity expires, it cannot become a fresh write merely because payloads
or retry state expired. Previously committed identities cannot be reused after
content deletion. Within recovery policy, status exposes the actual recording
outcome and exact retained material/references to authorized callers; unavailable
material and recovery limits remain explicit. App treatment has its own revision.

An authoritative "not seen" at one instant does not prove an earlier request
cannot arrive later. Safe replacement needs an authoritative non-committed outcome
plus a terminal cancellation/fence, or expiry preventing future commit and
a final outcome lookup confirming no prior commit within the supported recovery
boundary. Expiry alone does not prove there was no earlier commit. Preserve uncertainty rather
than generating another submission identity as an automatic recovery step.

### Separate kinds of change

Cancellation concerns uncommitted recording. Withdrawal concerns later treatment
of recorded material or a contribution. Revocation concerns future authority.
Suspension concerns operation. Closure/reopening follows Work policy and does not universally
establish artistic completion. Races with recording must resolve consistently
at the authoritative commit boundary, with the actual result recoverable.

Concurrent contributions retain their own bases and declared connections.
No automatic overwrite, last-writer-wins or compulsory merge is supplied. Optional
update streams are hints within a stated coverage/resume policy, not durable
recording, automatic Agent wake-up or a substitute for authoritative reads.

## 8. Resources, results and retention

### Exact data without artistic interpretation

Where content is retained or referenced, identify its representation/encoding,
declared media type, exact byte identity where claimed, source, access and
retention policy. For encoded carriage, a binding specifies how the original
bytes are recovered and distinguished from its envelope/canonical record bytes.
Text normalization, reserialization and media conversion cannot silently change
the original. A record-only implementation must not claim it preserved original
media when it retained only a URL or digest. Required originals remain retrievable
for the promised period; later loss is an availability failure/limit.

The core can bind submitted bytes without understanding their artistic syntax.
An app's XML/SVG parser, line rule or image check belongs to the app's named
validation/treatment, not a universal storage or Act requirement. A binding still
advertises its encodings, resource access, protocol-envelope and storage/transport
limits. Unsupported carriage, malformed encoding and exceeded budgets remain
technical limitations. This distinction selects no arbitrary-binary API, larger
quota or claim of full SVG support for the existing candidate.

### Safe inspection and app-owned rendering

Safe previews, normalization, sanitization, resizing and rasterization are
identified derivatives with their actual transformation basis. Resource retrieval
does not establish model perception; a displayed preview is not the original SVG.
Default evidence inspection presents permitted identity, source, metadata and
bounded exact-source/escaped-data views where supported. It must not automatically
interpret or execute bytes because their declared media type says SVG, HTML or
another format. Uninterpretable content remains identified as uninterpreted;
unavailable source remains unavailable, rather than being shown as empty artwork.

An explicit app-owned renderer can supply a separately identified preview or
artifact under its own qualified isolation, resource and safety conditions.
The core need not implement that format, and receipt grants no right to run it.
Rendering failure is reported separately. Derivative subjects and producer/rule
versions remain attributable; artist-supplied or remotely supplied content never
becomes authority to execute arbitrary code in the evidence viewer. Each renderer
and each claim about safe or actual display needs its own qualification.

A result/artifact identifies a particular composition/state, its inputs and
applicable rules when that claim is made. It is a supporting subject, not a fifth
primitive or proof of Work completion. Originals can remain unselected under the
Work's disclosed rules. Consequence and live display remain separate claims.

Disclose collection/access audiences, retention and deletion limits before the
capability promises them. Redaction, expiry and deletion identify affected claims
where permitted. An earlier assessment can remain attributable while no longer
repeatable; that does not automatically make its original finding false. Do not
promise indefinite tombstones or retraction of copies already exported. Retained
identifiers and digests also need privacy policy, rather than being presumed harmless.

## 9. Evidence, checking and audience accounts

### Common evidence contract

| Supporting object | Meaning |
| --- | --- |
| Claim | Identified statement/vocabulary, exact subjects and relevant basis, responsible declarer, covered boundary and predicate where applicable |
| Material | Permitted bytes/records/observations; representation, source/observer and control; binding to subjects; coverage, access and availability limits |
| Assessment | Exact claim/material versions, checker, method/version, external trust/policy, checks actually performed, processing status, finding and limits |
| Bundle | Manifest of selected claims/material/assessments, versions, collection/disclosure scope, results, exclusions and repeatability dependencies |
| Audience account | An attributed readable projection of that basis, connecting explanations and safe previews to subjects/material, sources, assessments and known gaps |

These objects organize evidence; they do not add creative primitives. A bundle
does not certify itself, appoint its issuer trusted or turn a declaration into
an observation. Imported browser receipts retain their actual original schema,
issuer and bounded meaning.

Check methods are advertised by the claims and material they can actually cover.
Distinguish processing completed/unsupported/unavailable/invalid/failed from a
claim being supported under policy, contradicted or not established. A signature
mismatch concerns that signature claim, not universal human authorship or fakery.
Changed material, rules or trust policy need another assessment; an earlier
finding cannot silently attach to a changed subject.

Execution-origin methods are extensions to this shared contract. No method or
universal origin threshold is selected. The earlier
dual-independence recommendation (source reference: `artwork/ASSURANCE-RECOMMENDATION.md`) remains
unadopted. If a profile requires it, missing evidence cannot satisfy that profile;
other records retain their narrower meaning. A genuine provider response does
not automatically cover a client's selection, tools or return. Only covered or
disclosed interventions are attributed; private intention remains outside proof.

### Attributable app and presentation reports

A retained report identifies the exact submission/Act/original/derivative it
concerns, applicable Work/rule revision, actual issuer and recording principal,
method or procedure, reported outcome, covered state/time where relevant, and
source material, trust and availability limits. A validation report can state
"unsupported by this app" without claiming the data is universally invalid.
An acceptance or selection identifies whose decision it is. A render report
identifies its inputs and output or failure; a display observation identifies
the actual presentation surface and observation coverage.

Report rights follow scoped authority. Permission to submit an Agent-attributed
expression does not confer permission to declare the artist's acceptance or
forge a renderer/observer report. Recording an imported report identifies the
importer and claimed issuer with their actual basis. A later rule change or
correction produces another identified report linked to its earlier subject;
it cannot change the original or silently overwrite the earlier assessment.

Recording authenticates/preserves the report only to the extent its stated path
supports. Independent verification of its assertion is a separate assessment.
An app report and a check by the same operator do not gain independent control
merely by having different labels. Reports organize evidence; they are not a
new primitive. An actual artistic decision may additionally be an Act under its
declared mapping; that does not turn every operational report into participation.

A consequence claim binds actual contributing material/status, applicable
conditions and state, a bounded artist-supplied predicate/checker and identified
output. Include acceptance where claimed or profile-required; an unaccepted
proposal can affect later participation without invented acceptance. Test the
specified effect: an Act ID in metadata, an ignored input or a layer hidden under
an opaque image does not establish a claimed visible contribution. The artist
owns artistic rules; audiences interpret significance.

### Audience presentation

Inspection is an explicit reusable SDK responsibility when advertised, not merely
a developer debug log. Show readable statements connected to their supporting
subjects and material. Preserve distinctions among original and derivative,
contributor and selector, declared link and observed dependency, partial account
and complete scoped coverage. Allow branches, alternative bases and continued work
instead of manufacturing one linear or jointly agreed story.

The artist controls style and narrative; a custom account still identifies whose
selection/arrangement it presents and makes factual basis/limits accessible.
Views identify their bundle/source revision and selection/disclosure policy.
Restricted or private inspection is valid. Giving an audience access to one
account grants no access to private Agent memory, conversation or hidden reasoning.

Export supplies permitted material to repeat advertised checks, or explains the
dependencies preventing repetition. An offline reader can inspect a bundle without
trusting the artwork's UI, but still needs explicit trust and permitted material
for stronger claims. Seeing the evidence account does not prove what another
live artwork surface previously displayed. Export, public exhibition and minting
remain separately authorized actions; the consuming contract owns mint admission.

### Paper checks of the agnostic contract

These are invented semantic traces and review cases, not executed tests, live
observations, changes to an artwork's rules or qualification of new media/clients.
Identifiers below are explanatory labels, not frozen wire fields.

| Case | Same retained meanings | Required distinction |
| --- | --- | --- |
| Text encounter shaped like THOUGHT | A Work maps a Human line and Agent-attributed reply to separate Acts. Their scoped receipts/originals, response Relation and later Human selection identify their actual sources. An app separately reports acceptance and a derived text pair. | Receipt, attribution, artistic acceptance, derivation and display are independent claims. Reproducing the pair establishes only the specified derivation under its stated inputs/rule. |
| Rich artist-owned SVG rejected by an app | A permitted in-budget submission passes generic envelope/authority/encoding checks. Under this example Work's mapping it is recorded as an Agent-attributed contribution with exact original bytes. The app reports "unsupported by rule v1" about that subject. | The shared evidence path does not parse SVG grammar. Rejection preserves the receipt, original and recorded Act under policy; the viewer does not automatically render it. Model authorship remains unestablished without its own basis. |
| Changed app rules and failed renderer | Rule v2 later accepts that same recorded SVG; a separate render report identifies the original and its failed rendering attempt. The v1 rejection remains accessible within policy. | New acceptance does not overwrite prior treatment. Renderer failure erases neither attribution nor acceptance and cannot become an Agent refusal. A later preview/derivative still does not prove exhibition. |
| Agent-first, multiple rounds, no website | Under standing authority an Agent-attributed initial expression is followed by another expression, a Human response, a branch and an Agent revision. Each offered/declared context basis, Act and attributed Relation stays explicit. An authorized non-browser integration supplies covered material. | No Human opening, alternating turn, fixed round count or final Result is required. A live integration names its actual observed boundary; host/model independence does not prove that the path is supported. |
| Selected import of that exchange | A permitted import preserves selected originals, claimed contributor/context/Relations, actual importer and source/coverage gaps. Its receipt identifies the import operation. | It does not invent a witnessed historical return, context acquisition, complete conversation or execution. An imported attribution may be retained without being independently established. |
| Exact retry versus intentional repetition | A lost acknowledgement is resolved with the same bound recording identity. A later deliberate expression uses its own Act/operation identity and declared basis even if its bytes match. | Retry creates no duplicate Act or app decision. A matching digest does not collapse independent expressions; uncertainty does not authorize automatic replacement. |
| Technical failure versus explicit refusal | A denied/expired grant, malformed envelope, unsupported encoding, quota excess or incomplete upload has its actual technical outcome. A separately permitted explicit refusal is attributed under the Work mapping. | No unauthorized-body retention or artistic Act is invented for the technical failure. Failure, missing evidence and silence cannot be reported as Agent refusal. |

These cases preserve all four primitive meanings while varying format, entry
surface, initiative and treatment. They test the proposed semantics on paper;
app rendering and actual adapters remain separately qualified responsibilities.

## 10. Implementation and SDK boundaries

```mermaid
flowchart LR
    App[Artist application] <--> Bridge[Qualified Agent adapter]
    Bridge <--> Agent[Agent environment]
    App <--> Store[Process records and permitted material]
    Bridge --> Store
    Store --> View[Audience account and export]
    Store --> Checks[Claim-specific checkers]
    Checks --> View
```

These are logical responsibilities, not mandatory separate services, trusted
parties or artistic order. Handoff-only reading bypasses the record/check/view
facilities. A local artist application can co-locate components; invited-curator
work can use an authorized remote service. Hosting alone establishes no independence.
There is no required shared cloud model or artist-hosted inference platform.
The diagram illustrates an adapter arrangement; an authorized non-browser
integration or selected import can supply material with its actual evidence basis.

| Owner | Supplies |
| --- | --- |
| Artist/application | Work profile, artistic rules, permitted choices, participant experience, composition/renderer, effect predicates and disclosure/narrative choices |
| Protocol/SDK implementation | Common record/reference handling, capability negotiation, handoff/adapter contracts, scoped exchange/recovery, resource boundaries, evidence/export/checking interfaces and reusable inspection data/views |
| Operator | Actual storage, availability, identity/authority integration, retention, secrets and service operation where those facilities are used |
| Agent environment | Actual inference/process, private context/tools, client permissions and contributed material through its qualified path |
| Evidence source/checker | Its covered observations/statements or actual checks, method/policy and trust/availability limits |

Planned SDK responsibilities can be modular: description/handoff, recording,
exchange, evidence/checking and inspection, plus client bindings. These are not
new import paths selected by this document. Apps should not rebuild those common
facilities per client; neither should the SDK implement each artwork's aesthetics
or decide its meaning. Client setup/permissions and actual context/return behavior
must be qualified, not inferred from a connector URL or abstract carrier support.

### Proposed developer experience: artist and coding Agent

**User and purpose adopted 2026-10-27; delivery details remain proposed.** This
supersedes the earlier wording that treated artist-and-coding-Agent development
as merely one possible target. It is the sole first-class SDK user. The heading
and its existing link are retained for compatibility with earlier references.

The central value is lowering the barrier to entering Agent Art creation. An
artist can begin with an idea and work with a coding Agent to build a supported
work without inherently recruiting a separate human programmer. Engineering
and operation still happen, with the Agent performing much of the
implementation. Experienced developers can use the SDK, but are not a separate
first-class design persona. This is not a universal no-code guarantee or a
currently implemented artwork-authoring product.

The artist directs the work purpose, consequential choices, interaction and
presentation. The coding Agent uses documented SDK capabilities to build the
application and adapters, prepare previews, run reproducible checks and explain
failures. The SDK should provide maintained examples, explicit contracts/limits,
common recording/exchange/inspection facilities and actionable diagnostics,
rather than requiring the Agent to reinvent the infrastructure.

The starting experience should explain the work's idea, participation and
inspectable process in terms the artist can direct, then give the coding Agent
an actionable brief. A local guide or generated brief is an entry aid, not an
artwork runtime, a participating Agent or evidence that an encounter occurred.

The current creation guidance (source reference: `artwork/CREATION-FRAMING.md`) begins, “What would
you like this work to explore, express or let people experience?” Its outcome
is attributable Work framing retained as authoring notes, with an explicit
decision about what exact wording will be offered to a participating Agent.
Participation conditions, offered context and an artist's Act are separate.
Telling the coding Agent an idea proves no participating-Agent acquisition or
comprehension. Ask for an opening contribution only when the selected supported
form needs one. This adds no primitive or mandatory schema field and changes
neither frozen artifacts nor older recorded context.

Building the application and contributing to its artwork are functions, not
mandatory separate actors or new primitives. One Agent may do both, but writing
code or creating a fixture does not automatically become a participating-Agent
Act or evidence of a real encounter. Record actual contributions and sources
according to the Work's rules and observation boundary.

Accounts, secrets, permissions, hosting, retention and releases still need actual
operating arrangements and authority. This target selects no managed platform,
visual authoring application, autonomous account access or deployment. The
current released SDK covers reading; the artwork facilities remain to be built
and qualified for the agnostic successor. Named existing candidates and actual
local results retain the narrower status recorded in PLAN.md.

## 11. Versions, compatibility and next design work

Distinguish protocol specification revision, record-schema version, capability/
method version, Work/profile revision, adapter/client version, SDK package
version and evidence-view version. A release identifies which artifacts it
releases and their exact compatibility; specification and SDK numbers need not match.
Unknown optional material can remain visible as unsupported; unknown required
semantics cannot be reported as conforming. No silent reinterpretation of prior
records or receipts is allowed.

Released reading `0.1.5-alpha.2` and retained `0.1.4` package bytes/APIs remain
unchanged. Existing `defineWork`, `createReading`, `mountReading`, native routes,
Copy and receipt verification keep their recorded scope. Handoff must remain
usable without requiring new artwork schemas, enrollment, callbacks or storage.
This design selects no next package/version, registry publication or deployment.

Ask your Agent's product/package/release separation is adopted and deferred in
PLAN.md. It remains independently usable and can remain a lightweight use case;
it needs no artwork runtime, Participant enrollment, evidence store or callback.
Its SDK releases do not identify a separately released stable protocol standard.
No package rename or repository split occurs through this document.

### Versioned correction over the existing implementation

The ownership review (source reference: `artwork/FORMAT-OWNERSHIP-REVIEW.md`) names a concrete blocker:
the current M7.2 path uses SVG grammar to gate attribution/commit, canonical
validation, reopening and inspection. Its restricted preview relies on that
gate. It does not implement this successor merely because it preserves some
private return bytes before parsing. Removing one helper check is insufficient.

Reuse the settled authority, originals, exact retry/status, cancellation fences,
transactions and selected inspection. The next binding design must map only the
necessary corrections onto those facilities, rather than add another evidence
service or reopen host-assurance work without a concrete operational blocker.

| Existing boundary | Required successor distinction to design |
| --- | --- |
| Work declaration and return bindings | Declare supported representation/limits and the expression/decision mapping separately from app format and artistic rules. |
| Preparation and scoped return | Generic permitted receipt/preservation and proposed Act attribution have explicit outcomes; an app's format rejection has its own subject/report. Preserve pinning, commit and status/retry consistency. |
| Canonical records and store reopen | Structural validation and original-byte/reference integrity must not depend on the artist's current media parser. Retention and authorization still apply. |
| App decisions and assessments | Bind exact subjects, issuer/authority, rule/version, reported treatment and its evidence basis; append later reports/corrections rather than rewrite originals. |
| Inspection and preview | Inspect permitted data and process without requiring artistic interpretation; qualify explicit renderer integration separately before exposing newly uninterpreted content. |

Define a versioned successor. Preserve old schema/profile identities, Work data,
archives, locks, original outcomes and qualification records. Do not remove
checks under `m7.1` / `static-svg-draft1`, upgrade actual private Works silently,
or turn historical format rejections into successful Acts. The dated THOUGHT
example and SOURCE.md retain their own earlier profile meanings. Changed
packaged inputs need a fresh archive, consumer pins and their own qualification.

### Remaining bounded decisions and qualification

The presented design direction makes concrete choices: five composable capability families;
separate capture and exchange; version-specific retained references; append new
expressions/corrections; scoped reliable recording/recovery; optional method-specific
checking; and portable audience inspection. That direction is the working
baseline. Detailed requirements, wire/schema choices, profile policies and
planned conformance cases still need refinement and checks; they are not all
ratified by agreement on the presented design.

Before implementing a binding, specify its exact schema/encoding/digest domains,
identifier and vocabulary rules, version/capability advertisement, credentials
and endpoint/tool mappings, per-profile validity/recovery/retention limits and
resource/checker interfaces. Then apply the conformance plan (source reference: `CONFORMANCE.md`),
first to bounded fixtures and later to separately authorized real-client cases.
The two artwork walkthroughs (source reference: `artwork/MODEL-WALKTHROUGH.md`) remain paper inputs.
The ordered protocol review/correction and SDK binding design (source reference: `SDK-BINDING.md`)
are recorded separately. The schema proposes exact logical types, JSON/hash and
carriage rules, receipt-versus-Act/report distinctions, and finite-bound/recovery
obligations. The proposed binding selects a bounded transport/authentication,
budget, commit/storage/recovery and inspection arrangement. Exact implementation
contracts/vectors, source changes and qualification remain ahead. Existing runtime
constraints supply feasibility feedback, not universal protocol requirements.
All these choices remain draft; no arbitrary media support, new host or new
execution-origin claim follows from recording a schema proposal.
The paper cases in section 9 are design acceptance cases, not completed conformance.
Existing named local execution results retain their bounded trust/coverage;
new binding/client or stronger origin claims need their own supported basis.
