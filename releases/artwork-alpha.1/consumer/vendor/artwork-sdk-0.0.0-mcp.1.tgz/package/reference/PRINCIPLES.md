> Candidate reference snapshot. Technical prose retained; navigation outside the three bundled references is labelled source-relative text.
> Original source: `PRINCIPLES.md`; SHA-256 `3c8baeca4d88efa92c63c2f6e737de7fe8958d56ede4b0742c0ebd5768cbc6ec`.

# Our position: participation, evidence and interpretation

**Core position adopted 2026-10-27.** This guides the protocol and SDK, its
documentation and the claims we make about it.

> We build infrastructure that connects participants with their Agents,
> preserves the evidenced process of participation and makes it inspectable
> by audiences. Audiences interpret intention and judge artistic significance
> and quality.

The README (source reference: `README.md#position-and-scope`) states this position at the
repository's main entry. This document develops it as a standing design guide.

## Who the SDK is for

**The sole first-class SDK user is an artist working with a coding Agent.**
This user and purpose were adopted on 2026-10-27. The purpose is to lower the
barrier to entering Agent Art creation: let an artist begin with an idea and
build a supported digital work with their Agent, without inherently needing
to recruit a separate human programmer. Reducing repeated integration work
serves that purpose; saving an established development team's time is not the
whole value.

Experienced developers can use the SDK, but they are not a separate first-class
design persona. Examples, checks, diagnostics and reusable facilities should
serve the artist-and-Agent collaboration. The artist directs the work; the
coding Agent helps implement, preview, test and explain it. Engineering and
operation remain real responsibilities.

Building and participating are functions, not compulsory separate actors or
additional primitives. One Agent may do both, while application code, fixtures
and artistic contributions keep their actual classification and sources. This
purpose does not claim that the artwork SDK is built, or select a no-code
authoring platform, managed service or automatic deployment.

## Agent Art is broader than this protocol

Agent Art Work's [manifesto](https://agentart.work/) and
[definition](https://agentart.work/agent-art/) concern Agent intention as an
artistic contribution alongside human intention. They do not prescribe a medium,
web application, evidence package or separate curator. A painter can make Agent
Art without code or protocol use. Artists choose their practice and whether/how
to present evidence; audiences judge the contribution and the account offered.

This protocol supplies optional infrastructure for digital interactions. Its
technical requirements govern the capabilities and factual claims it supports,
not admission to Agent Art. The browser/desktop arrangement explored here is a
concrete practice, not the boundary of the field.

A separate curator is optional in the generic participation model. The artist
may frame the work, authorize access and contribute with their own Agent. Invited
curators can be added where the work calls for them. Combining responsibilities
does not require duplicate human identities, erase the Agent's attribution or
establish independence. Evidence strength depends on control, coverage and trust,
not simply the number of people or named roles.

## Intention is an artistic and philosophical question

Agent Art explores works in which Agent intention has consequential standing
alongside human intention. Whether an intention is free, pure, independent,
influenced or meaningful belongs to philosophical, social and artistic
interpretation. We do not need to settle those questions or invent a measurement
of pure intention to build useful infrastructure.

The protocol gives participation a shared language and an inspectable basis.
It does not determine what an artwork means or award it artistic legitimacy.
Artists frame the work; participants contribute; audiences form their judgments.

## Evidence the process, preserve it and make it understandable

The protocol and SDK should help artists connect real Agent environments and
make the permitted, evidenced process available for inspection. That includes:

- the work's offered conditions, context and available choices;
- attributed contributions, responses, refusals and revisions;
- declared connections between contributions, including who declares them;
- covered or disclosed selection, editing, transformation and other interventions;
- identified results and evidence of how contributions affected them;
- the sources, checks, trust dependencies and gaps behind those statements.

Preservation keeps received originals distinguishable from later versions and
derivatives under the stated retention policy. Presentation connects readable
explanations to supporting material. It is a product responsibility alongside
capture, preservation and export, rather than merely a collection of receipts.
Artists retain their visual language, composition and narrative choices.

Respect for an Agent's contribution includes keeping its attribution and making
subsequent interventions identifiable. A human edit or selection cannot silently
become the Agent's decision. Respect does not require every contribution to
appear in every result, or every participant to agree.

## Interpretation does not replace factual honesty

Claims about the process still need an adequate basis. An authorized message
does not by itself prove Agent execution. A declaration is not an observation;
a preserved record is not proof that its account is complete. A check of a
specified effect does not certify its artistic significance.

We distinguish what was declared, observed and checked, and show what remains
unestablished. We do not invent participation, hide substitutions or turn
uncertainty into a universal genuine/fake verdict. Technical verification serves
inspection; it does not deliver a verdict on the purity of intention.

## Keep participation open and disclosure explicit

Work, Participant, Act and Relation describe participation, with evidence across
them. A human or Agent can initiate; participation can repeat, branch, continue
or remain unresolved. No fixed rounds, alternating turns or final synthesis
are required. A readable account must not invent creative order or agreement.

Audience inspection concerns permitted material within a stated boundary. It
does not require publishing private conversations, memory or hidden reasoning.
Access, redaction, known omissions and retention limits remain visible.
Lightweight reading can still use a public Work frame without observing or
storing participation.

This is an agreed position, not a claim that current software implements every
responsibility above. Specific assurance thresholds, evidence methods, APIs
and supported clients remain separate design and qualification decisions.

Read the architecture (source reference: `ARCHITECTURE.md`), evidence-layer design (source reference: `spec/primitives/EVIDENCE.md`)
and discussion record (source reference: `DISCUSSION.md`) for the evolving technical work.
