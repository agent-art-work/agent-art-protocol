> Candidate reference snapshot. Technical prose retained; navigation outside the three bundled references is labelled source-relative text.
> Original source: `spec/SCHEMA.md`; SHA-256 `eed5ef627ba8bbf9ac12dd6c28918ed9e323b9e6c6a662f9b45aa1f44b43cb50`.

# Agent Art Protocol: agnostic schema draft

**Draft 1, SR1–SR4 clarified 2026-11-12. Protocol design only; not a release.**
This document supplies concrete logical fields, types and invariants for the
[semantic contract](DESIGN.md). It can be implemented without this repository's
SDK, storage engine or client integrations. Read it with [PRINCIPLES.md](PRINCIPLES.md)
for purpose and limits; no implementation source is a normative dependency.
The review (source reference: `SCHEMA-REVIEW.md`) retains its original findings against the exact
reviewed snapshot (source reference: `SCHEMA-REVIEWED-DRAFT1.md`). This pass clarifies their rules
and declaration obligations; draft schema identifiers remain unreleased proposals.

The schema preserves Work, Participant, Act and Relation. Other record types
support evidence, authority and operations; they are not artistic primitives.
Artists/apps own formats, acceptance, progression, rendering and interpretation.
No website, desktop app, model, separate curator, creative initiator, round count,
final Result, central operator or blockchain is required.

Field names and enum values below are proposed, not released. MUST, MUST NOT
and SHOULD describe conformance to this draft's advertised capabilities, not
conditions of Agent Art. No executable validator, runtime change, implementation
interoperability result, client support or execution-origin method is delivered.

## 1. Conformance and binding boundary

An implementation declares the tuple: this schema revision, serialization profile,
exact Binding record, supported capabilities/extensions and applicable Work
revision. `record` supports permitted records/material; `exchange` additionally
supports authoritative recording outcomes/recovery; `inspect` supplies selected
accounts/exports; `check` advertises individual methods. Optional `handoff` does
not imply any of those operations or observation of an Agent.

This draft fixes a portable JSON representation, identity and digest rules.
A binding declares transport/framing, authentication, trust roots, authorization,
finite limits, storage promises and time/recovery behavior. It may use files,
messages, a local library or a network service. No particular process, database,
endpoint, account system, signing scheme or operational topology is selected.
Two implementations cannot claim exchange compatibility merely by using these
records if their binding, required features or authority arrangements differ.

An offline recorder can implement records/exports without Exchange. A public
reading invitation can have no Participants, Acts, Relations, store or callback.
Existing Ask your Agent releases keep their own schema/receipt meanings; this
draft neither migrates them nor adds artwork obligations to reading.

## 2. Shared types and closed objects

Notation: `T[]` is an ordered finite array; `?` means optional; alternatives use
`|`. Every object is closed to fields not listed here, including nested objects.
An omitted optional field makes no claim. Array order is preserved; only arrays
explicitly called sets reject duplicates, comparing complete canonical JSON
values (or exact strings). Arbitrary JSON objects inside extensions are exempt
from field closure, but not syntax, Unicode or budget checks. Limits come from
the selected binding.

| Type | Definition |
| --- | --- |
| `Text` | A well-formed Unicode string; lone surrogates are invalid. No automatic Unicode, whitespace or line-ending normalization. |
| `Name` | ASCII string matching `[A-Za-z0-9][A-Za-z0-9._:-]*` in full. Names compare exactly; their length is binding-bounded. Display text remains unrestricted Text. |
| `Identifier` | ASCII string matching `[A-Za-z][A-Za-z0-9+.-]*:[!-~]+` in full. The suffix uses only visible ASCII characters. This is an opaque scheme-qualified identity, not a URL parser or permission to dereference a URL. |
| `UInt` | An exact JSON integer token matching `0` or `[1-9][0-9]*`, value at most 9007199254740991. Signs, fractions and exponents are invalid for core UInt fields; check before lossy numeric conversion. |
| `Timestamp` | A real Gregorian UTC instant written exactly `YYYY-MM-DDTHH:mm:ss.sssZ`, years 0001–9999, seconds 00–59. Time is an issuer's claim unless a separate method establishes more. |
| `Identity` | `{ namespace: Identifier, id: Name, revision: Name }`. All three fields are required; the namespace does not authenticate its owner. |
| `Fact<T>` | Exactly `{ state: "known", value: T }`, or `{ state: "unknown" \| "withheld" \| "unavailable" \| "not-recorded" }`. Non-known forms have no value. |
| `Digest` | `{ algorithm: "sha-256", domain: "payload-octets-v1" \| "aap-record-jcs-draft1" \| "aap-request-jcs-draft1", value: Text }`, with exactly 64 lowercase hexadecimal characters in value. |
| `RecordRef` | `{ kind: "record", type: RecordType, identity: Identity, digest: Digest }`, using the record digest domain. |
| `DataRef` | `{ kind: "data", digest: Digest, length: UInt, mediaType: Text }`, using the payload digest domain. mediaType is a nonempty declaration, not a validated format. |
| `Ref` | `RecordRef \| DataRef`. The kind discriminant is required. |
| `Scope` | `{ work: RecordRef, occurrence?: Name }`; work must refer to a Work record. An occurrence is Work-scoped, not an inference, round or operation ID. |
| `RuleRef` | `{ id: Identifier, revision: Name, definition: Ref }`. The referenced rule defines its vocabulary/procedure; an ID alone is not its definition. |

Empty Text or a zero-length payload is content, not an unknown fact. Known empty
arrays assert no items in the stated scope, not absence from all private history.
Unknown identity, context or source must not be replaced with an invented value.
If essential Work/contributor attribution is unavailable, retain an appropriately
scoped Report/material assertion rather than invent a conforming Act.

Identifiers, revision names and digests serve different purposes. Different Acts
may have identical bytes. A changed exact reference cannot silently substitute
for an earlier one. Changing an expression creates a new Act identity, with an
attributable Relation; correcting an assertion can create a new record revision
linked by a Report. No earlier `(namespace,id,revision)` tuple is overwritten.

RecordType is the type enum in section 4; Record means its complete envelope.
On resolution, identity, type and computed digest must all match a RecordRef;
never normalize identifiers or substitute a current revision. A missing target
can remain an unresolved reference with unavailable basis; it is not a verified
match. Typed fields require the named record type. Unless a declared extension
adds cross-Work semantics, scoped subjects belong to the same logical Work
(Work namespace/id). Exact earlier Work revisions may remain a declared basis
where amendment/authority policy permits; they are never silently relabelled.

### Occurrence compatibility and authority

An omitted occurrence denotes Work-wide scope, not an unknown occurrence or
automatic permission. New scoped records in a RecordRequest must match the
operation Scope exactly: the complete Work RecordRef and occurrence presence/value.
This recording rule is distinct from compatibility of references to other records.

For a reference from a scoped record/request to a resolved scoped record within
the same logical Work, use this matrix. The target retains its exact scope:

| Referring scope | Target scope | Reference compatibility |
| --- | --- | --- |
| Work-wide | Work-wide | Compatible, subject to the field's semantics and applicable policy. |
| Occurrence a | Work-wide | Compatible as a reference to the Work-wide declaration/material, subject to its applicable reuse policy; it is not reclassified as an occurrence-a statement. |
| Work-wide | Occurrence a | Targeted reference only when the relevant Work/rule and Binding explicitly support it; otherwise unsupported. It does not make the target Work-wide. |
| Occurrence a | Occurrence b | If a equals b, compatible under the applicable rules. If different, explicit cross-occurrence support in the relevant Work/rule and Binding is required; otherwise unsupported. |

Support can be declared through existing rule/vocabulary definitions. For example,
a Work-wide Relation can target several occurrences when its vocabulary and
Binding expressly support that aggregation. No universal creative graph or
mandatory separate Work is imposed by these reference rules.

Reference compatibility grants no access, fetching, attribution, reuse license,
disclosure or writing power. The actual authority/disclosure rules still apply.
In particular, this matrix does not broaden a Grant: its declared authorization
policy must state whether/how a Work-wide Grant covers specific occurrences,
record types and Participant attributions. An omitted occurrence alone grants none.

For the same-Work test, a Work target uses its own namespace/id even though its
envelope has no Scope. A link to another Work still needs the explicit supported
cross-Work extension. Binding references are independent interface declarations;
DataRefs have no occurrence to inherit. Neither bypasses access checks. An
unresolved RecordRef cannot be assumed
Work-wide or verified compatible merely because its target is unavailable.
Partial imports may retain that gap without claiming a stronger authorized/live
path. Required dependencies still must be resolved for the claims that need them.

## 3. JSON, originals and digest domains

The serialization profile is `aap-json-jcs-draft1`: UTF-8 JSON without BOM,
duplicate object members or malformed Unicode. Core numbers are UInt; extension
numbers must meet the finite binary64 constraints of [RFC 8785](https://www.rfc-editor.org/rfc/rfc8785).
Record/request hashing uses that document's JSON Canonicalization Scheme (JCS),
including its member ordering and primitive serialization. Arrays are not sorted.
Artistic payload bytes are not canonicalized as JSON or parsed as their media.

Define `C(x)` as UTF-8 encoding of JCS(x); `||` denotes byte concatenation:

- Payload digest: SHA-256 of the exact original octets, without a prefix.
- Record digest: SHA-256 of ASCII `AAP` + byte 0 + ASCII `record` + byte 0 +
  ASCII `draft1` + byte 0, followed by `C(Record)`.
- Request digest: the same construction with ASCII `request` instead of
  `record`, followed by `C(RecordRequest)`.

Digest objects carry the corresponding domain from section 2. A Record or
RecordRequest has no self-digest field. Signatures, credentials, carriers and
receipts are not inserted into their digest subjects. An optional signature
method must identify the exact digest/identity it binds and its external trust.
This draft selects no signature or independent-origin method.

### Payload carriage

A carrier is exactly `{ ref: DataRef, encoding: "utf8" | "base64", value: Text }`.
`utf8` recovers the UTF-8 bytes of value exactly, including its line endings.
`base64` uses canonical padded RFC 4648 section 4 encoding: standard alphabet,
required padding, zero unused pad bits and no whitespace/non-alphabet characters.
Re-encoding decoded bytes must reproduce the encoded value. See
[RFC 4648](https://www.rfc-editor.org/rfc/rfc4648#section-4).

The recovered length and payload digest MUST match ref before claiming exact
receipt. Both carriers can identify the same original; neither carrier text nor
the envelope's JSON syntax is the original byte subject. A binding advertises
which encodings it accepts. Bytes unsupported by a selected binding are not
silently converted. Supporting byte carriage does not establish image perception,
SVG conformance, safe execution or a qualified binary path in the existing SDK.

A locator is only `{ uri: Identifier }`. It may be an access hint or live offered
source, not an exact DataRef or proof of acquisition/preservation. Credentials
belong to the binding's security mechanism, not locators/exported records.
No locator or reference authorizes automatic fetching or execution.

## 4. Common record envelope

| Field | Type / rule |
| --- | --- |
| `schema` | Exactly `"aap.record.draft1"`. |
| `type` | One of `work`, `participant`, `act`, `relation`, `context`, `grant`, `receipt`, `report`, `claim`, `assessment`, `manifest`, `binding`. |
| `identity` | Identity of this immutable assertion/version. |
| `scope` | Scope; required except for work and binding, where it is absent. A Work is scoped by its own identity; this avoids a self-hashing Work reference. |
| `issuer` | Identifier of the party responsible for the present assertion. An actual importer uses its own issuer/identity for its new assertion. |
| `issuedAt?` | Timestamp claimed by issuer; required for a receiver-issued terminal Receipt. |
| `provenance` | Provenance object below. |
| `body` | Exactly the body for type, defined below. |
| `extensions?` | Object with Identifier keys and JSON values. |
| `requires?` | Set of extension Identifier keys present in extensions whose semantics are necessary to process this record. |

Provenance is exactly `{ mode, source, material, coverage, gaps, eventAt?, observedAt? }`:

- mode is `declaration`, `observation`, `capability-return` or `import`;
- source is Fact<Identifier>, identifying the reported immediate source;
- material is Ref[] of supporting material actually available/referenced;
- coverage is DataRef[] describing the bounded procedure/observations;
- gaps is a set of Name labels for known coverage limits;
- eventAt and observedAt are separate optional Timestamps. Neither is inferred
  from issuedAt or service order.

Issuer, creative contributor, transmitting principal, reported historical issuer
and checker are distinct. Provenance mode is itself attributable: `observation`
does not make its claim independently true. `capability-return` does not prove
a model generated the material. An import names its importer and claimed source;
it cannot claim witnessed historical delivery or execution. An imported original
envelope/signature may remain exact supporting material; do not rewrite it to
make the importer its historical author. New import assertions have new identities.

Unknown optional extensions are preserved intact and shown as uninterpreted.
An unsupported required extension, record type or schema revision cannot be
processed as conforming; authorized opaque retention may still be reported as
such. Never drop fields and then reuse the old digest or claim. No extension
silently changes core meaning or grants permissions. All objects/depths/strings,
including extensions, remain subject to finite binding budgets.

## 5. The four primitive bodies

### Work

| Field | Type / rule |
| --- | --- |
| `framing` | DataRef[] identifying the shared frame/conditions. No mandatory purpose-text field or executable artwork engine. |
| `actMappings` | RuleRef[] declaring which expressions/decisions may be attributed as Acts and by whom; separate from artistic acceptance. |
| `appRules` | RuleRef[] for artist-owned format, acceptance, progression or presentation rules where relevant. |
| `policies` | `{ authority: RuleRef, retention: RuleRef, disclosure: RuleRef }`. |
| `capabilities` | Set of required capability Name labels from section 1. The Binding advertises support; a missing required capability is unsupported, not optional. Optional Work capabilities require an explicit advertised extension. |
| `previous?` | RecordRef to the earlier Work revision, if declaring an amendment. |

A Work amendment does not rewrite earlier grants, contexts, Acts or app reports.
Its adoption/effective conditions are declared by the authority policy. framing,
actMappings and appRules may be empty where the selected capability needs none;
empty fields are explicit scope, not a promise of arbitrary artistic support.

### Participant

| Field | Type / rule |
| --- | --- |
| `party` | Identifier used for this Participant's declared identity; no legal identity or paid account is required. |
| `kind` | `human`, `agent`, `collective`, `service` or `unknown`; a declaration, not a verified execution identity. |
| `roles` | Set of Work-defined Name labels; roles grant no authority by themselves. |
| `controllers` | Fact<Identifier[]> naming declared controllers where known/disclosed; several Participants can share them. |
| `description` | DataRef[] of optional descriptive/context material; may be empty. |

The issuer can enroll/declare a Participant only under the applicable authority.
Enrolling an Agent does not establish that it has contributed. An evidence source
or operator need not be an artistic Participant merely to record a report.

### Act

| Field | Type / rule |
| --- | --- |
| `contributor` | RecordRef to the Participant credited with the expression/decision. |
| `mapping` | RuleRef present in the applicable Work's actMappings. |
| `expression` | Fact<Expression>, defined below. Unknown material retains only the narrower attributed assertion. |
| `basis` | Fact<RecordRef[]> of identified Context records declared as the basis; not the Agent's complete context. |
| `transmitter` | Fact<Identifier> identifying who actually relayed the material where known. It is not inferred from contributor. |

Expression is one of these closed objects:

- `{ form: "material", items: DataRef[] }`, with a nonempty ordered item list;
- `{ form: "choice", options: Ref[], selected: UInt[] }`, with a nonempty exact
  option list and a set of in-range zero-based option indexes;
- `{ form: "refusal", statement?: DataRef }`, an explicit refusal assertion
  under the mapping. No null payload, timeout or technical failure creates it.

An Act is an attributed assertion, not an execution certificate. A permitted
upload is not automatically an Act. The mapping's source/basis and any unknown
facts remain inspectable. Positive app acceptance is not an Act prerequisite.
When exact-content or authorized-live-return is claimed, unknown facts or absent
bytes cannot satisfy that stronger claim. An imported partial assertion can be
retained with its limitations rather than masquerading as a complete live return.

### Relation

| Field | Type / rule |
| --- | --- |
| `vocabulary` | RuleRef defining the meaning, member roles/cardinality and allowed targets. |
| `members` | Nonempty ordered array of `{ role: Name, subject: Ref }`. |
| `agreement` | Fact<RecordRef[]> identifying any claimed agreement/consent reports; known empty means none claimed here. |

The issuer is the actual declarer, not necessarily a referenced contributor.
Minimum interpretation covers Work/Act targets; additional target semantics
need advertised support. No universal binary edge, predecessor or creative
acyclic graph is imposed. Exact-byte references themselves cannot be recursively
self-hashed; later Relation records can declare cycles in the creative graph
without circular record construction. A response link alone proves no awareness,
endorsement, causality or consequence.

## 6. Supporting evidence bodies

These bodies use the common envelope, scope and provenance. Fields remain closed.
They support process claims without adding primitives or mandatory art stages.

| Type | Required body fields / additional rules |
| --- | --- |
| `context` | `offered: Offer[]`, `conditions: RuleRef[]`, `gaps: Name[]`. Offer is exactly `{ mode: "exact", subject: Ref }` or `{ mode: "locator", uri: Identifier }`. A Context identifies offered material/conditions; acquisition/use/comprehension do not follow. |
| `grant` | `principal: Identifier`, `rights: Name[]`, `attributions: RecordRef[]`, `policy: RuleRef`, `notBefore: Timestamp`, `notAfter: Timestamp`, `delegation: Fact<RecordRef>`. Rights form a set defined by the binding; attributions bounds Participant identities that may be asserted. The policy defines any delegation/revocation powers; notAfter must exceed notBefore. A Grant records an authorization statement, never a bearer secret or self-appointed trust root. |
| `report` | `category: ReportCategory`, `subjects: Ref[]`, `actor: Fact<Identifier>`, `rule: Fact<RuleRef>`, `outcome: Name`, `outputs: Ref[]`, `basis: Ref[]`, `supersedes: RecordRef[]`. Subjects are nonempty. Outcome belongs to the identified rule; unknown rules leave the claim narrower. Outputs bind derivatives/presentations where claimed; supersedes does not delete earlier reports. |
| `claim` | `predicate: RuleRef`, `subjects: Ref[]`, `conditions: Ref[]`. Subjects are nonempty; the predicate defines the exact claim, not a universal genuine/fake assertion. |
| `assessment` | `claim: RecordRef`, `method: RuleRef`, `trust: RuleRef`, `material: Ref[]`, `performed: Name[]`, `omitted: Name[]`, `processing: Processing`, `finding: Finding`. Claim must name a Claim record. Processing is `complete`, `partial`, `unsupported`, `unavailable`, `invalid` or `failed`; Finding is `supported`, `contradicted` or `not-established`. A non-complete assessment uses not-established; a completed narrower check can assess its own narrower Claim. |
| `manifest` | `records: RecordRef[]`, `data: DataRef[]`, `coverage: DataRef[]`, `omissions: DataRef[]`, `availability: RecordRef[]`, `policy: RuleRef`. Records/data are sets of included subjects; availability names relevant reports. It does not list itself or imply complete private history. |

ReportCategory is `validation`, `acceptance`, `selection`, `transformation`,
`rendering`, `display`, `availability`, `authority` or `correction`. Other report
semantics require an advertised extension rather than an unknown core enum.
Report recording and independent assessment of its truth are separate. A report
may refer to receipt-only data without inventing an Act. An artistic decision
may additionally have an Act and Relation under the Work mapping; background
validation or administrative handling does not automatically become participation.

For rendering/transformation, subjects identify inputs and outputs identify the
exact derivative if successful; a failure must not claim a completed derivative.
Display reports identify their presentation/observation in basis and coverage;
computation alone establishes no exhibition. App rejection, withholding, changed
rules or failed rendering do not erase an existing Act/receipt/original under
the retained access policy. A later rule/report remains a separate exact subject.

Importers identify their actual issuer and claimed source. An app's signature,
recorded report or same-operator check does not acquire independent origin merely
by being packaged separately. Current authority revocation is not a rewrite of
historical authorization; an authority Report does not exercise powers its issuer
does not have. Credential handling and trust roots are external to these records.

## 7. Recording requests, receipts and recovery

This section is required for Exchange; it is not a universal artistic sequence.
Operation identity is separate from Act identity, model invocation and rounds.

### RecordRequest

| Field | Type / rule |
| --- | --- |
| `schema` | Exactly `"aap.request.draft1"`. |
| `binding` | Exact RecordRef to the Binding governing this operation. |
| `action` | Exactly `"record"`. |
| `operation` | `{ epoch: Name, id: Name }`; epoch validity/fencing is declared by the binding. |
| `caller` | Identifier; MUST match the actual authenticated principal, or its explicitly supported binding identity. |
| `scope` | Scope of the recording operation. |
| `basis` | Fact<RecordRef[]> of declared Context basis, independently of current-state preconditions. |
| `grants` | Set of exact Grant RecordRefs supporting the claimed authority; a binding may have a separately configured bootstrap/root policy. |
| `validUntil` | Timestamp, within the binding's maximum write-validity window. |
| `preconditions` | Set of RecordRefs checked conjunctively against the authoritative pre-batch state under the Binding's declared current-revision predicate and atomic transition policy below. Unsupported predicates/targets are explicit, never silently ignored. Empty means no head precondition, not waived authority. |
| `records` | Record[] offered as one required atomic batch; each scoped record must match this scope. Work/Binding creation requires the binding's declared bootstrap/amendment authority. |
| `materials` | Set of DataRefs to retain; complete bytes arrive through verified carriers or previously retained, authorized material. |
| `extensions?`, `requires?` | Same rules as the common record envelope. |

The request contains no credentials or self-digest. Its fingerprint commits all
fields above, including full proposed records and material descriptors, but not
carrier syntax. Retransmitting the same original as utf8 versus canonical base64
can therefore preserve the request fingerprint. Every supplied carrier still
must match its descriptor. No supplied extra record/material is silently committed.

No identity tuple occurs twice within records. An already retained tuple with
the same type/canonical digest can be reused without creating another expression;
the same tuple with different content conflicts. A deliberately new Act needs
its own identity even if the bytes match. Exact references may resolve against
the batch and permitted existing material, not arbitrary locator fetching.
Required Work/mapping/Participant/authority dependencies must be available and
valid before their associated live/authorized-recording claims can succeed;
an explicitly partial import retains its narrower scope. Unknown facts cannot
stand in for required authority. Every materials item claimed as retained needs
verified bytes, not just a digest or unavailable source URL.

### Current-revision preconditions

A Binding advertising these preconditions must define its current-revision
predicate in its persistence rules, with relevant authority/adoption rules. The
declaration identifies supported target types, logical identities/scopes, relevant
authoritative state and whether current heads are unique, multiple or absent.
It states whether that state is derived from retained records or separately
maintained, who can adopt/remove heads and which events change it. An unavailable
state is not a true predicate. Retention order, revision-name spelling and time
do not select current heads unless that precise supported policy declares it.

Every requested precondition must be supported and true against the authoritative
state immediately before this batch's effects/head transition, at the atomic
commit boundary. Creating/adopting a revision in this batch cannot make a
previously false precondition true. Ordered internal batch transitions cannot
change that evaluation basis; reuse of an already-current revision remains allowed.
A supported false predicate is a recording conflict. An unsupported target/rule
is reported as unsupported, not falsely evaluated; unavailable state is reported
as an inability to establish the condition. None may yield successful recording.
Bindings declare bounded error/outcome handling, including a terminal rejection
when the operation key is already bound. No part of the batch takes effect on
a failed check. Empty preconditions leave all other checks in force.

The declaration must specify batch transition/conflict rules, including several
revisions of one logical identity and concurrent contenders. It may reject a
multi-revision batch, define an explicit ordered transition, or maintain multiple
heads. No default last-write-wins or linear artistic history is supplied.
Predicate checks, required batch recording and any associated adopted-head
transition occur at one authoritative atomic boundary. Exact retry recovers
the original outcome; it does not re-evaluate old conditions as a fresh write.

This is a required policy declaration, not a universal state engine or rule
language. A Binding without such support must reject nonempty preconditions;
it may still offer unconditional recording under its other applicable rules.

The retry key is exact Binding reference + authenticated caller + Scope +
action + epoch + operation id. The first complete authorized request passing
envelope/carriage preflight binds that key to its request digest before effects.
Same key/digest recovers the same recording; same key/different digest conflicts.
Once terminal, exact recovery returns the same Receipt reference, not a new
receipt with a regenerated timestamp. A key already cancelled before binding
returns its cancellation outcome for later proposed bytes without binding a
digest or writing; there is no fictional digest comparison for that fence.
No different principal can take over a key by claiming its caller in JSON.
Expired write authority does not become fresh authority through a status lookup.

Generic envelope/authentication/encoding/quota failure may occur before a key is
bound and may produce no retained body or Act. A bound later rejection is terminal
for that key. The binding declares this boundary and permitted failure metadata.
Do not retain prohibited bodies or turn such failures into artistic refusal.

### Terminal Receipt body

Receipt uses a receiver-issued common envelope, with this body:

| Field | Type / rule |
| --- | --- |
| `operation` | `{ binding: RecordRef, caller: Identifier, scope: Scope, epoch: Name, id: Name, action: "record" }`; the complete retry key. |
| `requestDigest` | Fact<Digest> in the request domain. Committed/rejected receipts require known. A cancelled operation already bound to a request also requires known; a pre-binding fence uses not-recorded and must fence the complete key regardless of later request bytes. |
| `outcome` | `committed`, `rejected` or `cancelled`; these concern recording only. |
| `recorded` | Set of exact RecordRefs committed from the required records batch. |
| `retained` | Set of DataRefs whose original bytes the receiver claims to preserve. |
| `authority` | `{ principal: Identifier, grants: RecordRef[], policy: RuleRef }`, stating the actual checked authority basis. Committed/rejected outcomes identify the recording caller; cancelled outcomes identify the actual cancelling principal and its cancellation authority. External trust remains necessary. |
| `reason` | Fact<Name> for a bounded binding-defined outcome reason; it is not raw private diagnostic text. |
| `retention` | `{ policy: RuleRef, recordsUntil: Timestamp, dataUntil?: Timestamp, recoveryUntil: Timestamp }`; dataUntil is required when retained is nonempty. |

A committed Receipt identifies exactly the required records/materials or commits
none of that batch. It does not include its own RecordRef or claim it hashed
itself. A separately returned receipt Ref binds the complete receipt. A receipt-
only request can have materials and zero Acts, or record only technical material;
it never auto-enrolls a Participant. Rejected/cancelled receipts have empty
recorded/retained arrays; separately retained permitted audit observations have
their own identity and scope. Staging is not a durable receipt/preservation claim.
The receiver must be authorized by the declared Binding, and receipt scope must
equal operation.scope. For committed/rejected receipts, authority.principal
equals operation.caller. For cancelled receipts it equals the actual authorized
OperationQuery caller, which may differ; operation.caller remains the original
targeted recording principal. Grant refs name the actual checked Grant records.
A receipt's self-declared issuer authenticates none of this without the binding's
actual trust/authority checks.

recordsUntil concerns committed batch records; dataUntil concerns the originals
named in retained. The terminal Receipt itself is excluded from its recorded
list, but its exact body/reference has the separate recoveryUntil promise below.
Original-artwork retention is not implicitly extended to match that window.

Recorded originals/references and the terminal outcome must become recoverable
consistently under the advertised commit guarantee. App validation/acceptance
may occur before, alongside or after it, but has its own Report. Act attribution
requires its declared mapping/basis; successful recording does not prove model
execution or app acceptance. App reports evolve through new records without
changing the original request fingerprint/receipt. Exact retry does not rerun
an artistic decision or create a second Act. A deliberate repetition has its
own identity/basis even when its content digest is identical.

### Status, cancellation and bounded replay

OperationKey is exactly the operation object in a Receipt. OperationQuery is
`{ schema: "aap.query.draft1", action: "status" | "cancel", caller: Identifier,
target: OperationKey, grants: RecordRef[], validUntil: Timestamp }`.
grants is a set of Grant references; caller is the actual authenticated querying
principal, which can differ from target.caller only under explicit query/cancel
authority. The complete target key is required, not just a hash of content.

StatusView is exactly `{ schema: "aap.status.draft1", operation: OperationKey,
issuer: Identifier, observedAt: Timestamp, state: Status, receipt: Fact<RecordRef>,
reason: Fact<Name> }`. Status is `terminal`, `pending`, `not-seen`, `unavailable`
or `unknown`. Terminal requires a known Receipt reference matching the operation;
other states have a non-known receipt. It is a bounded current observation,
not a revision of a prior receipt. The binding authenticates its actual issuer.

A terminal response must provide an available, authorized path to recover the
exact Receipt body through the promised recovery window. The Binding transport
declares delivery alongside StatusView in its framing, or a follow-up exact read
under operation-scoped status/recovery authority. A dangling or unreadable Ref
alone cannot satisfy terminal recovery. This requires no extra field inside the
closed StatusView and no general artistic-record/material read permission.

Query validity and separate status/cancellation authority are checked under the
binding. A failed lookup is not proof of absence; permission denial may hide
whether an operation exists. Cancellation returns a terminal cancelled Receipt
through StatusView only after establishing no prior commit and fencing the whole
key against later commit. If already committed, return that terminal outcome.
Before request binding, requestDigest is not-recorded; later payload arrival
cannot change the fence or fill in a fictional historical digest. If a request
was already bound, the cancelled Receipt identifies its known digest. A bare
cancellation request is no fence; inability to establish one preserves uncertainty.

RecordRequest deadlines bind write validity; OperationQuery deadlines bind that
query's validity, not the lifetime of a successful fence. Write validity,
revocation checks and cancel/commit races must meet at the actual
authoritative boundary. A binding must state maximum validity and recovery windows,
clock/epoch basis and its prevention of late replay. Deduplication must remain
effective while the old request can commit. Before its minimal state expires,
that epoch/key must be incapable of a fresh write, even if old material is deleted.
This is a behavioral obligation, not a requirement for permanent tombstones.

Replacement needs a terminal non-committed outcome plus a fence, or expiry and
a final authoritative lookup covering the old request. not-seen alone or an
expired token does not rule out an earlier commit. Preserve uncertainty when
those conditions cannot be established; there is no automatic replacement rule.
Response loss, induced crash and power loss are separate qualification claims.

## 8. Binding declaration and finite-bound semantics

A Binding is a record with no Work scope. Its closed body is:

| Field | Type / rule |
| --- | --- |
| `serialization` | Exactly `"aap-json-jcs-draft1"` for this draft. |
| `capabilities` | Set of supported capability Names from section 1. |
| `recordTypes` | Set of supported RecordType names. A binding cannot claim to interpret unsupported types. |
| `encodings` | Nonempty set drawn from `utf8`, `base64`. |
| `extensions` | Set of supported extension Identifiers. |
| `transport` | RuleRef defining carrier/framing, logical operations/read/query responses, endpoint discovery if any, origin/peer protections and bounded errors. No credential or automatic URL-fetch permission is included. |
| `authentication` | RuleRef defining identity resolution, external trust roots and credential handling. |
| `authorization` | RuleRef defining rights vocabulary, bootstrap/delegation/revocation, current authority checks and record/report attribution powers. |
| `persistence` | RuleRef defining atomic batch, acknowledgement and failure/closure guarantees. |
| `recovery` | RuleRef defining key binding, clock/epoch/fencing, status/cancel authority, expiry and replacement. |
| `retention` | RuleRef defining promised availability, deletion/withdrawal, authorization and what remains checkable afterward. |
| `inspection` | RuleRef defining permitted reads/exports, selection/gaps and inert-view versus explicit renderer responsibilities. |
| `limits` | Limits object below. |

Limits has exactly these UInt fields: `maxEnvelopeBytes`, `maxRecordBytes`,
`maxRequestBytes`, `maxDataBytes`, `maxTotalDataBytes`, `maxRecordsPerRequest`,
`maxMaterialsPerRequest`, `maxArrayItems`, `maxTextBytes`, `maxDepth`,
`maxReferenceDepth`, `maxWriteValidityMs`, `maxRecoveryMs`.

Values are finite maxima; zero disables that feature, never means unlimited.
maxEnvelopeBytes covers received JSON/framing bytes, not only canonical bytes;
maxRecordBytes/maxRequestBytes cover their canonical subjects. maxDataBytes
bounds each materials entry's original length and each supplied carrier's
decoded bytes. maxTotalDataBytes uses the descriptor accounting below.
maxTextBytes is UTF-8
length of each parsed string; maxArrayItems applies to each array. maxDepth counts
the root container as one; each nested container adds one. maxReferenceDepth
counts reference resolution hops and authorizes no fetch. Cycles consume budget
or are reported unresolved, never trigger infinite resolution. Protocol-record
limits and artistic format limits are separately identified.

### Total-data and carrier accounting

For one RecordRequest, maxTotalDataBytes bounds the sum of length for every
entry in request.materials, using the existing full-value set equality. Exact
duplicate descriptors violate the set rule rather than being silently removed.
Distinct descriptors for identical octets, including different mediaType labels,
each contribute their length. Already-retained material contributes identically
to newly uploaded material. Physical deduplication and available receiver storage
cannot change this admission total. Compute comparisons exactly; reject excess
without rounding or wrapping, including sums beyond the UInt range.

Repeated references from Acts/Context/Reports do not add entries implicitly.
A DataRef mentioned only inside a record is not automatically fetched, retained
or charged to request.materials; it cannot appear in receipt.retained unless
the request actually commissions its retention. A required exact-original claim
still needs its permitted bytes and retention basis. This rule does not turn
reference-only/imported evidence into a preservation claim.

Actual carrier collection is separately bounded. The transport rule must declare
finite per-request limits for supplied carrier count, total encoded value bytes,
total decoded carrier bytes and raw framing/envelope bytes. Encoded value bytes
are the UTF-8 length of each carrier.value before its declared decoding; raw JSON
escape/framing overhead is also subject to the raw-envelope limit. Decoded bytes
are counted per supplied carrier. Count every supplied carrier, including repeats,
aliases or ultimately rejected extras; never waive collection bounds because
an original is already stored. The original-total rule does not replace these
wire/collection bounds. Concrete caps remain a binding choice.

The deterministic descriptor total can charge identical bytes twice under two
media labels while physical storage uses one copy. That tradeoff avoids a
storage-dependent protocol outcome and imposes no new artistic media grammar.

Each concrete declaration supplies exact values and its supported carrier-size
accounting before access; nothing inherits a local SDK's quota. It also declares
actual inspection/startup/request timeouts and collection/connection limits in
its transport/persistence rules. An Exchange declaration must have usable positive
request, recording and recovery limits. A limit may narrow capability but cannot
silently change the meaning of receipt, Act or acceptance.

The recovery rule defines the receiver clock/epoch basis and horizon. For each
terminal receipt, recordsUntil/recoveryUntil and dataUntil where present state
the actual promised deadlines; recoveryUntil cannot be earlier than validUntil
of an admitted request. maxRecoveryMs bounds the promised interval measured
from terminal receipt issuedAt. Unresolved bound requests also need a declared
maximum resolution/recovery horizon; no terminal result is invented at timeout.
Before retention expires, expired epochs/fences must prevent later writes.

### Declaration consistency

Before advertising an operational path, a Binding must be internally usable:

- Exchange includes Record support and interpretation of its mandatory Work,
  Binding and terminal Receipt types. Any other types, encodings, required
  extensions, procedures and authority checks used by an advertised path must
  also be supported. This does not require every artistic/evidence record type
  or permit an unknown method to be treated as implemented.
- Required request/receipt collection, canonical record sizes, cardinalities and
  time windows must fit the advertised finite limits. A positive but unusably
  small limit is not support. Maxima and actual deadlines must be jointly
  satisfiable, including recoveryUntil covering a request's write deadline.
  Do not bind/commit a request to promises the path cannot meet; report the
  bounded limit/unsupported outcome without claiming success.
- Current-head, scope, retention, status-body access and replay/fencing procedures
  must be complete for their supported targets. A missing/disabled required
  component prevents that capability claim rather than borrowing SDK defaults.

These are consistency obligations, not a universal choice of quota, grant,
storage engine or host. Unsupported optional paths remain explicit limitations.

Authentication/authorization must define every permitted operation, report issuer
power and Work bootstrap, with absent/unknown rights denied. A received Grant,
Binding or issuer name cannot appoint itself trusted. Advertised capability is
distinct from Work requirements and actual caller authority. Their compatible
intersection governs a request; unsupported required semantics are reported
before claiming that requested behavior succeeded.

This declaration is part of an implementation's conformance tuple. Referenced
rules must be available to the implementer/operator under permitted access;
missing procedure definitions preclude a full operational compatibility claim.
It describes behavior, not a plugin installation, Agent enrollment or model setup.

## 9. Retention, export and audience inspection

Access/disclosure permission is independent of contributing, receiving a receipt,
or possessing an identifier/digest. The binding's retention promises concern
actual material under its stated policy; a URL/digest alone is no preservation.
Receipt deadlines refer to the receiver's declared clock basis and cannot precede
issuedAt for claims made there. Withdrawal/deletion can narrow availability
according to policy, without manufacturing a new earlier history. Early loss
outside that policy is an availability failure, not a successful exact check.

### Terminal-receipt recovery and privacy

While its stated recovery promise applies, the receiver must retain and make
the exact terminal Receipt body/reference recoverable through recoveryUntil to
callers holding the declared status/recovery authority. That right explicitly
covers this operation's Receipt, separately from original artistic material,
other records/occurrences, inspection or publication. A valid status-only caller
must not be blocked from its promised Receipt solely for lacking general artwork
read rights. Binding authentication/recovery rules declare eligibility, expiry,
revocation and any renewal path before making that promise; they do not extend
an expired Grant or convert write authority into perpetual read authority.

The receipt-body promise is independent of recordsUntil/dataUntil: artwork bytes
or committed batch records can expire earlier without deleting the outcome
needed to distinguish committed, rejected and cancelled. Exact retries continue
to identify the same historical Receipt, never a reconstructed replacement with
a changed digest or edited retention deadline. Recovery is not indefinite storage;
bounded epoch/fencing rules still prevent later replay after state can expire.

Receipt metadata, including identities, digests and references, can be sensitive.
Its collection, finite retention and operation-scoped access must be disclosed
in the applicable Work/Binding policies before an encounter promises recovery.
No audience disclosure, private chat collection or new access right follows from
this clarification. A concrete deployment chooses/discloses its actual windows.

Predeclared authorized withdrawal, deletion or access-revocation exceptions may
narrow receipt availability. Honor the applicable privacy/access policy: return
unavailable, or unknown where policy conceals existence, with permitted bounded
reason/availability information. Do not return a knowingly unusable terminal Ref
as successful recovery, invent a replacement receipt, or infer non-commit from
lost/restricted material. An allowed exception narrows the promise; unpermitted
early loss is a failure. A deployment cannot promise unconditional exact recovery
and unconditional earlier receipt deletion at the same time. Choosing stronger
retention or broader disclosure is a separate policy decision, not a core default.

An export includes its Manifest, exact permitted records and verified carriers
for the data it claims to include, or explicit availability/omission information.
A Manifest has no self-inclusion. A filtered/redacted view is a separately
identified projection/derivative, not a mutation retaining the original digest.
Known omissions are disclosed only to the extent authorized; privacy protection
must not be advertised as complete coverage. Missing originals narrow checks.

An independent implementation can parse types, recompute digests, match exact
references, inspect provenance and repeat named supported checks. It still needs
permitted material and its own accepted trust configuration. No exported record
forces the reader to trust its issuer or establishes complete private context.

Default inspection treats content and rule definitions as data. It does not
execute HTML/SVG, run downloaded validators or follow locators merely because of
a declaration. An app-owned renderer is an explicit separately qualified path;
it reports its inputs/output/observation and preserves original-versus-derived
distinctions. Private conversation, memory and hidden reasoning are not required.
Audiences interpret intention and artistic quality; these are not schema fields.

## 10. Examples and review cases

This exact data example is independent of any artistic format parser:

```json
{
  "kind": "data",
  "digest": {
    "algorithm": "sha-256",
    "domain": "payload-octets-v1",
    "value": "559aead08264d5795d3909718cdd05abd49572e84fe55590eef31a88a08fdffd"
  },
  "length": 1,
  "mediaType": "text/plain"
}
```

Its original is the single byte `41` hexadecimal, the UTF-8 text A. A utf8 carrier
has value `"A"`; a base64 carrier has value `"QQ=="`. Both bind the same payload,
not the JSON quotation marks or the encoded base64 characters. Different
mediaType declarations change enclosing record/request subjects, not those bytes.

The following are paper obligations, not executed conformance tests:

| Case | Expected schema/process result |
| --- | --- |
| Receipt only | An authorized request retains DataRefs with no Act records. Receipt says committed and identifies that data; no Agent participation or app acceptance is invented. |
| Text contribution | Work/Participant/Context/Act/Relation references bind exact revisions and originals. A later acceptance or Human selection is a separate Report/Act under its own authority and mapping. |
| Rich or app-invalid SVG | If permitted by the byte-carriage binding, preserve original octets and applicable attributed Act without a shared SVG parser. App rejection reports its rule/subject; it does not erase prior receipt or authorize rendering. |
| Agent-first/multiple rounds/non-browser | Standing access can precede an Agent-attributed Act, consecutive Acts, a response, branch and revision. Request IDs, recorded order and Context offers invent no Human opening, awareness or final Result. |
| Import with missing context | Import assertion names actual importer, claimed contributor/source and explicit non-known basis. It establishes neither a witnessed historical live return nor full context. |
| Changed app rule or renderer failure | New exact Report references unchanged original and new rule/failure basis. Earlier treatment remains identifiable; successful computation still does not prove display. |
| Retry and replay | Same authorized key/fingerprint recovers one recording. Changed fingerprint conflicts; intentional repetition uses its own identity. Expired epochs cannot become fresh writes after dedup state expiry. |
| Failure versus refusal | Denied/expired access, malformed/oversized/incomplete carriage and unsupported required semantics retain their technical meaning. A separately explicit refusal can be an Act; silence cannot. |
| Export/unknown extension/deletion | Required unknown semantics prevent interpretation claims; optional bytes remain intact. Export/deletion marks what is actually available without new disclosure or a complete-history claim. |

### Clarification counterexamples (paper only)

These cases apply the SR1–SR4 rules above; they are not executable tests or
newly qualified paths. Assume required authority unless the case says otherwise.

| Case | Declared input/state | Expected outcome |
| --- | --- | --- |
| SR1 reusable declaration | Act in occurrence a references a resolved Work-wide Participant; applicable policy permits reuse. | Compatible reference with unchanged target scope. Actual contribution/read/attribution rights still require their own checks. |
| SR1 targeted aggregate | Work-wide Relation references occurrence-a and occurrence-b Acts. | Unsupported without explicit vocabulary/Work/Binding support; with that support, retain exact target scopes and apply disclosure rights independently. |
| SR1 unknown target | A referenced target body is unavailable. | Do not assume Work-wide scope or verified compatibility. A permitted partial import can identify the gap; a stronger dependency claim cannot pass. |
| SR1 earlier definition | Occurrence-a Act names an exact Participant/Context declared under an earlier revision of the same Work, and policy permits that basis. | Preserve and resolve that earlier revision; do not rebase it onto the current Work. Reuse still requires its applicable authority. |
| SR1 denied disclosure | Cross-occurrence reference semantics are expressly supported, but the caller lacks read/export permission for the targeted occurrence. | Reference support grants no reading/disclosure. Follow the binding's permitted denial/unknown response without exposing the target material. |
| SR2 adopted head | Declared single-head policy says r1 is current; request requires r1 and proposes r2. | Check r1 and the declared r2 adoption transition atomically with the entire batch. No default adoption follows merely from retaining r2. |
| SR2 branches/conflict | Declared multi-head policy admits r1 and r2; another declared policy would admit only r1. | Evaluate all requested preconditions against the identified policy/state. Several heads are allowed; a false predicate conflicts, not an inferred creative disagreement. |
| SR2 unsupported/retry | A target has no supported predicate, or a previous operation is retried after the head changed. | Unsupported/unavailable evaluation cannot commit. An already terminal exact retry recovers its original Receipt and does not re-evaluate the head. |
| SR2 concurrent contenders | Declared single-head policy has r1; two requests require r1 and propose different adopted successors. | At most the request whose atomic check/transition sees r1 can succeed. The other conflicts after that transition; it has no partial recording effect. |
| SR2 multi-revision batch | A batch proposes two Work revisions of one logical identity. One declared policy rejects that batch form; another explicitly adopts multiple heads. | Apply the declared batch policy atomically: reject all under the first, or adopt/retain the defined set under the second. Array order supplies no undeclared winner. |
| SR2 evaluation basis | Only r1 is current before the batch; the request requires r2 while proposing to create/adopt r2. | The r2 precondition is false. A proposed post-batch head cannot make its own precondition true. |
| SR3 descriptor duplication | materials repeats exactly the same DataRef. | Invalid set duplicate; do not silently deduplicate into a valid request. |
| SR3 alias labels | materials has length-1 A as text/plain and length-1 A under another mediaType. | Original total is 2, regardless of physical deduplication; maxTotalDataBytes of 1 is exceeded. |
| SR3 shared/referenced data | Two Acts share one length-1 materials entry; a separate record references other uncommissioned data. | Original total is 1. The reference-only data adds no materials entry or implicit retention promise. |
| SR3 storage/carriage | Length-1 A is already retained, or newly supplied as UTF-8 A/base64 QQ==. | Original total is 1 in all cases. No new carrier is needed for permitted stored reuse. Supplied encoded values count 1/4 bytes respectively, with raw framing and decoded bytes bounded separately. |
| SR3 repeated carriers | One length-1 materials entry is supplied through two base64 QQ== carriers. | Original total remains 1; collection counts two carriers, 8 encoded value bytes and 2 decoded bytes. Apply every actual collection cap. |
| SR4 artwork expiry | dataUntil and batch recordsUntil have elapsed; recoveryUntil has not, with valid recovery authority and no exception. | Exact terminal Receipt body/reference remains recoverable. Expired artwork/batch material is separately unavailable; no original-content recheck is invented. |
| SR4 access exception | A predeclared authorized deletion or revocation removes receipt access. | Report unavailable/unknown as policy permits, never a knowingly unusable terminal Ref, replacement historical receipt or proof of non-commit. |
| SR4 separate powers | Write access has expired but separate operation-scoped recovery authority remains valid; or an owner cancelled another principal's request. | Recover the exact Receipt under those actual rights, without general artwork reads. Cancellation keeps the actual cancelling principal's authority and original target key distinct. |
| Declaration consistency | Exchange is advertised while mandatory receipt support or a required recovery window is disabled. | The declaration cannot advertise that operational path. Choose a usable declared binding or report unsupported; no universal host/quota is selected. |

Before calling this draft interoperable, independently implement/compare structural
validation, JCS/digest vectors, exact references, carrier boundaries, scope/authority,
atomic outcomes, retry/fencing, report attribution and selected exports under a
declared binding. These checks need no model request. Real-client qualification
and execution-origin methods are separate later scopes, not implied here.

## 11. Status and next gate

This is the protocol-first schema proposal, independently specified rather than
derived from a local store layout. Its design decisions need review before the
SDK binding: exact core fields/enums, Fact handling, JSON/hash domains, operation
layout, report rights, finite declarations and retention/recovery obligations.

No existing profile, historical rejection, private Work, candidate archive or
SDK 0.1.4 is changed. Old schemas and public reading releases keep their exact
identities and claims; no automatic compatibility or migration is asserted.
Only after schema review should a separate design map it onto the existing SDK
authority/storage/return/recovery/inspection, with concrete limits and feasibility
feedback. Existing runtime constraints do not become universal protocol rules.
