// ARTIST-OWNED EXAMPLE. Invented policies, identities and expressions only.
// Uses installed public SDK imports; no repository paths, model or renderer.
import { LIMITS, TYPES, payloadReference, recordReference } from '@agent-art/artwork-sdk';
import { ParticipationOwner } from '@agent-art/artwork-sdk/owner';
const j = JSON.stringify, known = value => ({ state: 'known', value }), absent = () => ({ state: 'not-recorded' });
const ref = record => recordReference(j(record)), end = (clock, ms) => new Date(Date.parse(clock()) + ms).toISOString();

export function createWorkApplication(config, directory, clock) {
  const root = `urn:example:${config.id}:artist`, receiver = `urn:example:${config.id}:receiver`, principal = `urn:example:${config.id}:curator`;
  const namespace = `urn:example:${config.id}`, identity = id => ({ namespace, id, revision: 'v1' });
  const definition = 'INVENTED LOCAL FIXTURE. ' + config.title + '\n' + config.premise
    + '\nAgent room: may contribute, revise or explicitly refuse. No mandatory ending or fixed rounds.'
    + '\nAuthority: operator-declared enrollment and test-only scoped identity; no independent model-origin verification.'
    + '\nCapture: receiver records the exact transmitted expression attributed to the declared Agent.'
    + '\nRetention: one-hour record/data promises, seven-day recovery after the five-minute write deadline; no audience.'
    + '\nApp decisions are separately declared. Text/SVG source is not rendered or validated as an artistic format by the SDK.';
  const definitionRef = payloadReference(definition, 'text/plain'), rule = id => ({ id: `urn:example:rule:${id}`, revision: 'v1', definition: definitionRef });
  let workRef;
  const record = (type, id, body) => ({ schema: 'aap.record.draft1', type, identity: identity(id),
    ...(!['work', 'binding'].includes(type) ? { scope: { work: workRef } } : {}), issuer: root, issuedAt: clock(),
    provenance: { mode: 'declaration', source: known(root), material: [], coverage: [], gaps: ['invented-fixture', 'operator-controlled'] }, body });
  const work = record('work', 'work', { framing: [definitionRef], actMappings: [rule('expression')], appRules: [rule('app-decision')],
    policies: { authority: rule('authority'), retention: rule('retention'), disclosure: rule('disclosure') }, capabilities: ['record', 'exchange', 'inspect'] });
  workRef = ref(work);
  const agent = record('participant', 'agent', { party: `urn:example:${config.id}:agent`, kind: 'agent', roles: ['participant'], controllers: known([principal]), description: [] });
  const human = record('participant', 'human', { party: principal, kind: 'human', roles: ['curator'], controllers: known([principal]), description: [] });
  const binding = record('binding', 'binding', { serialization: 'aap-json-jcs-draft1', capabilities: ['record', 'exchange', 'inspect'],
    recordTypes: [...TYPES], encodings: ['utf8'], extensions: [], transport: rule('raw-method-fixture'), authentication: rule('inert-identity-fixture'),
    authorization: rule('authority'), persistence: rule('single-owner-sqlite'), recovery: rule('exact-recovery'), retention: rule('retention'),
    inspection: rule('selected-inert-account'), limits: { ...LIMITS } });
  const setup = { work, binding, owner: root, receiver, mappingRules: [rule('expression')], relationRules: [rule('revises')],
    bootstrapUntil: end(clock, 7200000), policy: { writeMs: 300000, recordsMs: 3600000, dataMs: 3600000,
      recoveryMs: 604800000, maxActive: 4, maxEntries: 20 } };
  const state = { owner: ParticipationOwner.initialize({ directory, setupJson: j(setup), clock }), currentContext: null };
  const expectedIdentity = state.owner.describe().identity;
  state.owner.enroll(j({ principal, participant: agent, terms: rule('fixture-consent'), notAfter: end(clock, 7200000) }));
  const application = { config, principal, expectedIdentity, get owner() { return state.owner; },
    publishRound(id, humanText = null, priorActs = []) {
      const records = [work, agent], carriers = [{ ref: definitionRef, encoding: 'utf8', value: definition }], offered = [];
      if (humanText !== null) {
        const original = payloadReference(humanText, 'text/plain'), act = record('act', 'human-' + id, { contributor: ref(human), mapping: rule('human-input'),
          expression: known({ form: 'material', items: [original] }), basis: state.currentContext ? known([state.currentContext]) : absent(), transmitter: known(principal) });
        records.push(human, act); offered.push({ mode: 'exact', subject: ref(act) }); carriers.push({ ref: original, encoding: 'utf8', value: humanText });
      }
      for (const act of priorActs) {
        records.push(act); offered.push({ mode: 'exact', subject: ref(act) });
        const x = act.body.expression;
        const refs = x.state !== 'known' ? [] : x.value.form === 'material' ? x.value.items : x.value.statement ? [x.value.statement] : [];
        for (const r of refs) {
          if (carriers.some(c => c.ref.digest.value === r.digest.value && c.ref.length === r.length && c.ref.mediaType === r.mediaType)) continue;
          const original = state.owner.inspectData(j(r)); if (!original?.original) throw new Error('example_original_unavailable');
          carriers.push({ ref: r, encoding: 'utf8', value: original.original.toString('utf8') });
        }
      }
      const context = record('context', 'context-' + id, { offered, conditions: [rule('fixture-creative-room')], gaps: ['invented-fixture'] });
      records.push(context); const manifest = record('manifest', 'context-manifest-' + id, { records: records.map(ref), data: carriers.map(c => c.ref),
        coverage: [], omissions: [], availability: [], policy: rule('disclosure') });
      state.currentContext = state.owner.publishContext(j({ package: { work: workRef, context: ref(context), manifest, records, carriers }, readers: [principal], until: end(clock, 3600000) }));
      return state.currentContext;
    },
    declareAppDecision(id, act, outcome) {
      const report = record('report', 'app-' + id, { category: 'acceptance', subjects: [ref(act)], actor: known(root), rule: known(rule('app-decision')),
        outcome, outputs: [], basis: [ref(act)], supersedes: [] });
      state.owner.appendAppReport(j(report), end(clock, 3600000)); return report;
    },
    selectAccount(id, records, data) {
      const manifest = record('manifest', 'selected-' + id, { records: records.map(ref), data, coverage: [], omissions: [], availability: [], policy: rule('disclosure') });
      return state.owner.publishInspection(j({ selection: id, manifest, readers: [principal], until: end(clock, 300000) }));
    },
    reopen() { state.owner.close(); state.owner = ParticipationOwner.open({ directory, identityJson: j(expectedIdentity), clock }); },
    close() { state.owner.close(); } };
  application.publishRound('initial', config.opening); return application;
}
