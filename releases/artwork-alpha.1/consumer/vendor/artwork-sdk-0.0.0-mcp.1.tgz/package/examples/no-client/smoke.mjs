// Installed public API proof. All "Agent" expressions/identity are invented.
// No listener, client, account, network, renderer or model request is used.
import assert from 'node:assert/strict';
import { mkdtempSync, realpathSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { recordReference, payloadReference } from '@agent-art/artwork-sdk';
import { createParticipationAdapter } from '@agent-art/artwork-sdk/mcp';
import { InertPrincipalResolver } from '@agent-art/artwork-sdk/testing/inert-resolver';
import { createWorkApplication } from './app.mjs';

const CANDIDATE = '@agent-art/artwork-sdk@0.0.0-mcp.1', j = JSON.stringify;
const checks = [], apps = []; let directory, current = 'startup', id = 0;
const verify = (name, action) => { current = name; action(); checks.push(name); };
const ref = r => recordReference(j(r)), value = frame => frame.result.structuredContent.value;
let now = Date.parse('2026-11-13T00:00:00.001Z'); const clock = () => new Date(now).toISOString();
let adapter, resolver, auth, a, b, first, second, graphic, refusal, preparedA, preparedB, aAct, bAct, appReport;
const subject = 'urn:installed-fixture:account';
const freshAuth = () => resolver.issue(j({ subject, notAfter: new Date(now + 3600000).toISOString() }));
const call = (name, args) => JSON.parse(adapter.dispatch(j({ jsonrpc: '2.0', id: ++id, method: 'tools/call', params: { name, arguments: args } }), auth));
const context = work => value(call('read_context', { work }));
const prepare = (work, ctx, prepareId, revisionOf) => value(call('prepare_return', { work, context: ctx, prepareId, ...(revisionOf ? { revisionOf } : {}) }));
const submit = (work, p, expression) => value(call('submit_expression', { work, returnHandle: p.returnHandle, reservation: p.reservation, expression })).receipt.value;
const status = (work, p) => value(call('return_status', { work, returnHandle: p.returnHandle })).receipt.value;
try {
  verify('four-installed-public-imports', () => {
    for (const name of ['', '/owner', '/mcp', '/testing/inert-resolver']) {
      const resolved = realpathSync(fileURLToPath(import.meta.resolve('@agent-art/artwork-sdk' + name)));
      assert.ok(resolved.includes(path.join('node_modules', '@agent-art', 'artwork-sdk') + path.sep));
    }
    assert.equal(process.version, 'v22.23.4'); assert.equal(process.versions.sqlite, '3.53.4');
    assert.throws(() => import.meta.resolve('@agent-art/artwork-sdk/internal/store.mjs'));
  });
  const configs = JSON.parse(readFileSync(new URL('./works.json', import.meta.url), 'utf8'));
  verify('two-artist-owned-configurations-and-private-owners', () => {
    directory = realpathSync(mkdtempSync(path.join(tmpdir(), 'aap-mcp-installed-work-')));
    for (const config of configs) apps.push(createWorkApplication(config, path.join(directory, config.id), clock));
    [a, b] = apps; assert.notEqual(configs[0].premise, configs[1].premise);
    assert.notDeepEqual(a.expectedIdentity.work, b.expectedIdentity.work);
  });
  verify('one-inert-subject-two-work-local-principals', () => {
    resolver = new InertPrincipalResolver({ clock, membersJson: j(apps.map(app => ({ subject, work: app.config.id, principal: app.principal }))) });
    auth = freshAuth(); adapter = createParticipationAdapter({ resolver, works: apps.map(app => ({ work: app.config.id,
      identity: app.expectedIdentity, getOwner: () => app.owner })) });
    const catalog = JSON.parse(adapter.dispatch(j({ jsonrpc: '2.0', id: ++id, method: 'tools/list', params: {} }), auth));
    assert.equal(catalog.result.tools.length, 7); assert.notEqual(a.principal, b.principal);
  });
  let ac, bc;
  verify('human-first-and-agent-initiated-contexts', () => {
    ac = context('room'); bc = context('map');
    assert.ok(ac.records.some(r => r.type === 'act' && r.body.transmitter.value === a.principal));
    assert.ok(!bc.records.some(r => r.type === 'act')); assert.ok(bc.records.some(r => r.type === 'participant' && r.body.kind === 'agent'));
  });
  verify('idempotent-reservation-and-actual-recording', () => {
    preparedA = prepare('room', ac.context, 'first'); assert.deepEqual(prepare('room', ac.context, 'first'), preparedA);
    first = submit('room', preparedA, a.config.agentFixture); assert.equal(first.body.outcome, 'committed');
    aAct = a.owner.inspectRecord(j(first.body.recorded[0])).record;
    assert.equal(a.owner.inspectData(j(first.body.retained[0])).original.toString(), a.config.agentFixture.text);
  });
  verify('exact-retry-and-changed-intent-conflict', () => {
    assert.deepEqual(submit('room', preparedA, a.config.agentFixture), first);
    const response = call('submit_expression', { work: 'room', returnHandle: preparedA.returnHandle, reservation: preparedA.reservation,
      expression: { form: 'material', mediaType: 'text/plain', text: 'different' } });
    assert.equal(response.result.structuredContent.processing, 'invalid'); assert.deepEqual(status('room', preparedA), first);
  });
  verify('fresh-human-context-and-own-agent-revision', () => {
    now += 10; const ctx = a.publishRound('second', a.config.humanRevision, [aAct]);
    const p = prepare('room', ctx, 'second', ref(aAct)); second = submit('room', p, a.config.agentRevisionFixture);
    assert.equal(second.body.recorded.length, 2); assert.notDeepEqual(first.body.operation, second.body.operation);
    const relation = a.owner.inspectRecord(j(second.body.recorded[1])).record;
    assert.deepEqual(relation.body.members[1].subject, ref(aAct)); assert.deepEqual(status('room', preparedA), first);
  });
  verify('static-svg-original-is-opaque-and-byte-exact', () => {
    preparedB = prepare('map', bc.context, 'graphic'); graphic = submit('map', preparedB, b.config.agentFixture);
    bAct = b.owner.inspectRecord(j(graphic.body.recorded[0])).record;
    const original = b.owner.inspectData(j(graphic.body.retained[0])).original;
    assert.ok(original.equals(Buffer.from(b.config.agentFixture.text, 'utf8')));
    assert.deepEqual(payloadReference(original, 'image/svg+xml'), graphic.body.retained[0]);
  });
  verify('explicit-refusal-is-recorded-without-a-fabricated-original', () => {
    const p = prepare('map', bc.context, 'refusal'); refusal = submit('map', p, { form: 'refusal' });
    assert.equal(refusal.body.outcome, 'committed'); assert.deepEqual(refusal.body.retained, []);
    assert.equal(b.owner.inspectRecord(j(refusal.body.recorded[0])).record.body.expression.value.form, 'refusal');
  });
  verify('cross-work-handle-and-context-substitution-denied', () => {
    assert.equal(call('return_status', { work: 'map', returnHandle: preparedA.returnHandle }).result.structuredContent.processing, 'denied');
    assert.equal(call('prepare_return', { work: 'map', context: ac.context, prepareId: 'substitute' }).result.structuredContent.processing, 'invalid');
  });
  verify('app-decision-does-not-change-the-recording-receipt', () => {
    const revised = a.owner.inspectRecord(j(second.body.recorded[0])).record;
    appReport = a.declareAppDecision('withhold', revised, 'withheld'); assert.equal(appReport.body.outputs.length, 0);
    assert.deepEqual(status('room', preparedA), first);
  });
  verify('selected-inert-process-and-exact-data-use-the-same-owner', () => {
    a.selectAccount('account', [aAct, first, appReport], first.body.retained);
    b.selectAccount('account', [bAct, graphic], graphic.body.retained);
    const page = value(call('inspect_process', { work: 'room', selection: 'account' })); assert.deepEqual(page.records[0], aAct);
    assert.equal(page.projection.ref.mediaType, 'application/json'); assert.doesNotMatch(page.projection.value, /<svg/);
    const read = value(call('inspect_process', { work: 'map', selection: 'account', data: graphic.body.retained[0] }));
    assert.equal(read.carrier.value, b.config.agentFixture.text);
    assert.equal(call('inspect_process', { work: 'map', selection: 'account', cursor: page.nextCursor.value }).result.structuredContent.processing, 'invalid');
  });
  verify('pre-pin-cancellation-is-not-agent-refusal', () => {
    const p = prepare('map', bc.context, 'cancel'); const r = value(call('cancel_return', { work: 'map', returnHandle: p.returnHandle })).receipt.value;
    assert.equal(r.body.outcome, 'cancelled'); assert.equal(r.body.requestDigest.state, 'not-recorded');
  });
  verify('expired-source-and-artwork-retirement-preserve-own-outcome', () => {
    now += 7300000; auth = freshAuth();
    for (const [app, r] of [[a, first], [b, graphic]]) {
      app.owner.setActive(app.principal, false);
      app.owner.retire(j({ subject: r.body.retained[0], reason: 'fixture-retention-ended' }));
      app.owner.retire(j({ subject: r.body.recorded[0], reason: 'fixture-retention-ended' }));
    }
    assert.deepEqual(status('room', preparedA), first); assert.deepEqual(status('map', preparedB), graphic);
    assert.equal(call('read_context', { work: 'room' }).result.structuredContent.processing, 'denied');
    assert.equal(call('inspect_process', { work: 'map', selection: 'account' }).result.structuredContent.processing, 'denied');
  });
  verify('native-reopen-fresh-context-and-recovery-index', () => {
    for (const app of apps) app.reopen(); resolver.revoke(auth); auth = freshAuth();
    assert.deepEqual(status('room', preparedA), first); assert.deepEqual(status('map', preparedB), graphic);
    const index = value(call('resume_work', { work: 'room' })); assert.equal(index.context.state, 'unavailable');
    assert.ok(index.operations.some(x => x.returnHandle === preparedA.returnHandle));
  });
  verify('finite-recovery-expiry-does-not-renew-operation', () => {
    now = Date.parse(first.body.retention.recoveryUntil) + 1; auth = freshAuth();
    assert.equal(call('return_status', { work: 'room', returnHandle: preparedA.returnHandle }).result.structuredContent.processing, 'denied');
  });
  for (const app of apps) app.close(); rmSync(directory, { recursive: true }); directory = null;
  checks.push('owned-fixture-resources-closed');
  process.stdout.write(j({ schema: 'aap.artwork-sdk.installed-mcp-proof.v1', candidate: CANDIDATE, status: 'passed',
    checks, workConfigurations: 2, publicImports: 4, node: process.versions.node, sqlite: process.versions.sqlite,
    creativeResponses: 'invented-fixtures', inertIdentity: true, realAuthentication: false, listenerOpened: false,
    clientLaunched: false, modelRequests: 0, rendererUsed: false, ownedFixtureResourcesClosed: true }) + '\n');
} catch {
  for (const app of apps) { try { app.close(); } catch {} }
  if (directory) rmSync(directory, { recursive: true, force: true });
  process.stdout.write(j({ schema: 'aap.artwork-sdk.installed-mcp-proof.v1', candidate: CANDIDATE, status: 'failed', check: current }) + '\n');
  process.exitCode = 1;
}
