const GATES = new Set(['raw', 'schema', 'semantic']);

// Public failures contain only stable codes and gate identity, never supplied text.
export class ContractError extends Error {
  constructor(code, gate = 'raw') {
    if (typeof code !== 'string' || !/^[a-z][a-z0-9_]{0,95}$/.test(code) || !GATES.has(gate)) {
      throw new TypeError('Invalid contract error identity.');
    }
    super(code);
    this.name = 'ContractError';
    this.code = code;
    this.gate = gate;
  }
}
