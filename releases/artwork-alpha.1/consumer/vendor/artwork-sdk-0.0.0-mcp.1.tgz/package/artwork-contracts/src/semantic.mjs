// Pure, locally decidable predicates. No store, grants, clock or admission engine.
import { createHash } from 'node:crypto';
import { ContractError } from './errors.mjs';

const fail = code => { throw new ContractError(code, 'semantic'); };
const timestampKeys = new Set(['validUntil', 'offeredAt', 'recordedAt', 'observedAt',
  'committedAt', 'recoveryUntil', 'checkedAt', 'minimumAvailableUntil']);
const digestText = text => createHash('sha256').update(Buffer.from(text, 'utf8')).digest('hex');
const isObject = value => value !== null && typeof value === 'object' && !Array.isArray(value);

export function sameRef(a, b) {
  return a !== null && b !== null && a.authorityId === b.authorityId
    && a.kind === b.kind && a.id === b.id && a.version === b.version;
}

export function refKey(ref) {
  return JSON.stringify([ref.authorityId, ref.kind, ref.id, ref.version]);
}

const refListEqual = (a, b) => a.length === b.length && a.every((ref, i) => sameRef(ref, b[i]));

export function checkExpression(expression, maximum = 16384) {
  if (expression === null) return;
  const bytes = Buffer.byteLength(expression.text, 'utf8');
  if (bytes < 1 || bytes > maximum) fail('utf8_text_byte_limit');
}

function checkUTC(value) {
  const time = Date.parse(value);
  if (!Number.isFinite(time) || new Date(time).toISOString() !== value) fail('invalid_calendar_time');
}

function checkBindingRefs(refs, bindings) {
  if (refs.length !== bindings.length || refs.some((ref, i) => !sameRef(ref, bindings[i].ref))) {
    fail('bound_record_ref_mismatch');
  }
}

function checkSummary(value) {
  if (value.state === 'accepted' && !refListEqual(value.retainedRefs, value.acceptedRefs)) {
    fail('accepted_retained_unit_equality');
  }
}

function checkResource(data, maxOutputBytes = 32769) {
  checkExpression(data.expression, maxOutputBytes);
  const bytes = Buffer.byteLength(data.expression.text, 'utf8');
  if (bytes !== data.byteLength) fail('utf8_length_mismatch');
  if (digestText(data.expression.text) !== data.digest.value) fail('text_digest_mismatch');
}

function checkPolicy(data) {
  const terms = new Set();
  for (const term of data.relationVocabulary) {
    if (terms.has(term.term)) fail('duplicate_relation_term');
    terms.add(term.term);
    const roles = new Set();
    for (const role of term.endpointRoles) {
      if (roles.has(role.role)) fail('duplicate_relation_role');
      roles.add(role.role);
    }
  }
}

function checkContext(data, workRef = data.workBasis) {
  if (!sameRef(workRef, data.workBasis)) fail('exact_work_basis_mismatch');
  checkBindingRefs(data.selectedRefs, data.selectedBindings);
}

function checkOutcome(data, workRef = data.workBasis) {
  if (!sameRef(workRef, data.workBasis)) fail('exact_work_basis_mismatch');
  if (data.operationRef.authorityId !== workRef.authorityId || data.operationRef.workId !== workRef.id) fail('operation_scope_mismatch');
  checkSummary(data);
  checkBindingRefs(data.retainedRefs, data.recordBindings);
  if (Date.parse(data.recoveryUntil) < Date.parse(data.committedAt) + 7 * 86400000) fail('recovery_boundary_too_short');
  if (data.state !== 'rejected' && Date.parse(data.validUntil) < Date.parse(data.committedAt)) fail('invalid_deadline_order');
}

function checkResult(data) {
  if (data.processing === 'completed' && data.inputRefs.length !== 2) fail('text_pair_requires_two_inputs');
}

function checkRecord(record, rules) {
  if (record.workRef !== null && record.authorityId !== record.workRef.authorityId) fail('record_authority_mismatch');
  const workRef = record.kind === 'work'
    ? { authorityId: record.authorityId, kind: 'work', id: record.id, version: record.version }
    : record.workRef;
  // A Ref is a declaration here. This checks its local scope, not resolution/access.
  const checkRefs = value => {
    if (Array.isArray(value)) { for (const item of value) checkRefs(item); return; }
    if (!isObject(value)) return;
    if ('authorityId' in value && 'kind' in value && 'id' in value && 'version' in value) {
      if (value.authorityId !== record.authorityId) fail('reference_authority_mismatch');
      if (value.kind === 'work' && value.id !== workRef.id) fail('logical_work_mismatch');
    }
    for (const item of Object.values(value)) checkRefs(item);
  };
  checkRefs(record.data);
  const data = record.data;
  switch (record.kind) {
    case 'act': checkExpression(data.expression, rules.maxActBytes); break;
    case 'resource': checkResource(data, rules.maxOutputBytes); break;
    case 'policy': checkPolicy(data); break;
    case 'context': checkContext(data, record.workRef); break;
    case 'outcome': checkOutcome(data, record.workRef); break;
    case 'observation':
      if (data.operationRef.authorityId !== record.authorityId || data.operationRef.workId !== workRef.id) fail('operation_scope_mismatch');
      break;
    case 'result': checkResult(data); break;
    default: break;
  }
}

function checkProposalValue(proposal) {
  if (proposal.authorityId !== proposal.workRef.authorityId) fail('proposal_authority_mismatch');
  if (proposal.contextRef !== null && proposal.contextRef.authorityId !== proposal.authorityId) fail('reference_authority_mismatch');
  if (proposal.currentStatePrecondition !== null && proposal.currentStatePrecondition.authorityId !== proposal.authorityId) fail('reference_authority_mismatch');
  const identities = new Set();
  for (const record of proposal.records) {
    if (!sameRef(record.workRef, proposal.workRef)) fail('exact_work_basis_mismatch');
    const identity = JSON.stringify([record.authorityId, record.kind, record.id]);
    if (identities.has(identity)) fail('duplicate_record_identity');
    identities.add(identity);
    if (record.kind === 'act') {
      if (record.data.contextRef !== null && !sameRef(record.data.contextRef, proposal.contextRef)) fail('single_context_batch_mismatch');
      if (proposal.operationKind === 'submit_contribution' && record.data.contextRef === null) fail('direct_context_required');
    }
  }
}

function checkResponse(value) {
  if (value.outcome !== null) checkSummary(value.outcome);
  if (value.operationRef !== null) {
    if (value.outcomeRef !== null && value.outcomeRef.authorityId !== value.operationRef.authorityId) fail('operation_scope_mismatch');
    if (value.outcome !== null) {
      for (const ref of [...value.outcome.retainedRefs, ...value.outcome.acceptedRefs]) {
        if (ref.authorityId !== value.operationRef.authorityId) fail('reference_authority_mismatch');
      }
    }
  }
}

export function assertLocalSemantics(value, definition, profileRules) {
  // This optional seam is supplied by trusted local codecs, never wire data.
  // Omission preserves every legacy schema marker and byte boundary.
  const rules = profileRules ?? { recordSchema: 'aap.local-text.record.draft1',
    proposalSchema: 'aap.local-text.proposal.draft1', maxActBytes: 16384, maxOutputBytes: 32769 };
  // Calendar validation is key-specific, so an artistic date-like string is not edited/rejected.
  const visit = item => {
    if (Array.isArray(item)) { for (const v of item) visit(v); return; }
    if (!isObject(item)) return;
    for (const [key, v] of Object.entries(item)) {
      if (timestampKeys.has(key) && v !== null) checkUTC(v);
      visit(v);
    }
    if (item.schema === rules.recordSchema) checkRecord(item, rules);
    if (item.schema === rules.proposalSchema) checkProposalValue(item);
  };
  visit(value);
  if (definition === 'UTC') checkUTC(value);
  if (definition === 'TextExpression') checkExpression(value);
  if (definition === 'OutputTextExpression') checkExpression(value, rules.maxOutputBytes);
  if (definition === 'ResourceData') checkResource(value, rules.maxOutputBytes);
  if (definition === 'ContextData') checkContext(value);
  if (definition === 'OutcomeData') checkOutcome(value);
  if (definition === 'ResultData') checkResult(value);
  if (definition === 'PolicyData') checkPolicy(value);
  if (definition === 'ContributionData' || definition === 'RefusalData' || definition === 'ActData') checkExpression(value.expression, rules.maxActBytes);
  if (definition === 'OutcomeSummary') checkSummary(value);
  if (definition === 'Response' || definition === 'ToolResponse') checkResponse(value);
  if (definition === 'FingerprintSubject' && value.authorityId !== value.proposal.authorityId) fail('proposal_authority_mismatch');
  return value;
}
