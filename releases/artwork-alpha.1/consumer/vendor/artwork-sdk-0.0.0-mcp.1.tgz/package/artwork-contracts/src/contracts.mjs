// Pure local-text contracts. Passing these checks is not Work admission or authentication.
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { types } from 'node:util';
import Ajv2020 from 'ajv/dist/2020.js';
import addFormats from 'ajv-formats';
import canonicalize from 'canonicalize';
import { parseDomainDocument } from './parse.mjs';
import { ContractError } from './errors.mjs';
import { assertLocalSemantics, sameRef, refKey } from './semantic.mjs';

const schemaNames = ['common', 'records', 'operations', 'tool-proposal', 'tool-query', 'tool-response'];
const schemas = schemaNames.map(name => JSON.parse(readFileSync(new URL(`../schema/${name}.schema.json`, import.meta.url), 'utf8')));
const ajv = new Ajv2020({ strict: true, coerceTypes: false, useDefaults: false,
  removeAdditional: false, ownProperties: true, allErrors: false });
addFormats(ajv);
for (const schema of schemas) ajv.addSchema(schema);

const validators = new Map();
for (const schema of schemas.slice(0, 3)) {
  for (const name of Object.keys(schema.$defs)) {
    if (!validators.has(name)) validators.set(name, ajv.compile({ $ref: `${schema.$id}#/$defs/${name}` }));
  }
}
for (const [name, index] of [['ToolProposal', 3], ['ToolQuery', 4], ['ToolResponse', 5]]) {
  validators.set(name, ajv.getSchema(schemas[index].$id));
}
const fail = (code, gate = 'semantic') => { throw new ContractError(code, gate); };
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const digest = (subject, bytes) => Object.freeze({ algorithm: 'sha-256', subject, value: hash(bytes) });
const canonicalBytes = value => Buffer.from(canonicalize(value), 'utf8');
const referenceOf = record => Object.freeze({ authorityId: record.authorityId, kind: record.kind, id: record.id, version: record.version });

export function validateDocument(input, definition = 'Proposal') {
  const validator = validators.get(definition);
  if (!validator) fail('unsupported_definition', 'schema');
  const value = parseDomainDocument(input);
  if (!validator(value)) fail('schema_validation_failed', 'schema');
  return assertLocalSemantics(value, definition);
}

export function canonicalRecordBytes(input) {
  return canonicalBytes(validateDocument(input, 'Record'));
}

export function recordDigest(input) {
  return digest('record-jcs-v1', Buffer.concat([Buffer.from('aap.local-text.record.draft1\n'), canonicalRecordBytes(input)]));
}

export function textDigest(text) {
  if (typeof text !== 'string' || !text.isWellFormed()) fail('invalid_text', 'raw');
  if (Buffer.byteLength(text, 'utf8') > 32769) fail('utf8_text_byte_limit');
  return digest('text-utf8', Buffer.from(text, 'utf8'));
}

function safeFields(value, names) {
  if (value === null || typeof value !== 'object' || types.isProxy(value)
      || ![Object.prototype, null].includes(Object.getPrototypeOf(value))
      || Object.getOwnPropertySymbols(value).length) fail('invalid_scope');
  const entries = Object.getOwnPropertyDescriptors(value);
  if (Object.keys(entries).length !== names.length || names.some(name => !Object.hasOwn(entries, name))
      || Object.entries(entries).some(([name, descriptor]) => !names.includes(name) || !Object.hasOwn(descriptor, 'value'))) fail('invalid_scope');
  return Object.fromEntries(names.map(name => [name, entries[name].value]));
}

function identifier(value) {
  if (typeof value !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/.test(value)) fail('invalid_scope');
  return value;
}

export function operationFingerprint(input, actualScope) {
  const proposal = validateDocument(input, 'Proposal');
  const scope = safeFields(actualScope, ['authorityId', 'principalId']);
  identifier(scope.authorityId); identifier(scope.principalId);
  if (scope.authorityId !== proposal.authorityId) fail('proposal_authority_mismatch');
  return digest('operation-jcs-v1', Buffer.concat([Buffer.from('aap.local-text.operation.draft1\n'),
    canonicalBytes({ authorityId: scope.authorityId, principalId: scope.principalId, proposal })]));
}

export function checkProposal(input, suppliedScope) {
  const proposal = validateDocument(input, 'Proposal');
  const scope = safeFields(suppliedScope, ['authorityId', 'workRef']);
  identifier(scope.authorityId);
  const ref = safeFields(scope.workRef, ['authorityId', 'kind', 'id', 'version']);
  identifier(ref.authorityId); identifier(ref.id); identifier(ref.version);
  if (ref.kind !== 'work') fail('invalid_scope');
  const work = validateDocument(JSON.stringify(ref), 'WorkRef');
  if (scope.authorityId !== proposal.authorityId || scope.authorityId !== work.authorityId) fail('proposal_authority_mismatch');
  if (!sameRef(proposal.workRef, work)) fail('exact_work_basis_mismatch');
  return proposal;
}

export function recordReference(input) {
  return referenceOf(validateDocument(input, 'Record'));
}

export function equalReferences(left, right) {
  return sameRef(validateDocument(left, 'RecordRef'), validateDocument(right, 'RecordRef'));
}

export function checkRecordBindings(input, materialDocuments) {
  const record = validateDocument(input, 'Record');
  if (!['context', 'outcome'].includes(record.kind)) fail('unsupported_binding_record');
  if (types.isProxy(materialDocuments) || !Array.isArray(materialDocuments)
      || Object.getPrototypeOf(materialDocuments) !== Array.prototype || materialDocuments.length > 256) fail('invalid_material_set');
  const descriptors = Object.getOwnPropertyDescriptors(materialDocuments);
  if (Object.getOwnPropertySymbols(materialDocuments).length || Object.values(descriptors).some(d => !Object.hasOwn(d, 'value'))
      || Object.keys(descriptors).some(name => name !== 'length' && (!/^(0|[1-9][0-9]*)$/.test(name) || Number(name) >= materialDocuments.length))
      || Array.from({ length: materialDocuments.length }, (_, i) => i).some(i => !Object.hasOwn(descriptors, i))) fail('invalid_material_set');
  const materials = new Map();
  for (const raw of materialDocuments) {
    const material = validateDocument(raw, 'Record');
    const work = material.kind === 'work' ? referenceOf(material) : material.workRef;
    if (work.authorityId !== record.workRef.authorityId || work.id !== record.workRef.id) fail('material_work_mismatch');
    const key = refKey(referenceOf(material));
    if (materials.has(key)) fail('duplicate_record_identity');
    materials.set(key, canonicalBytes(material));
  }
  const bindings = record.kind === 'context' ? record.data.selectedBindings : record.data.recordBindings;
  for (const binding of bindings) {
    const bytes = materials.get(refKey(binding.ref));
    if (!bytes) fail('material_not_supplied');
    if (hash(Buffer.concat([Buffer.from('aap.local-text.record.draft1\n'), bytes])) !== binding.digest.value) fail('bound_record_digest_mismatch');
  }
  return record;
}

export const contractInfo = Object.freeze({ profile: 'aap.local-text.pilot', profileVersion: 'm1.4',
  schemaDocuments: 6, definitions: validators.size,
  assurance: 'Local structure, exact bytes and supplied-material checks only; no authentication, admission, persistence or Agent/model-origin claim.' });
