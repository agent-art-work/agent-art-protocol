import { visit } from 'jsonc-parser';
import { ContractError } from './errors.mjs';

export const MAX_DOCUMENT_BYTES = 262144;
export const MAX_DEPTH = 64;
const MAX_INTEGER_TOKEN = '9007199254740991';
const decoder = new TextDecoder('utf-8', { fatal: true, ignoreBOM: true });
const typedArrayPrototype = Object.getPrototypeOf(Uint8Array.prototype);
const byteLengthOf = Object.getOwnPropertyDescriptor(typedArrayPrototype, 'byteLength').get;
const byteOffsetOf = Object.getOwnPropertyDescriptor(typedArrayPrototype, 'byteOffset').get;
const bufferOf = Object.getOwnPropertyDescriptor(typedArrayPrototype, 'buffer').get;
const typedArrayNameOf = Object.getOwnPropertyDescriptor(typedArrayPrototype, Symbol.toStringTag).get;
const reject = code => { throw new ContractError(code, 'raw'); };

function assertUnicode(value) {
  for (let i = 0; i < value.length; i++) {
    const unit = value.charCodeAt(i);
    if (unit >= 0xd800 && unit <= 0xdbff) {
      const next = value.charCodeAt(++i);
      if (!(next >= 0xdc00 && next <= 0xdfff)) reject('invalid_unicode');
    } else if (unit >= 0xdc00 && unit <= 0xdfff) reject('invalid_unicode');
  }
}

function documentText(input) {
  if (typeof input === 'string') {
    // Code-unit length is a cheap necessary bound before scanning or encoding.
    if (input.length > MAX_DOCUMENT_BYTES) reject('request_byte_limit');
    assertUnicode(input);
    if (Buffer.byteLength(input, 'utf8') > MAX_DOCUMENT_BYTES) reject('request_byte_limit');
    if (input.charCodeAt(0) === 0xfeff) reject('unexpected_bom');
    return input;
  }
  if (!ArrayBuffer.isView(input) || typedArrayNameOf.call(input) !== 'Uint8Array') reject('invalid_input_type');
  // Intrinsic accessors and copying avoid user-supplied valueOf/iterator/getters.
  let length, snapshot;
  try {
    length = byteLengthOf.call(input);
    if (length > MAX_DOCUMENT_BYTES) reject('request_byte_limit');
    const view = new Uint8Array(bufferOf.call(input), byteOffsetOf.call(input), length);
    snapshot = Buffer.alloc(length);
    snapshot.set(view);
  } catch (error) {
    if (error instanceof ContractError) throw error;
    reject('invalid_input_type');
  }
  if (snapshot[0] === 0xef && snapshot[1] === 0xbb && snapshot[2] === 0xbf) reject('unexpected_bom');
  try { return decoder.decode(snapshot); } catch { reject('invalid_utf8'); }
}

function freezeJson(value) {
  if (value !== null && typeof value === 'object') {
    for (const key of Object.keys(value)) freezeJson(value[key]);
    Object.freeze(value);
  }
  return value;
}

export function parseDomainDocument(input) {
  const text = documentText(input);
  const stack = [];
  function begin(type) {
    if (stack.length === MAX_DEPTH) reject('nesting_depth_limit');
    stack.push({ type, keys: type === 'object' ? new Set() : null });
  }
  try {
    visit(text, {
      onObjectBegin: () => begin('object'),
      onArrayBegin: () => begin('array'),
      onObjectEnd: () => { stack.pop(); },
      onArrayEnd: () => { stack.pop(); },
      onObjectProperty: key => {
        assertUnicode(key);
        const frame = stack.at(-1);
        if (frame?.type !== 'object') reject('invalid_json');
        if (frame.keys.has(key)) reject('duplicate_key');
        frame.keys.add(key);
      },
      onLiteralValue: (value, offset, length) => {
        if (typeof value === 'string') assertUnicode(value);
        if (typeof value === 'number') {
          const token = text.slice(offset, offset + length);
          if (!/^(0|[1-9][0-9]*)$/.test(token)
              || token.length > MAX_INTEGER_TOKEN.length
              || (token.length === MAX_INTEGER_TOKEN.length && token > MAX_INTEGER_TOKEN)
              || !Number.isSafeInteger(value)) reject('invalid_number');
        }
      },
      onError: () => reject('invalid_json'),
    }, { disallowComments: true, allowTrailingComma: false, allowEmptyContent: false });
    if (stack.length) reject('invalid_json');
    return freezeJson(JSON.parse(text));
  } catch (error) {
    if (error instanceof ContractError) throw error;
    // Neither parser diagnostics nor native SyntaxError text may echo the source.
    reject('invalid_json');
  }
}
