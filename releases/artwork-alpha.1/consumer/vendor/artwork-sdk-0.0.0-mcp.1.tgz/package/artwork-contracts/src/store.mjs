// Internal single-owner store. No transport, caller authentication or artistic admission policy.
import { DatabaseSync } from 'node:sqlite';
import { mkdirSync, realpathSync, lstatSync, openSync, closeSync } from 'node:fs';
import { resolve, join, dirname, basename, isAbsolute } from 'node:path';
import { createHash } from 'node:crypto';
import { types } from 'node:util';
import canonicalize from 'canonicalize';
import { parseDomainDocument } from './parse.mjs';
import { validateDocument, canonicalRecordBytes, recordDigest, recordReference } from './contracts.mjs';

const FORMAT = 'aap.local-text.store.m2.2';
const defaultContractSet = Object.freeze({ validateDocument, canonicalRecordBytes,
  recordDigest, recordReference, storeFormat: FORMAT, recordDigestSubject: 'record-jcs-v1' });
const APP_ID = 0x41415031;
const ACTIVE_PATHS = new Set(); // Fast same-process guard; SQLite remains the OS-backed authority.
const TABLES = Object.freeze({
  metadata: 'CREATE TABLE metadata(key TEXT PRIMARY KEY, value BLOB NOT NULL) STRICT',
  records: `CREATE TABLE records(authority TEXT NOT NULL, kind TEXT NOT NULL, id TEXT NOT NULL, version TEXT NOT NULL,
    work_id TEXT NOT NULL, canonical BLOB NOT NULL, digest TEXT NOT NULL, original BLOB,
    PRIMARY KEY(authority,kind,id,version)) STRICT`,
  heads: 'CREATE TABLE heads(name TEXT PRIMARY KEY, ref BLOB NOT NULL) STRICT',
  operations: `CREATE TABLE operations(authority TEXT NOT NULL, principal TEXT NOT NULL, work_id TEXT NOT NULL,
    kind TEXT NOT NULL, id TEXT NOT NULL, fingerprint TEXT, response BLOB NOT NULL,
    PRIMARY KEY(authority,principal,work_id,kind,id)) STRICT`,
});
const normalizedSQL = sql => sql.replace(/\s+/g, '').toLowerCase();
const REQUIRED = Object.freeze({ journal_mode: 'delete', synchronous: 3, fullfsync: 1,
  locking_mode: 'exclusive', foreign_keys: 1, busy_timeout: 1000 });
const id = value => typeof value === 'string' && /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/.test(value);
const key = value => typeof value === 'string' && /^[A-Za-z0-9][A-Za-z0-9._:-]{0,255}$/.test(value);
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const refKey = ref => JSON.stringify([ref.authorityId, ref.kind, ref.id, ref.version]);
const opValues = ref => [ref.authorityId, ref.principalId, ref.workId, ref.operationKind, ref.operationId];
const equal = (a, b) => canonicalize(a) === canonicalize(b);
const bytes = value => Buffer.from(value);

export class StoreError extends Error {
  constructor(code) { super(code); this.name = 'StoreError'; this.code = code; }
}
const fail = code => { throw new StoreError(code); };
// This provider is trusted local code, never a wire/uploaded validator. Snapshot
// its data properties before filesystem effects; callers cannot switch a live store.
function checkedContractSet(value) {
  if (value === null || typeof value !== 'object' || types.isProxy(value)
      || ![Object.prototype, null].includes(Object.getPrototypeOf(value))
      || !Object.isFrozen(value)) fail('invalid_contract_set');
  const fields = Object.getOwnPropertyDescriptors(value);
  const functions = ['validateDocument', 'canonicalRecordBytes', 'recordDigest', 'recordReference'];
  const names = [...functions, 'storeFormat', 'recordDigestSubject'];
  if (names.some(name => !fields[name] || !Object.hasOwn(fields[name], 'value'))
      || functions.some(name => typeof fields[name].value !== 'function')
      || ['storeFormat', 'recordDigestSubject'].some(name => !id(fields[name].value)))
    fail('invalid_contract_set');
  return Object.freeze(Object.fromEntries(names.map(name => [name, fields[name].value])));
}
// A versioned row adapter is trusted source code, never JSON/plugin input. Both
// formats retain this class's path/ownership/transaction/unknown-commit boundary.
function checkedStorageProfile(value) {
  if (value === undefined) return null;
  if (!value || types.isProxy(value) || !Object.isFrozen(value)
      || ![Object.prototype, null].includes(Object.getPrototypeOf(value))) fail('invalid_storage_profile');
  const fields = Object.getOwnPropertyDescriptors(value), names = ['format', 'version', 'tables', 'readQueries', 'writeQueries', 'validateIdentity', 'validateExisting'];
  if (Object.keys(fields).sort().join(',') !== [...names].sort().join(',')
      || names.some(k => !Object.hasOwn(fields[k], 'value'))) fail('invalid_storage_profile');
  const p = Object.fromEntries(names.map(k => [k, fields[k].value]));
  if (!id(p.format) || p.version !== 2 || typeof p.validateIdentity !== 'function' || typeof p.validateExisting !== 'function'
      || !p.tables || types.isProxy(p.tables) || !Object.isFrozen(p.tables) || Object.getPrototypeOf(p.tables) !== Object.prototype) fail('invalid_storage_profile');
  const tableFields = Object.getOwnPropertyDescriptors(p.tables);
  if (!Object.hasOwn(tableFields, 'metadata') || Object.entries(tableFields).some(([k, d]) => !id(k)
      || !Object.hasOwn(d, 'value') || typeof d.value !== 'string') || p.tables.metadata !== TABLES.metadata) fail('invalid_storage_profile');
  p.tables = Object.freeze(Object.fromEntries(Object.entries(tableFields).map(([k, d]) => [k, d.value])));
  for (const kind of ['readQueries', 'writeQueries']) {
    const queries = p[kind];
    if (!queries || types.isProxy(queries) || !Object.isFrozen(queries) || Object.getPrototypeOf(queries) !== Object.prototype) fail('invalid_storage_profile');
    const descriptors = Object.getOwnPropertyDescriptors(queries);
    if (Object.entries(descriptors).some(([k, d]) => !id(k) || !Object.hasOwn(d, 'value') || typeof d.value !== 'string'
        || !(kind === 'readQueries' ? /^\s*SELECT\b/i : /^\s*(INSERT|UPDATE|DELETE)\b/i).test(d.value))) fail('invalid_storage_profile');
    p[kind] = Object.freeze(Object.fromEntries(Object.entries(descriptors).map(([k, d]) => [k, d.value])));
  }
  return Object.freeze(p);
}
function profileArguments(input) {
  if (!Array.isArray(input) || types.isProxy(input)) fail('invalid_profile_arguments');
  const d = Object.getOwnPropertyDescriptors(input);
  if (d.length.value > 32 || Object.keys(d).length !== d.length.value + 1) fail('invalid_profile_arguments');
  return Array.from({ length: d.length.value }, (_, i) => {
    if (!Object.hasOwn(d[i] ?? {}, 'value')) fail('invalid_profile_arguments');
    const v = d[i].value;
    if (v === null || (typeof v === 'string' && Buffer.byteLength(v) <= 4194304) || (typeof v === 'number' && Number.isSafeInteger(v))) return v;
    if (!types.isProxy(v) && ArrayBuffer.isView(v) && byteArrayNameOf.call(v) === 'Uint8Array') {
      const n = byteLengthOf.call(v); if (n > 4194304) fail('invalid_profile_arguments');
      return Buffer.from(new Uint8Array(bufferOf.call(v), byteOffsetOf.call(v), n));
    }
    fail('invalid_profile_arguments');
  });
}
function sqlError(error, ownership = false) {
  if (error instanceof StoreError) return error;
  switch (Number.isInteger(error?.errcode) ? error.errcode & 255 : null) {
    case 5: case 6: return new StoreError(ownership ? 'ownership_busy' : 'storage_locked');
    case 8: return new StoreError('storage_readonly');
    case 10: return new StoreError('storage_io');
    case 11: case 26: return new StoreError('store_corrupt');
    case 13: return new StoreError('storage_full');
    case 19: return new StoreError('storage_constraint');
    default: return new StoreError('storage_failed');
  }
}

// Trusted local control arguments still cannot invoke arbitrary getters/toJSON.
function plain(value, depth = 0) {
  if (depth > 64) fail('invalid_control_value');
  if (value === null || ['string', 'boolean'].includes(typeof value)) return value;
  if (typeof value === 'number' && Number.isSafeInteger(value) && value >= 0 && !Object.is(value, -0)) return value;
  if (typeof value !== 'object' || types.isProxy(value)) fail('invalid_control_value');
  const prototype = Object.getPrototypeOf(value);
  if (!(Array.isArray(value) ? prototype === Array.prototype : prototype === Object.prototype || prototype === null)
      || Object.getOwnPropertySymbols(value).length) fail('invalid_control_value');
  const descriptors = Object.getOwnPropertyDescriptors(value);
  if (Object.values(descriptors).some(d => !Object.hasOwn(d, 'value'))) fail('invalid_control_value');
  if (Array.isArray(value)) {
    if (Object.keys(descriptors).some(k => k !== 'length' && (!/^(0|[1-9][0-9]*)$/.test(k) || Number(k) >= value.length))) fail('invalid_control_value');
    return Array.from({ length: value.length }, (_, i) => {
      if (!Object.hasOwn(descriptors, i)) fail('invalid_control_value');
      return plain(descriptors[i].value, depth + 1);
    });
  }
  return Object.fromEntries(Object.entries(descriptors).map(([k, d]) => [k, plain(d.value, depth + 1)]));
}
const document = value => typeof value === 'string' || ArrayBuffer.isView(value) ? value : canonicalize(plain(value));
const original = record => ['act', 'resource'].includes(record.kind) && record.data.expression !== null
  ? Buffer.from(record.data.expression.text, 'utf8') : null;

// Versioned opaque bytes share this database/transaction authority. These are
// not JSON metadata or artistic records. Integrity binds the namespace key as
// well as the exact bytes; it is not protection against an operator rewriting
// the database or rolling it back to a trusted older copy/binary.
const PRIVATE_BYTES_PREFIX = 'agent-return-bytes:';
const PRIVATE_BYTES_MAGIC = Buffer.from('aap.agent-return.private-bytes.v1\0', 'utf8');
const PRIVATE_BYTES_MAX = 262144;
const PRIVATE_BYTES_HEADER = PRIVATE_BYTES_MAGIC.length + 4 + 32;
const privateKey = name => key(name) && name.startsWith(PRIVATE_BYTES_PREFIX)
  && name.length > PRIVATE_BYTES_PREFIX.length;
const byteArrayPrototype = Object.getPrototypeOf(Uint8Array.prototype);
const byteLengthOf = Object.getOwnPropertyDescriptor(byteArrayPrototype, 'byteLength').get;
const byteOffsetOf = Object.getOwnPropertyDescriptor(byteArrayPrototype, 'byteOffset').get;
const bufferOf = Object.getOwnPropertyDescriptor(byteArrayPrototype, 'buffer').get;
const byteArrayNameOf = Object.getOwnPropertyDescriptor(byteArrayPrototype, Symbol.toStringTag).get;
const privateDigest = (name, payload) => createHash('sha256')
  .update(PRIVATE_BYTES_MAGIC).update(name, 'utf8').update('\n', 'utf8').update(payload).digest();
function privateSnapshot(input) {
  if (types.isProxy(input) || !ArrayBuffer.isView(input)
      || byteArrayNameOf.call(input) !== 'Uint8Array') fail('invalid_private_bytes');
  try {
    const length = byteLengthOf.call(input);
    if (length > PRIVATE_BYTES_MAX) fail('private_bytes_limit');
    const snapshot = Buffer.alloc(length);
    snapshot.set(new Uint8Array(bufferOf.call(input), byteOffsetOf.call(input), length));
    return snapshot;
  } catch (error) {
    if (error instanceof StoreError) throw error;
    fail('invalid_private_bytes');
  }
}
function privateFrame(name, payload) {
  const frame = Buffer.alloc(PRIVATE_BYTES_HEADER + payload.length);
  PRIVATE_BYTES_MAGIC.copy(frame);
  frame.writeUInt32BE(payload.length, PRIVATE_BYTES_MAGIC.length);
  privateDigest(name, payload).copy(frame, PRIVATE_BYTES_MAGIC.length + 4);
  payload.copy(frame, PRIVATE_BYTES_HEADER);
  return frame;
}
function privatePayload(name, frame) {
  if (!privateKey(name) || frame.length < PRIVATE_BYTES_HEADER
      || !frame.subarray(0, PRIVATE_BYTES_MAGIC.length).equals(PRIVATE_BYTES_MAGIC)) fail('store_corrupt');
  const length = frame.readUInt32BE(PRIVATE_BYTES_MAGIC.length);
  if (length > PRIVATE_BYTES_MAX || frame.length !== PRIVATE_BYTES_HEADER + length) fail('store_corrupt');
  const payload = frame.subarray(PRIVATE_BYTES_HEADER);
  if (!frame.subarray(PRIVATE_BYTES_MAGIC.length + 4, PRIVATE_BYTES_HEADER)
    .equals(privateDigest(name, payload))) fail('store_corrupt');
  return Buffer.from(payload);
}

export class SqliteStore {
  #db; #directory; #file; #identity; #binding; #contracts; #closed = false; #poisoned = false; #inside = false; #testFault;
  #profile;

  static initialize(options) { return new SqliteStore(options, true); }
  static open(options) { return new SqliteStore(options, false); }

  constructor({ directory, identity, testFault, maxPageCountTestOnly, queryOnlyTestOnly = false,
    contractSet = defaultContractSet, storageProfile } = {}, create) {
    if (create !== true && create !== false) fail('use_explicit_store_factory');
    this.#contracts = checkedContractSet(contractSet);
    this.#profile = checkedStorageProfile(storageProfile);
    if (typeof directory !== 'string' || !isAbsolute(directory)) fail('noncanonical_store_path');
    const normalized = resolve(directory);
    try {
      if (create) {
        if (realpathSync(dirname(normalized)) !== dirname(normalized)) fail('noncanonical_store_path');
        try { mkdirSync(normalized, { mode: 0o700 }); }
        catch (e) { if (e.code !== 'EEXIST') throw e; }
      }
      const stat = lstatSync(normalized);
      if (stat.isSymbolicLink() || !stat.isDirectory() || realpathSync(normalized) !== normalized) fail('noncanonical_store_path');
      if ((stat.mode & 0o777) !== 0o700 || stat.uid !== process.getuid()) fail('store_permissions_invalid');
    } catch (error) {
      if (error instanceof StoreError) throw error;
      fail(error.code === 'ENOENT' ? 'store_missing' : 'store_path_unavailable');
    }
    this.#directory = normalized; this.#file = join(normalized, 'store.sqlite');
    if (ACTIVE_PATHS.has(this.#file)) fail('ownership_busy');
    const safeIdentity = plain(identity);
    if (this.#profile) this.#profile.validateIdentity(document(safeIdentity));
    else if (Object.keys(safeIdentity).sort().join(',') !== 'authorityId,ownerPrincipalId,workId'
        || Object.values(safeIdentity).some(v => !id(v))) fail('invalid_store_identity');
    this.#identity = parseDomainDocument(canonicalize(safeIdentity));
    if (testFault !== undefined && typeof testFault !== 'function') fail('invalid_test_fault');
    this.#testFault = testFault;
    if (process.platform !== 'darwin' || process.arch !== 'arm64' || process.version !== 'v22.23.4'
        || process.versions.sqlite !== '3.53.4') fail('unsupported_store_runtime');
    if (create) {
      try { const fd = openSync(this.#file, 'wx', 0o600); closeSync(fd); }
      catch (e) { fail(e.code === 'EEXIST' ? 'store_already_exists' : 'store_create_failed'); }
    }
    this.#binding = this.#pathBinding();
    try {
      this.#db = new DatabaseSync(this.#file, { open: true, readOnly: false,
        enableForeignKeyConstraints: true, enableDoubleQuotedStringLiterals: false,
        allowExtension: false, timeout: 1000 });
      this.#db.exec('PRAGMA busy_timeout=1000; PRAGMA main.locking_mode=EXCLUSIVE; PRAGMA main.journal_mode=DELETE; PRAGMA main.synchronous=EXTRA; PRAGMA fullfsync=ON; PRAGMA foreign_keys=ON;');
      this.#assertSettings();
      this.#db.exec('BEGIN EXCLUSIVE');
      if (create) this.#create();
      else this.#validateExisting();
      this.#db.exec('COMMIT');
      this.#assertSettings();
      if (maxPageCountTestOnly !== undefined) {
        if (!Number.isSafeInteger(maxPageCountTestOnly) || maxPageCountTestOnly < 1) fail('invalid_test_page_limit');
        this.#db.exec(`PRAGMA main.max_page_count=${maxPageCountTestOnly}`);
      }
      if (queryOnlyTestOnly) this.#db.exec('PRAGMA query_only=ON');
      ACTIVE_PATHS.add(this.#file);
    } catch (error) {
      try { if (this.#db?.isTransaction) this.#db.exec('ROLLBACK'); } catch {}
      try { this.#db?.close(); } catch {}
      this.#closed = true;
      throw sqlError(error, true);
    }
  }

  #pathBinding() {
    try {
      const dir = lstatSync(this.#directory), stat = lstatSync(this.#file);
      if (dir.isSymbolicLink() || !dir.isDirectory() || realpathSync(this.#directory) !== this.#directory
          || (dir.mode & 0o777) !== 0o700 || dir.uid !== process.getuid()) fail('store_path_replaced');
      if (stat.isSymbolicLink() || !stat.isFile() || stat.nlink !== 1) fail('store_path_replaced');
      if ((stat.mode & 0o777) !== 0o600 || stat.uid !== process.getuid()) fail('store_permissions_invalid');
      return { pathHash: hash(Buffer.from(this.#file)), device: String(stat.dev), inode: String(stat.ino) };
    } catch (error) {
      if (error instanceof StoreError) throw error;
      fail(error.code === 'ENOENT' ? 'store_missing' : 'store_path_unavailable');
    }
  }
  #validatedRef(ref) { if (this.#profile) fail('legacy_rows_unsupported'); return this.#contracts.validateDocument(document(ref), 'RecordRef'); }
  #validatedOp(ref) { if (this.#profile) fail('legacy_rows_unsupported'); return this.#contracts.validateDocument(document(ref), 'OperationRef'); }
  #ready() {
    if (this.#closed) fail('store_closed');
    if (this.#poisoned) fail('store_unavailable');
    try { if (!equal(this.#pathBinding(), this.#binding)) fail('store_path_replaced'); }
    catch (error) { this.#poisoned = true; throw error; }
  }
  #sql(fn) {
    this.#ready();
    try { return fn(); }
    catch (error) {
      const safe = sqlError(error);
      if (['storage_io', 'storage_locked', 'store_corrupt'].includes(safe.code)) this.#poisoned = true;
      throw safe;
    }
  }
  #write() { this.#ready(); if (!this.#inside || !this.#db.isTransaction) fail('transaction_required'); }
  #assertSettings() {
    for (const [name, expected] of Object.entries(REQUIRED)) {
      const actual = Object.values(this.#db.prepare(`PRAGMA main.${name}`).get())[0];
      if (actual !== expected) fail('durability_settings_mismatch');
    }
  }
  #create() {
    this.#db.exec(Object.values(this.#profile?.tables ?? TABLES).join(';') + `; PRAGMA application_id=${APP_ID}; PRAGMA user_version=${this.#profile?.version ?? 1};`);
    const put = this.#db.prepare('INSERT INTO metadata(key,value) VALUES(?,?)');
    for (const [name, value] of Object.entries({ identity: this.#identity, storeBinding: this.#binding,
      storeFormat: this.#profile?.format ?? this.#contracts.storeFormat, sequence: 0, clockHighWater: 0 })) put.run(name, Buffer.from(canonicalize(value)));
  }
  #validateExisting() {
    if (this.#db.prepare('PRAGMA application_id').get().application_id !== APP_ID
        || this.#db.prepare('PRAGMA user_version').get().user_version !== (this.#profile?.version ?? 1)) fail('unsupported_store_schema');
    if (this.#db.prepare('PRAGMA quick_check').get().quick_check !== 'ok') fail('store_corrupt');
    const get = name => {
      const row = this.#db.prepare('SELECT value FROM metadata WHERE key=?').get(name);
      if (!row) fail('unsupported_store_schema');
      return parseDomainDocument(bytes(row.value));
    };
    if (get('storeFormat') !== (this.#profile?.format ?? this.#contracts.storeFormat)) fail('unsupported_store_schema');
    if (!equal(get('identity'), this.#identity) || !equal(get('storeBinding'), this.#binding)) fail('store_identity_mismatch');
    for (const name of ['sequence', 'clockHighWater']) {
      const value = get(name);
      if (!Number.isSafeInteger(value) || value < 0) fail('store_corrupt');
    }
    // Reserved BLOB rows are validated before the reopened owner becomes ready.
    for (const row of this.#db.prepare('SELECT key FROM metadata WHERE substr(key,1,?)=?')
      .iterate(PRIVATE_BYTES_PREFIX.length, PRIVATE_BYTES_PREFIX)) this.#privateBytesRow(row.key);
    const definitions = this.#db.prepare("SELECT name,type,sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%'").all();
    const tables = this.#profile?.tables ?? TABLES;
    if (definitions.length !== Object.keys(tables).length || definitions.some(row => row.type !== 'table'
        || !tables[row.name] || normalizedSQL(row.sql) !== normalizedSQL(tables[row.name]))) fail('unsupported_store_schema');
    if (this.#profile) { this.#profile.validateExisting(this.#db, this.#identity); return; }
    // Startup validates retained bytes and every authoritative operation before readiness.
    for (const row of this.#db.prepare('SELECT authority,kind,id,version FROM records').iterate()) {
      this.#recordRow({ authorityId: row.authority, kind: row.kind, id: row.id, version: row.version });
    }
    for (const row of this.#db.prepare('SELECT name,ref FROM heads').iterate()) {
      try { if (!key(row.name) || !this.#recordRow(this.#contracts.validateDocument(bytes(row.ref), 'RecordRef'))) fail('store_corrupt'); }
      catch { fail('store_corrupt'); }
    }
    for (const row of this.#db.prepare('SELECT authority,principal,work_id,kind,id FROM operations').iterate()) {
      const scope = this.#validatedOp({ authorityId: row.authority, principalId: row.principal, workId: row.work_id, operationKind: row.kind, operationId: row.id });
      if (scope.authorityId !== this.#identity.authorityId || scope.workId !== this.#identity.workId) fail('store_corrupt');
      this.#operationRow(scope);
    }
  }

  settings() {
    return this.#sql(() => Object.freeze(Object.fromEntries(Object.keys(REQUIRED).map(name =>
      [name, Object.values(this.#db.prepare(`PRAGMA main.${name}`).get())[0]]))));
  }
  transaction(fn, { beforeCommit } = {}) {
    this.#ready();
    if (this.#inside || typeof fn !== 'function' || (beforeCommit !== undefined && typeof beforeCommit !== 'function')) fail('invalid_transaction');
    let committed = false;
    try {
      this.#db.exec('BEGIN EXCLUSIVE'); this.#inside = true;
      const result = fn(this);
      if (result instanceof Promise || (result !== null && typeof result === 'object' && typeof result.then === 'function')) fail('async_transaction_forbidden');
      this.#testFault?.('beforeCommit', this);
      beforeCommit?.();
      this.#ready();
      this.#db.exec('COMMIT'); committed = true; this.#inside = false;
      this.#testFault?.('afterCommit', this);
      return result;
    } catch (error) {
      this.#inside = false;
      if (committed) { this.#poisoned = true; fail('commit_outcome_unknown'); }
      try {
        if (this.#db.isTransaction) { this.#testFault?.('beforeRollback', this); this.#db.exec('ROLLBACK'); }
        if (this.#db.isTransaction || this.#db.prepare('SELECT 1 AS ok').get().ok !== 1) throw new Error('unusable');
      } catch { this.#poisoned = true; fail('rollback_state_unknown'); }
      if (error?.code === 'ERR_SQLITE_ERROR' || Number.isInteger(error?.errcode)) {
        const safe = sqlError(error); if (['storage_io', 'storage_locked', 'store_corrupt'].includes(safe.code)) this.#poisoned = true; throw safe;
      }
      throw error;
    }
  }
  close() {
    if (this.#closed) return;
    try { if (this.#db.isTransaction) this.#db.exec('ROLLBACK'); this.#db.close(); }
    catch { this.#closed = true; ACTIVE_PATHS.delete(this.#file); fail('store_close_failed'); }
    this.#closed = true; ACTIVE_PATHS.delete(this.#file);
  }
  // Source-only adapter seam. A profile can neither replace the database owner
  // nor weaken this class's transaction and path checks. Legacy callers cannot
  // accidentally enter it; no such operation is exposed over participant JSON.
  profileRead(name, args = []) {
    if (!this.#profile || typeof name !== 'string' || !Object.hasOwn(this.#profile.readQueries, name)) fail('storage_profile_query');
    const parameters = profileArguments(args);
    return this.#sql(() => this.#db.prepare(this.#profile.readQueries[name]).all(...parameters));
  }
  profileWrite(name, args = []) {
    this.#write(); if (!this.#profile || typeof name !== 'string' || !Object.hasOwn(this.#profile.writeQueries, name)) fail('storage_profile_query');
    const parameters = profileArguments(args);
    return this.#sql(() => this.#db.prepare(this.#profile.writeQueries[name]).run(...parameters));
  }
  getMeta(name) {
    if (!key(name)) fail('invalid_metadata_key');
    if (name.startsWith(PRIVATE_BYTES_PREFIX)) fail('private_bytes_namespace');
    return this.#sql(() => { const row = this.#db.prepare('SELECT value FROM metadata WHERE key=?').get(name);
      if (!row) return null; try { return parseDomainDocument(bytes(row.value)); } catch { this.#poisoned = true; fail('store_corrupt'); } });
  }
  setMeta(name, value) {
    this.#write(); if (!key(name) || ['identity', 'storeBinding', 'storeFormat'].includes(name)) fail('immutable_metadata');
    if (name.startsWith(PRIVATE_BYTES_PREFIX)) fail('private_bytes_namespace');
    if (['sequence', 'clockHighWater'].includes(name) && (!Number.isSafeInteger(value) || value < 0 || value < this.getMeta(name))) fail('monotone_metadata_required');
    const encoded = Buffer.from(canonicalize(plain(value))); parseDomainDocument(encoded);
    return this.#sql(() => this.#db.prepare('INSERT INTO metadata(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(name, encoded));
  }
  privateMetadataKeys(prefix) {
    if (!['agent-return:invitation:', 'agent-return-op:'].includes(prefix)) fail('invalid_private_metadata_prefix');
    return this.#sql(() => {
      const rows = this.#db.prepare('SELECT key FROM metadata WHERE substr(key,1,length(?))=? ORDER BY key').all(prefix, prefix);
      if (rows.some(row => !key(row.key))) fail('store_corrupt');
      return Object.freeze(rows.map(row => row.key));
    });
  }
  #privateBytesRow(name) {
    // Check length inside SQLite before materializing a corrupt oversized BLOB.
    const row = this.#db.prepare('SELECT length(value) AS byteLength, CASE WHEN length(value)<=? THEN value ELSE NULL END AS value FROM metadata WHERE key=?')
      .get(PRIVATE_BYTES_HEADER + PRIVATE_BYTES_MAX, name);
    if (!row) return null;
    if (!Number.isSafeInteger(row.byteLength) || row.byteLength < PRIVATE_BYTES_HEADER
        || row.byteLength > PRIVATE_BYTES_HEADER + PRIVATE_BYTES_MAX) fail('store_corrupt');
    return privatePayload(name, bytes(row.value));
  }
  getPrivateBytes(name) {
    if (!privateKey(name)) fail('invalid_private_bytes_key');
    return this.#sql(() => this.#privateBytesRow(name));
  }
  putPrivateBytes(name, input) {
    this.#write();
    if (!privateKey(name)) fail('invalid_private_bytes_key');
    const payload = privateSnapshot(input);
    return this.#sql(() => {
      const prior = this.#privateBytesRow(name);
      if (prior !== null) {
        if (!prior.equals(payload)) fail('private_bytes_conflict');
        return false;
      }
      this.#db.prepare('INSERT INTO metadata(key,value) VALUES(?,?)').run(name, privateFrame(name, payload));
      return true;
    });
  }
  #recordRow(ref) {
    const row = this.#db.prepare('SELECT * FROM records WHERE authority=? AND kind=? AND id=? AND version=?')
      .get(ref.authorityId, ref.kind, ref.id, ref.version);
    if (!row) return null;
    try {
      const record = this.#contracts.validateDocument(bytes(row.canonical), 'Record');
      const canonical = this.#contracts.canonicalRecordBytes(bytes(row.canonical));
      const expectedOriginal = original(record);
      if (!equal(this.#contracts.recordReference(bytes(row.canonical)), ref) || record.authorityId !== this.#identity.authorityId || row.work_id !== this.#identity.workId
          || !canonical.equals(bytes(row.canonical)) || row.digest !== this.#contracts.recordDigest(bytes(row.canonical)).value
          || (expectedOriginal === null ? row.original !== null : row.original === null || !expectedOriginal.equals(bytes(row.original)))) fail('store_corrupt');
      return { record, canonical, original: expectedOriginal, digest: { algorithm: 'sha-256', subject: this.#contracts.recordDigestSubject, value: row.digest } };
    } catch { this.#poisoned = true; fail('store_corrupt'); }
  }
  getRecord(ref) { const safe = this.#validatedRef(ref); return this.#sql(() => this.#recordRow(safe)?.record ?? null); }
  getRecordBytes(ref) { const safe = this.#validatedRef(ref); return this.#sql(() => this.#recordRow(safe)?.canonical ?? null); }
  getOriginal(ref) { const safe = this.#validatedRef(ref); return this.#sql(() => this.#recordRow(safe)?.original ?? null); }
  putRecord(raw) {
    this.#write(); if (this.#profile) fail('legacy_rows_unsupported'); const record = this.#contracts.validateDocument(document(raw), 'Record');
    // Derive every stored field from the first validated snapshot: raw may be mutable bytes.
    const snapshot = canonicalize(record);
    const ref = this.#contracts.recordReference(snapshot), workId = record.kind === 'work' ? record.id : record.workRef.id;
    if (record.authorityId !== this.#identity.authorityId || workId !== this.#identity.workId) fail('record_scope_mismatch');
    const canonical = this.#contracts.canonicalRecordBytes(snapshot), digest = this.#contracts.recordDigest(snapshot);
    return this.#sql(() => {
      const prior = this.#recordRow(ref);
      if (prior) { if (!prior.canonical.equals(canonical)) fail('record_conflict'); return { record: prior.record, ref, digest, created: false }; }
      this.#db.prepare('INSERT INTO records(authority,kind,id,version,work_id,canonical,digest,original) VALUES(?,?,?,?,?,?,?,?)')
        .run(ref.authorityId, ref.kind, ref.id, ref.version, workId, canonical, digest.value, original(record));
      return { record, ref, digest, created: true };
    });
  }
  getHead(name) {
    if (this.#profile) fail('legacy_rows_unsupported');
    if (!key(name)) fail('invalid_head_key');
    return this.#sql(() => { const row = this.#db.prepare('SELECT ref FROM heads WHERE name=?').get(name); if (!row) return null;
      try { const ref = this.#contracts.validateDocument(bytes(row.ref), 'RecordRef'); if (!this.#recordRow(ref)) fail('store_corrupt'); return ref; }
      catch { this.#poisoned = true; fail('store_corrupt'); } });
  }
  setHead(name, ref) {
    this.#write(); const safe = this.#validatedRef(ref); if (!key(name)) fail('invalid_head_key');
    return this.#sql(() => { if (!this.#recordRow(safe)) fail('head_record_missing');
      this.#db.prepare('INSERT INTO heads(name,ref) VALUES(?,?) ON CONFLICT(name) DO UPDATE SET ref=excluded.ref').run(name, Buffer.from(canonicalize(safe))); });
  }
  #operationRow(scope) {
    const row = this.#db.prepare('SELECT fingerprint,response FROM operations WHERE authority=? AND principal=? AND work_id=? AND kind=? AND id=?').get(...opValues(scope));
    if (!row) return null;
    try {
      const response = this.#contracts.validateDocument(bytes(row.response), 'Response');
      if (!equal(response.operationRef, scope) || response.processing !== 'completed' || !response.outcomeRef || !response.outcome) fail('store_corrupt');
      const fingerprint = response.outcome.fingerprint;
      if ((fingerprint?.value ?? null) !== row.fingerprint) fail('store_corrupt');
      const outcome = this.#recordRow(response.outcomeRef)?.record;
      if (!outcome || outcome.kind !== 'outcome' || !equal(outcome.data.operationRef, scope)) fail('store_corrupt');
      for (const field of ['state', 'fingerprint', 'retainedRefs', 'acceptedRefs', 'reason']) if (!equal(outcome.data[field], response.outcome[field])) fail('store_corrupt');
      for (const binding of outcome.data.recordBindings) {
        const record = this.#recordRow(binding.ref); if (!record || !equal(record.digest, binding.digest)) fail('store_corrupt');
      }
      return Object.freeze({ fingerprint, response });
    } catch { this.#poisoned = true; fail('store_corrupt'); }
  }
  getOperation(ref) { const scope = this.#validatedOp(ref); return this.#sql(() => this.#operationRow(scope)); }
  putOperation(ref, { fingerprint, response }) {
    this.#write(); const scope = this.#validatedOp(ref), safeResponse = this.#contracts.validateDocument(document(response), 'Response');
    const safeFingerprint = fingerprint === null ? null : this.#contracts.validateDocument(document(fingerprint), 'OperationDigest');
    if (scope.authorityId !== this.#identity.authorityId || scope.workId !== this.#identity.workId
        || !equal(scope, safeResponse.operationRef) || !equal(safeFingerprint, safeResponse.outcome?.fingerprint)) fail('operation_scope_mismatch');
    return this.#sql(() => {
      const prior = this.#operationRow(scope);
      if (prior) { if (!equal(prior, { fingerprint: safeFingerprint, response: safeResponse })) fail('operation_conflict'); return false; }
      // The engine has already staged the outcome and required unit in this transaction.
      this.#db.prepare('INSERT INTO operations(authority,principal,work_id,kind,id,fingerprint,response) VALUES(?,?,?,?,?,?,?)')
        .run(...opValues(scope), safeFingerprint?.value ?? null, Buffer.from(canonicalize(safeResponse)));
      this.#operationRow(scope);
      return true;
    });
  }
}
