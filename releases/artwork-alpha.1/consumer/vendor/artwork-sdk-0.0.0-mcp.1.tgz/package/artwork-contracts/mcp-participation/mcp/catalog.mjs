// Tool schemas for this candidate only; pure validators remain the complete
// byte/domain checks. No server, transport or dynamic tool code is loaded.
import { freeze } from '../src/core.mjs';
const name = { type: 'string', minLength: 1, maxLength: 128, pattern: '^[A-Za-z0-9][A-Za-z0-9._:-]*$' };
const identifier = { type: 'string', minLength: 1, maxLength: 512, pattern: '^[A-Za-z][A-Za-z0-9+.-]*:[!-~]+$' };
const object = (properties, required = Object.keys(properties)) => ({ type: 'object', properties, required, additionalProperties: false });
const digest = domain => object({ algorithm: { const: 'sha-256' }, domain: { const: domain }, value: { type: 'string', pattern: '^[a-f0-9]{64}$' } });
const data = object({ kind: { const: 'data' }, digest: digest('payload-octets-v1'), length: { type: 'integer', minimum: 0, maximum: 65536 }, mediaType: { type: 'string', minLength: 1, maxLength: 255 } });
const record = type => object({ kind: { const: 'record' }, type: { const: type }, identity: object({ namespace: identifier, id: name, revision: name }), digest: digest('aap-record-jcs-draft1') });
const expression = { oneOf: [object({ form: { const: 'material' }, mediaType: { type: 'string', minLength: 1, maxLength: 255 }, text: { type: 'string', maxLength: 65536 } }),
  object({ form: { const: 'refusal' }, statement: { type: 'string', maxLength: 65536 } }, ['form'])] };
const reason = { oneOf: [object({ state: { const: 'known' }, value: name }), object({ state: { enum: ['not-recorded', 'unknown', 'unavailable', 'withheld'] } })] };
const outputSchema = object({ schema: { const: 'aap.sdk.mcp-result.draft1' }, processing: { enum: ['completed', 'denied', 'invalid', 'unsupported', 'unavailable', 'unknown'] },
  reason, value: { type: ['object', 'null'] } });
const specs = [
  ['resume_work', object({ work: name, cursor: name }, ['work']), 'Recover permitted Work context and your own return index. May persist clock metadata.'],
  ['read_context', object({ work: name }), 'Read the exact selected Context. Does not read private chat history or establish model execution. Persists clock metadata.'],
  ['prepare_return', object({ work: name, context: record('context'), prepareId: name, revisionOf: record('act') }, ['work', 'context', 'prepareId']), 'Reserve one finite return under current Work rights. Retry the same prepareId to recover; do not replace an unknown outcome with a new one.'],
  ['submit_expression', object({ work: name, returnHandle: name, reservation: data, expression }), 'Record one exact expression or explicit refusal. A Receipt covers recording, separately from artistic acceptance or rendering.'],
  ['return_status', object({ work: name, returnHandle: name }), 'Recover your exact outcome. May finalize expiry/revocation and persist a fence; not a pure read.'],
  ['cancel_return', object({ work: name, returnHandle: name }), 'Resolve and fence a permitted uncommitted return. Existing committed outcomes win; cancellation does not reverse them.'],
  ['inspect_process', { ...object({ work: name, selection: name, cursor: name, data }, ['work', 'selection']),
    not: { type: 'object', properties: { cursor: name, data }, required: ['cursor', 'data'] } }, 'Read one owner-selected canonical record page or exact selected UTF-8 original. Source is inert; no SVG/HTML rendering. May persist clock metadata.'],
];
export const TOOL_CATALOG = freeze(specs.map(([tool, inputSchema, description]) => ({ name: tool, inputSchema, outputSchema, description,
  annotations: { readOnlyHint: false, destructiveHint: ['submit_expression', 'return_status', 'cancel_return'].includes(tool),
    idempotentHint: ['prepare_return', 'submit_expression', 'cancel_return'].includes(tool), openWorldHint: false } })));
export const ADAPTER_INFO = freeze({ name: 'agent-art-participation-methods', version: '0.0.0-mcp.1',
  schemaCohort: '@modelcontextprotocol/core@2.4.0', methods: ['tools/list', 'tools/call'],
  maxRequestBytes: 2097152, maxResultBytes: 1048576, maxSummaryBytes: 1024 });
