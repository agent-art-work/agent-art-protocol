// Inert metadata derivative. Never fetches locators, executes a rule or renders
// original text/SVG/HTML. Canonical source records remain separately identified.
import { validateRecord, parseValidated, recordReference, canonicalBytes, payloadReference,
  freeze } from './core.mjs';
export function projectInspection(recordJson, manifestJson) {
  const record = recordJson === null ? null : validateRecord(recordJson);
  const manifest = parseValidated(manifestJson, (v, c, p) => c.ref(v, p, 'manifest'));
  const summary = record ? { source: recordReference(recordJson), type: record.type, issuer: record.issuer,
    provenance: record.provenance.mode, gaps: record.provenance.gaps,
    ...(record.type === 'act' ? { contributor: record.body.contributor, transmitter: record.body.transmitter,
      expression: record.body.expression.state === 'known' ? record.body.expression.value.form : record.body.expression.state } : {}),
    ...(record.type === 'receipt' ? { recording: record.body.outcome } : {}),
    ...(record.type === 'report' ? { appReport: { category: record.body.category, outcome: record.body.outcome,
      findingBasis: 'issuer-declaration-not-independent-verification' } } : {}) } : null;
  const value = canonicalBytes({ schema: 'aap.sdk.mcp-inert-page.draft1', manifest, summary,
    limits: ['selected-account-not-complete-history', 'originals-require-selected-data-read', 'rendering-unobserved', 'model-origin-unverified'] }).toString();
  return freeze({ ref: payloadReference(value, 'application/json'), encoding: 'utf8', value });
}
