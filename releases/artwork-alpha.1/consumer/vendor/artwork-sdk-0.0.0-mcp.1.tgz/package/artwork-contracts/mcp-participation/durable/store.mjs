// Version-2 row mapping over the existing SqliteStore owner/transaction boundary.
// Fresh databases only. No listener, model, OAuth implementation or legacy migration.
import { createHash } from 'node:crypto';
import { SqliteStore, StoreError } from '../../src/store.mjs';
import { parseValidated, validateRecord, recordReference, canonicalBytes, payloadReference,
  requestDigest, checkOperation, equal, fail } from '../src/core.mjs';
import { validateReservationState } from '../src/reservation.mjs';

export const STORE_FORMAT = 'aap.mcp-participation.store.v2';
const json = JSON.stringify, buffer = v => Buffer.from(v);
const unavailable = () => { throw new StoreError('store_corrupt'); };
export const recordKey = ref => canonicalBytes(ref.identity).toString();
export const dataKey = ref => canonicalBytes(ref).toString();
export const operationKeyText = op => canonicalBytes(op).toString();
export const preparationKey = d => canonicalBytes({ binding: d.binding, principal: d.transmitter,
  work: d.scope.work, epoch: d.operation.epoch, id: d.prepareId }).toString();
const checksum = (...parts) => {
  const hash = createHash('sha256').update('AAP-MCP-STORE-v2\0');
  for (const part of parts) {
    const b = part === null ? Buffer.from('null:') : typeof part === 'string' ? Buffer.from('text:' + part)
      : typeof part === 'number' ? Buffer.from('uint:' + part) : Buffer.concat([Buffer.from('bytes:'), buffer(part)]);
    hash.update(String(b.length) + ':').update(b);
  }
  return hash.digest('hex');
};
const blob = (v, limit = 2097152) => {
  if (!(v instanceof Uint8Array) || v.length > limit) unavailable(); return buffer(v);
};
function parse(bytes, validator = () => {}, max = 2097152) {
  const b = blob(bytes, max), value = parseValidated(b, validator, max);
  if (!canonicalBytes(value).equals(b)) unavailable(); return value;
}
export function validateIdentity(input) {
  return parseValidated(input, (v, c) => {
    c.object(v, ['work', 'binding', 'owner', 'receiver']); c.ref(v.work, ['work'], 'work'); c.ref(v.binding, ['binding'], 'binding');
    c.identifier(v.owner); c.identifier(v.receiver);
  });
}
const tables = Object.freeze({
  metadata: 'CREATE TABLE metadata(key TEXT PRIMARY KEY, value BLOB NOT NULL) STRICT',
  protocol_records: `CREATE TABLE protocol_records(key TEXT PRIMARY KEY, reference BLOB NOT NULL,
    canonical BLOB, available_until TEXT NOT NULL, retirement BLOB, checksum TEXT NOT NULL) STRICT`,
  protocol_data: `CREATE TABLE protocol_data(key TEXT PRIMARY KEY, reference BLOB NOT NULL,
    original BLOB, available_until TEXT NOT NULL, history BLOB NOT NULL, checksum TEXT NOT NULL) STRICT`,
  protocol_controls: 'CREATE TABLE protocol_controls(key TEXT PRIMARY KEY, canonical BLOB NOT NULL, checksum TEXT NOT NULL) STRICT',
  protocol_operations: `CREATE TABLE protocol_operations(key TEXT PRIMARY KEY, handle TEXT NOT NULL UNIQUE,
    preparation TEXT NOT NULL UNIQUE, principal TEXT NOT NULL, sequence INTEGER NOT NULL,
    descriptor BLOB NOT NULL, state BLOB NOT NULL, request BLOB, fingerprint TEXT,
    receipt_key TEXT, checksum TEXT NOT NULL) STRICT`,
  protocol_staging: `CREATE TABLE protocol_staging(operation TEXT NOT NULL, data_key TEXT NOT NULL,
    reference BLOB NOT NULL, original BLOB NOT NULL, checksum TEXT NOT NULL,
    PRIMARY KEY(operation,data_key)) STRICT`,
});
const recordProjection = 'key, CASE WHEN length(reference)<=65536 THEN reference END AS reference, CASE WHEN length(canonical)<=65536 THEN canonical END AS canonical, available_until, CASE WHEN length(retirement)<=65536 THEN retirement END AS retirement, checksum';
const dataProjection = 'key, CASE WHEN length(reference)<=65536 THEN reference END AS reference, CASE WHEN length(original)<=65536 THEN original END AS original, available_until, CASE WHEN length(history)<=65536 THEN history END AS history, checksum';
const opProjection = 'key,handle,preparation,principal,sequence, CASE WHEN length(descriptor)<=65536 THEN descriptor END AS descriptor, CASE WHEN length(state)<=2097152 THEN state END AS state, CASE WHEN length(request)<=262144 THEN request END AS request, fingerprint,receipt_key,checksum';
const controlProjection = 'key, CASE WHEN length(canonical)<=2097152 THEN canonical END AS canonical, checksum';
const stagingProjection = 'operation,data_key, CASE WHEN length(reference)<=65536 THEN reference END AS reference, CASE WHEN length(original)<=65536 THEN original END AS original, checksum';
const readQueries = Object.freeze({
  record: `SELECT ${recordProjection} FROM protocol_records WHERE key=?`,
  records: `SELECT ${recordProjection} FROM protocol_records ORDER BY key`,
  data: `SELECT ${dataProjection} FROM protocol_data WHERE key=?`,
  allData: `SELECT ${dataProjection} FROM protocol_data ORDER BY key`,
  control: `SELECT ${controlProjection} FROM protocol_controls WHERE key=?`,
  controls: `SELECT ${controlProjection} FROM protocol_controls ORDER BY key`,
  operation: `SELECT ${opProjection} FROM protocol_operations WHERE handle=?`,
  operationKey: `SELECT ${opProjection} FROM protocol_operations WHERE key=?`,
  prepared: `SELECT ${opProjection} FROM protocol_operations WHERE preparation=?`,
  operations: `SELECT ${opProjection} FROM protocol_operations ORDER BY sequence`,
  staged: `SELECT ${stagingProjection} FROM protocol_staging WHERE operation=? ORDER BY data_key`,
  allStaged: `SELECT ${stagingProjection} FROM protocol_staging ORDER BY operation,data_key`,
});
const writeQueries = Object.freeze({
  record: 'INSERT INTO protocol_records(key,reference,canonical,available_until,retirement,checksum) VALUES(?,?,?,?,?,?) ON CONFLICT(key) DO UPDATE SET canonical=excluded.canonical,available_until=excluded.available_until,retirement=excluded.retirement,checksum=excluded.checksum',
  data: 'INSERT INTO protocol_data(key,reference,original,available_until,history,checksum) VALUES(?,?,?,?,?,?) ON CONFLICT(key) DO UPDATE SET original=excluded.original,available_until=excluded.available_until,history=excluded.history,checksum=excluded.checksum',
  control: 'INSERT INTO protocol_controls(key,canonical,checksum) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET canonical=excluded.canonical,checksum=excluded.checksum',
  operation: 'INSERT INTO protocol_operations(key,handle,preparation,principal,sequence,descriptor,state,request,fingerprint,receipt_key,checksum) VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(key) DO UPDATE SET state=excluded.state,request=excluded.request,fingerprint=excluded.fingerprint,receipt_key=excluded.receipt_key,checksum=excluded.checksum',
  staging: 'INSERT INTO protocol_staging(operation,data_key,reference,original,checksum) VALUES(?,?,?,?,?) ON CONFLICT(operation,data_key) DO NOTHING',
  clearStaging: 'DELETE FROM protocol_staging WHERE operation=?',
});
function checkedRecord(row, identity) {
  if (!row) return null;
  try {
    const ref = parse(row.reference, (v, c, p) => c.ref(v, p)), until = row.available_until;
    parseValidated(json(until), (v, c) => c.time(v));
    if (row.key !== recordKey(ref) || row.checksum !== checksum(row.key, row.reference, row.canonical, until, row.retirement)) unavailable();
    if (row.canonical === null) {
      const retirement = parse(row.retirement); checkRetirement(retirement, identity); return { ref, record: null, until, retirement };
    }
    if (row.retirement !== null) unavailable();
    const record = validateRecord(blob(row.canonical, 65536));
    if (!canonicalBytes(record).equals(buffer(row.canonical)) || !equal(recordReference(json(record)), ref)) unavailable();
    if (record.type === 'work' ? !equal(ref, identity.work) : record.type === 'binding' ? !equal(ref, identity.binding)
      : !equal(record.scope, { work: identity.work })) unavailable();
    return { ref, record, until, retirement: null };
  } catch { unavailable(); }
}
function checkRetirement(value, identity) {
  parseValidated(json(value), (v, c) => {
    c.object(v, ['at', 'actor', 'policy', 'reason']); c.time(v.at); c.identifier(v.actor); c.rule(v.policy, ['policy']); c.name(v.reason);
    if (v.actor !== identity.owner) fail('retirement_actor');
  });
}
function checkedData(row, identity) {
  if (!row) return null;
  try {
    const ref = parse(row.reference, (v, c, p) => c.data(v, p)), history = parse(row.history);
    parseValidated(json(row.available_until), (v, c) => c.time(v));
    if (!Array.isArray(history) || history.length > 256 || row.key !== dataKey(ref)
      || row.checksum !== checksum(row.key, row.reference, row.original, row.available_until, row.history)) unavailable();
    history.forEach(v => checkRetirement(v, identity));
    if (row.original === null ? !history.length : !equal(payloadReference(blob(row.original, 65536), ref.mediaType), ref)) unavailable();
    return { ref, original: row.original === null ? null : buffer(row.original), until: row.available_until, history };
  } catch { unavailable(); }
}
function checkedControl(row) {
  if (!row) return null;
  try {
    if (!/^[A-Za-z0-9][A-Za-z0-9._:-]{0,254}$/.test(row.key) || row.checksum !== checksum(row.key, row.canonical)) unavailable();
    return parse(row.canonical);
  } catch { unavailable(); }
}
function checkedOperation(row, identity, readRecord) {
  if (!row) return null;
  try {
    const state = validateReservationState(blob(row.state)), d = state.descriptor;
    if (!canonicalBytes(state).equals(buffer(row.state)) || !buffer(row.descriptor).equals(canonicalBytes(d))
      || !equal(d.scope.work, identity.work) || !equal(d.binding, identity.binding) || d.receiver !== identity.receiver
      || row.key !== operationKeyText(d.operation) || row.preparation !== preparationKey(d) || row.principal !== d.transmitter
      || !Number.isSafeInteger(row.sequence) || row.sequence < 1 || !/^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/.test(row.handle)
      || row.checksum !== checksum(row.key, row.handle, row.preparation, row.principal, row.sequence, row.descriptor, row.state, row.request, row.fingerprint, row.receipt_key)) unavailable();
    const req = state.request.state === 'known' ? canonicalBytes(state.request.value) : null;
    if (req === null ? row.request !== null || row.fingerprint !== null
      : row.request === null || !req.equals(buffer(row.request)) || row.fingerprint !== requestDigest(json(state.request.value)).value) unavailable();
    if (state.receipt.state === 'known') {
      const receipt = state.receipt.value, ref = recordReference(json(receipt));
      if (row.receipt_key !== recordKey(ref) || !equal(readRecord(ref)?.record, receipt)) unavailable();
    } else if (row.receipt_key !== null) unavailable();
    return { handle: row.handle, preparation: row.preparation, sequence: row.sequence, state };
  } catch { unavailable(); }
}
function checkedStaged(row) {
  try {
    const ref = parse(row.reference, (v, c, p) => c.data(v, p)), original = blob(row.original, 65536);
    parseValidated(row.operation, checkOperation);
    if (row.data_key !== dataKey(ref) || !equal(payloadReference(original, ref.mediaType), ref)
      || row.checksum !== checksum(row.operation, row.data_key, row.reference, row.original)) unavailable();
    return { ref, original };
  } catch { unavailable(); }
}
const PROFILE = Object.freeze({ format: STORE_FORMAT, version: 2, tables, readQueries, writeQueries, validateIdentity,
  validateExisting(db, identity) {
    try {
      const rows = name => db.prepare(readQueries[name]).all();
      const records = new Map(rows('records').map(row => [row.key, checkedRecord(row, identity)]));
      rows('allData').forEach(row => checkedData(row, identity)); rows('controls').forEach(checkedControl);
      const operations = rows('operations');
      const indexed = new Map(operations.map(row => [row.key, checkedOperation(row, identity, ref => records.get(recordKey(ref)))]));
      const stagedRows = rows('allStaged');
      for (const row of stagedRows) {
        const value = checkedStaged(row), op = indexed.get(row.operation);
        if (!op || op.state.request.state !== 'known' || op.state.receipt.state === 'known'
          || !op.state.request.value.materials.some(ref => equal(ref, value.ref))) unavailable();
      }
      for (const [key, op] of indexed) if (op.state.request.state === 'known' && op.state.receipt.state !== 'known') {
        const material = stagedRows.filter(row => row.operation === key).map(checkedStaged);
        if (material.length !== op.state.request.value.materials.length
          || op.state.request.value.materials.some(ref => !material.some(x => equal(x.ref, ref)))) unavailable();
      }
    } catch { unavailable(); }
  } });

export class ParticipationStore {
  #base; #identity;
  constructor({ directory, identity, ...testing }, initialize) {
    if (Object.keys(testing).some(k => !['testFault', 'maxPageCountTestOnly', 'queryOnlyTestOnly'].includes(k))) throw new StoreError('store_options');
    this.#identity = validateIdentity(json(identity));
    this.#base = SqliteStore[initialize ? 'initialize' : 'open']({ ...testing, directory, identity: this.#identity, storageProfile: PROFILE });
  }
  static initialize(options) { return new ParticipationStore(options, true); }
  static open(options) { return new ParticipationStore(options, false); }
  close() { this.#base.close(); }
  settings() { return this.#base.settings(); }
  transaction(fn, beforeCommit) { return this.#base.transaction(() => fn(this), { beforeCommit }); }
  highWater() { return this.#base.getMeta('clockHighWater'); }
  setHighWater(value) { this.#base.setMeta('clockHighWater', value); }
  sequence() { const n = this.#base.getMeta('sequence') + 1; this.#base.setMeta('sequence', n); return n; }
  #read(name, args = []) { return this.#base.profileRead(name, args); }
  #write(name, args) { return this.#base.profileWrite(name, args); }
  control(key) { return checkedControl(this.#read('control', [key])[0]); }
  controls() { return this.#read('controls').map(row => ({ key: row.key, value: checkedControl(row) })); }
  putControl(key, value) {
    if (typeof key !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9._:-]{0,254}$/.test(key)) throw new StoreError('control_key');
    const b = canonicalBytes(parseValidated(json(value), () => {})); return this.#write('control', [key, b, checksum(key, b)]);
  }
  record(ref) {
    const row = checkedRecord(this.#read('record', [recordKey(ref)])[0], this.#identity);
    if (row && !equal(row.ref, ref)) throw new StoreError('record_reference_mismatch'); return row;
  }
  putRecord(input, until) {
    parseValidated(json(until), (v, c) => c.time(v));
    const record = validateRecord(input), ref = recordReference(json(record)), prior = this.record(ref);
    const canonical = canonicalBytes(record), key = recordKey(ref), reference = canonicalBytes(ref);
    if (record.type === 'work' ? !equal(ref, this.#identity.work) : record.type === 'binding' ? !equal(ref, this.#identity.binding)
      : !equal(record.scope, { work: this.#identity.work })) throw new StoreError('record_scope_mismatch');
    if (prior && !prior.record) throw new StoreError('record_retired');
    const end = prior && prior.until > until ? prior.until : until;
    this.#write('record', [key, reference, canonical, end, null, checksum(key, reference, canonical, end, null)]); return ref;
  }
  data(ref) { const row = checkedData(this.#read('data', [dataKey(ref)])[0], this.#identity); return row; }
  putData(ref, bytes, until) {
    parseValidated(json(until), (v, c) => c.time(v));
    const b = buffer(bytes); if (!equal(payloadReference(b, ref.mediaType), ref)) throw new StoreError('data_reference_mismatch');
    const prior = this.data(ref), end = prior && prior.until > until ? prior.until : until;
    const history = canonicalBytes(prior?.history ?? []), key = dataKey(ref), reference = canonicalBytes(ref);
    this.#write('data', [key, reference, b, end, history, checksum(key, reference, b, end, history)]);
  }
  retireData(ref, retirement) {
    const row = this.data(ref); if (!row || !row.original) return false;
    if (retirement.at < row.until) throw new StoreError('retention_active'); checkRetirement(retirement, this.#identity);
    const history = canonicalBytes([...row.history, retirement]), key = dataKey(ref), reference = canonicalBytes(ref);
    if (row.history.length >= 256) throw new StoreError('availability_history_limit');
    this.#write('data', [key, reference, null, row.until, history, checksum(key, reference, null, row.until, history)]); return true;
  }
  retireRecord(ref, retirement) {
    const row = this.record(ref); if (!row?.record) return false;
    if (row.record.type === 'receipt') throw new StoreError('protected_receipt');
    if (retirement.at < row.until) throw new StoreError('retention_active'); checkRetirement(retirement, this.#identity);
    const key = recordKey(ref), reference = canonicalBytes(ref), mark = canonicalBytes(retirement);
    this.#write('record', [key, reference, null, row.until, mark, checksum(key, reference, null, row.until, mark)]); return true;
  }
  operation(handle) { return checkedOperation(this.#read('operation', [handle])[0], this.#identity, ref => this.record(ref)); }
  prepared(key) { return checkedOperation(this.#read('prepared', [key])[0], this.#identity, ref => this.record(ref)); }
  operations() { return this.#read('operations').map(row => checkedOperation(row, this.#identity, ref => this.record(ref))); }
  putOperation(handle, stateInput, sequence) {
    const state = validateReservationState(stateInput), d = state.descriptor;
    const prior = this.operation(handle), key = operationKeyText(d.operation), prep = preparationKey(d);
    const keyed = this.#read('operationKey', [key])[0];
    if (keyed && keyed.handle !== handle) throw new StoreError('operation_conflict');
    if (prior && (!equal(prior.state.descriptor, d) || prior.sequence !== sequence || state.clockHighWater < prior.state.clockHighWater
      || (prior.state.intent.state === 'known' && (!equal(prior.state.intent, state.intent) || !equal(prior.state.request, state.request)))
      || (prior.state.closure.state === 'known' && state.closure.state !== 'known')
      || (prior.state.fence === 'observed' && state.fence !== 'observed')
      || (prior.state.receipt.state === 'known' && !equal(prior.state.receipt, state.receipt)))) throw new StoreError('operation_conflict');
    const descriptor = canonicalBytes(d), bytes = canonicalBytes(state);
    const request = state.request.state === 'known' ? canonicalBytes(state.request.value) : null;
    const fingerprint = request ? requestDigest(json(state.request.value)).value : null;
    const receiptKey = state.receipt.state === 'known' ? recordKey(recordReference(json(state.receipt.value))) : null;
    this.#write('operation', [key, handle, prep, d.transmitter, sequence, descriptor, bytes, request, fingerprint, receiptKey,
      checksum(key, handle, prep, d.transmitter, sequence, descriptor, bytes, request, fingerprint, receiptKey)]);
    this.operation(handle);
  }
  stage(operation, carrier) {
    const key = operationKeyText(operation), ref = carrier.ref, b = Buffer.from(carrier.value, 'utf8');
    if (carrier.encoding !== 'utf8' || !equal(payloadReference(b, ref.mediaType), ref)) throw new StoreError('staging_mismatch');
    const prior = this.staged(operation).find(x => equal(x.ref, ref));
    if (prior && !prior.original.equals(b)) throw new StoreError('staging_conflict');
    const dk = dataKey(ref), reference = canonicalBytes(ref);
    this.#write('staging', [key, dk, reference, b, checksum(key, dk, reference, b)]);
  }
  staged(operation) { return this.#read('staged', [operationKeyText(operation)]).map(checkedStaged); }
  clearStaging(operation) { this.#write('clearStaging', [operationKeyText(operation)]); }
}
