// Pure reducer and inert observation checks. Effects below are proposals; no
// transaction, durable fence, authentication or real commit is performed here.
import { parseValidated, checkRecord, checkRequest, checkQuery, canonicalBytes, equal,
  freeze, known, absent, recordReference, requestDigest, fail } from './core.mjs';
import { checkDescriptor, validateDescriptor, checkAuthority, authorize,
  checkExpression, compileReturn, controlReference, validateToolResult } from './binding.mjs';

const json = JSON.stringify;
const CLOSURES = ['expired', 'revoked', 'withdrawn', 'superseded', 'cancel-requested'];
function checkState(v, c, p) {
  c.object(v, ['schema', 'descriptor', 'clockHighWater', 'intent', 'request', 'closure', 'fence', 'uncertain', 'receipt']);
  if (v.schema !== 'aap.sdk.mcp-reservation-state.draft1') fail('schema');
  checkDescriptor(v.descriptor, c, [...p, 'descriptor']); c.time(v.clockHighWater);
  if (v.clockHighWater < v.descriptor.issuedAt) fail('state_time');
  c.fact(v.intent, [...p, 'intent'], (x, q) => c.data(x, q)); c.fact(v.request, [...p, 'request'], (x, q) => checkRequest(x, c, q));
  if (!['known', 'not-recorded'].includes(v.intent.state) || !['known', 'not-recorded'].includes(v.request.state)
    || (v.intent.state === 'known') !== (v.request.state === 'known')) fail('state_pin');
  c.fact(v.closure, [...p, 'closure'], x => c.one(x, CLOSURES));
  if (!['known', 'not-recorded'].includes(v.closure.state)) fail('state_closure');
  c.one(v.fence, ['none', 'required', 'observed']); c.bool(v.uncertain);
  c.fact(v.receipt, [...p, 'receipt'], (x, q) => { checkRecord(x, c, q); if (x.type !== 'receipt') fail('ref_type'); });
  if (!['known', 'not-recorded'].includes(v.receipt.state)) fail('state_receipt');
  if (v.request.state === 'known') checkRequestBinding(v.descriptor, v.request.value);
  if (v.receipt.state === 'known') {
    checkReceiptBinding(v, v.receipt.value);
    if (v.uncertain || (v.receipt.value.body.outcome !== 'committed' && v.fence !== 'observed')) fail('state_terminal');
  }
}
export const validateReservationState = input => parseValidated(input, checkState);
const setEqual = (a, b) => a.length === b.length && a.every(x => b.some(y => equal(x, y)));
function checkRequestBinding(d, r) {
  const operation = { binding: r.binding, caller: r.caller, scope: r.scope, epoch: r.operation.epoch, id: r.operation.id, action: r.action };
  if (!equal(operation, d.operation) || r.validUntil !== d.validUntil || !equal(r.basis, known([d.context]))
    || !setEqual(r.grants, d.captureGrants) || r.records.length !== (d.revisionOf ? 2 : 1)) fail('request_binding');
  const [act, relation] = r.records;
  if (act.type !== 'act' || !equal(act.identity, d.actIdentity) || act.issuer !== d.receiver
    || !equal(act.body.contributor, d.contributor) || !equal(act.body.mapping, d.mapping)
    || !equal(act.body.transmitter, known(d.transmitter)) || !equal(act.body.basis, known([d.context]))
    || act.provenance.mode !== 'capability-return' || !equal(act.provenance.source, known(d.transmitter))) fail('capture_binding');
  if (!act.issuedAt || act.issuedAt < d.issuedAt || act.issuedAt >= d.validUntil || act.provenance.observedAt !== act.issuedAt
    || !equal(act.provenance.material, [d.context, d.manifest, ...d.sourceGrants]) || act.provenance.coverage.length
    || !equal(act.provenance.gaps, ['model-origin-unverified', 'complete-context-unverified', 'operator-controlled'])
    || Object.hasOwn(act.provenance, 'eventAt') || r.extensions || r.requires
    || r.records.some(x => x.extensions || x.requires)) fail('capture_binding');
  const expression = act.body.expression;
  if (expression.state !== 'known' || !['material', 'refusal'].includes(expression.value.form)) fail('capture_binding');
  const expectedMaterials = expression.value.form === 'material' ? expression.value.items
    : Object.hasOwn(expression.value, 'statement') ? [expression.value.statement] : [];
  if (expectedMaterials.length > 1 || !setEqual(expectedMaterials, r.materials)) fail('capture_materials');
  if (relation && (relation.type !== 'relation' || relation.issuer !== d.receiver || !equal(relation.identity, d.relationIdentity)
    || !equal(relation.body.vocabulary, d.vocabulary)
    || !equal(relation.body.members, [{ role: 'revision', subject: recordReference(json(act)) }, { role: 'original', subject: d.revisionOf }])
    || !equal(relation.body.agreement, known([])) || relation.issuedAt !== act.issuedAt || !equal(relation.provenance, act.provenance))) fail('revision_binding');
}
function checkReceiptBinding(state, receipt) {
  const d = state.descriptor, b = receipt.body;
  if (!equal(b.operation, d.operation) || receipt.issuer !== d.receiver || !equal(b.retention.policy, d.retentionPolicy)
    || !equal(b.authority.policy, d.authorityPolicy) || b.retention.recoveryUntil !== d.recoveryUntil
    || receipt.issuedAt < d.issuedAt || receipt.issuedAt > d.recoveryUntil) fail('receipt_binding');
  if (state.request.state === 'known') {
    if (!equal(b.requestDigest, known(requestDigest(json(state.request.value))))) fail('receipt_digest');
  } else if (b.outcome !== 'cancelled' || b.requestDigest.state !== 'not-recorded') fail('receipt_without_request');
  if (b.outcome === 'committed') {
    if (!setEqual(b.recorded, state.request.value.records.map(r => recordReference(json(r))))
      || !setEqual(b.retained, state.request.value.materials) || !setEqual(b.authority.grants, d.captureGrants)
      || receipt.issuedAt >= d.validUntil || b.retention.recordsUntil !== d.recordsUntil
      || (b.retained.length && b.retention.dataUntil !== d.dataUntil)) fail('receipt_batch');
  } else if (b.outcome === 'rejected' && !setEqual(b.authority.grants, d.finalizationGrants)) fail('finalization_authority');
}

export function createReservationState(input) {
  const descriptor = validateDescriptor(input);
  return validateReservationState(json({ schema: 'aap.sdk.mcp-reservation-state.draft1', descriptor,
    clockHighWater: descriptor.issuedAt, intent: absent(), request: absent(), closure: absent(),
    fence: 'none', uncertain: false, receipt: absent() }));
}

function checkEvent(e, c, p) {
  c.one(e?.type, ['pin', 'close', 'observe-terminal']);
  const required = e.type === 'pin' ? ['type', 'at', 'expression', 'authority'] : e.type === 'close'
    ? ['type', 'at', 'reason', 'knownUncommitted', 'fenceObserved']
    : ['type', 'at', 'receipt', 'nonCommitObserved', 'fenceObserved'];
  c.object(e, required, e.type === 'observe-terminal' ? ['query'] : []); c.time(e.at);
  if (e.type === 'pin') { checkExpression(e.expression, c, [...p, 'expression']); checkAuthority(e.authority, c, [...p, 'authority']); }
  if (e.type === 'close') { c.one(e.reason, CLOSURES); c.bool(e.knownUncommitted); c.bool(e.fenceObserved); }
  if (e.type === 'observe-terminal') {
    checkRecord(e.receipt, c, [...p, 'receipt']); if (e.receipt.type !== 'receipt') fail('ref_type');
    c.bool(e.nonCommitObserved); c.bool(e.fenceObserved); if (Object.hasOwn(e, 'query')) checkQuery(e.query, c, [...p, 'query']);
  }
}
export function reduceReservation(stateInput, eventInput) {
  const before = validateReservationState(stateInput), e = parseValidated(eventInput, checkEvent);
  if (e.at < before.clockHighWater) fail('clock_rollback');
  const state = JSON.parse(json(before)); state.clockHighWater = e.at;
  const finish = (decision, effects = []) => freeze({ decision, state: validateReservationState(json(state)), effects });
  if (e.type === 'observe-terminal') {
    checkReceiptBinding(state, e.receipt);
    if (e.receipt.issuedAt > e.at) fail('future_receipt');
    if (state.receipt.state === 'known') {
      if (!equal(state.receipt.value, e.receipt)) fail('terminal_conflict'); return finish('terminal-recovered');
    }
    if (e.receipt.body.outcome !== 'committed') {
      if (!e.nonCommitObserved || !e.fenceObserved) fail('fence_unobserved');
      if (e.receipt.body.outcome === 'cancelled') {
        if (!e.query || e.query.action !== 'cancel' || !equal(e.query.target, state.descriptor.operation)
          || e.query.caller !== e.receipt.body.authority.principal || !setEqual(e.query.grants, e.receipt.body.authority.grants)
          || e.receipt.issuedAt > e.query.validUntil) fail('cancelling_principal');
      }
      state.fence = 'observed';
    }
    state.receipt = known(e.receipt); state.uncertain = false; return finish('terminal-observed');
  }
  if (state.receipt.state === 'known') return finish('terminal-recovered');
  if (e.type === 'close') {
    if (e.reason === 'expired' && e.at < state.descriptor.validUntil) fail('expiry_observation');
    state.closure = known(e.reason); state.fence = e.fenceObserved ? 'observed' : 'required';
    state.uncertain = state.request.state === 'known' && !e.knownUncommitted;
    return finish(state.uncertain ? 'resolve-before-finalization' : 'closed',
      [state.request.state === 'known' ? 'resolve-or-finalize-existing-key' : 'fence-unbound-key']);
  }
  if (e.authority.at !== e.at) fail('observation_time');
  const auth = authorize(json(state.descriptor), json(e.authority), 'return.submit');
  const capture = authorize(json(state.descriptor), json(e.authority), 'capture.record');
  if (!auth.allowed || !capture.allowed) return finish('denied');
  if (state.closure.state === 'known' || state.uncertain) return finish('write-closed');
  const compiled = compileReturn(json(state.descriptor), json(e.expression), e.at);
  if (state.intent.state === 'known') return finish(equal(state.intent.value, compiled.intent) ? 'pin-recovered' : 'intent-conflict');
  state.intent = known(compiled.intent); state.request = known(compiled.request);
  return finish('pinned', ['persist-exact-pin-before-effects', 'record-at-authoritative-owner']);
}

export function projectReturn(stateInput, input) {
  const state = validateReservationState(stateInput);
  const q = parseValidated(input, (v, c, p) => {
    c.object(v, ['authority', 'availability', 'returnHandle']); checkAuthority(v.authority, c, ['authority']);
    c.one(v.availability, ['available', 'unavailable', 'unknown']); c.name(v.returnHandle);
  });
  const decision = authorize(json(state.descriptor), json(q.authority), 'outcome.read');
  const wrap = value => validateToolResult('return_status', json(value));
  if (!decision.allowed) return wrap({ schema: 'aap.sdk.mcp-result.draft1', processing: 'denied', reason: known(decision.reason), value: null });
  const at = q.authority.at; if (at < state.clockHighWater) fail('clock_rollback');
  const available = q.availability === 'available';
  const terminal = available && state.receipt.state === 'known';
  const statusState = terminal ? 'terminal' : !available ? q.availability : state.uncertain ? 'unknown'
    : state.request.state === 'known' ? 'pending' : 'not-seen';
  const noReceipt = absent(['unknown', 'unavailable'].includes(statusState) ? statusState : 'not-recorded');
  const status = { schema: 'aap.status.draft1', operation: state.descriptor.operation, issuer: state.descriptor.receiver,
    observedAt: at, state: statusState,
    receipt: terminal ? known(recordReference(json(state.receipt.value))) : noReceipt, reason: absent() };
  return wrap({ schema: 'aap.sdk.mcp-result.draft1', processing: 'completed', reason: absent(), value: {
    reservation: controlReference(state.descriptor), returnHandle: q.returnHandle,
    slot: terminal ? 'terminal' : !available || state.uncertain ? 'unknown' : state.closure.state === 'known' ? 'closed'
      : state.request.state === 'known' ? 'bound' : 'reserved', status, receipt: terminal ? state.receipt : noReceipt } });
}

export function planCancellation(descriptorInput, authorityInput) {
  const d = validateDescriptor(descriptorInput);
  const a = parseValidated(authorityInput, checkAuthority);
  const permission = authorize(descriptorInput, authorityInput, 'return.cancel');
  if (!permission.allowed) return freeze({ decision: 'denied', query: null });
  const deadline = [d.recoveryUntil, a.auth.notAfter, ...a.grants.filter(g => permission.grants.some(r => equal(r, recordReference(json(g.record)))))
    .map(g => g.record.body.notAfter)].sort()[0];
  if (deadline <= a.at) return freeze({ decision: 'denied', query: null });
  const query = { schema: 'aap.query.draft1', action: 'cancel', caller: d.transmitter,
    target: d.operation, grants: permission.grants, validUntil: deadline };
  return freeze({ decision: 'resolve-and-fence', query }); // No fence is asserted here.
}
export function replacementAllowed(input) {
  const v = validateReservationState(input);
  return v.receipt.state === 'known' && v.receipt.value.body.outcome !== 'committed' && v.fence === 'observed' && !v.uncertain;
}
