// Raw method seam only. No initialize/session negotiation, server/connection,
// transport, listener, provider or client. A later supported MCP transport must
// preserve raw request bytes before object parsing and supply a trusted resolver.
import { parseTree, findNodeAtLocation } from 'jsonc-parser';
import { parseValidated, octets, canonicalBytes, equal, known, fail } from '../src/core.mjs';
import { validateToolArguments, validateToolResult, checkResultBudget } from '../src/binding.mjs';
import { TOOL_CATALOG, ADAPTER_INFO } from './catalog.mjs';
export { TOOL_CATALOG, ADAPTER_INFO } from './catalog.mjs';
const j = JSON.stringify;
const failed = (processing, reason) => ({ schema: 'aap.sdk.mcp-result.draft1', processing, reason: known(reason), value: null });
const rpcError = (id, code, message) => j({ jsonrpc: '2.0', id, error: { code, message } });
const codeOf = error => { try { const v = Object.getOwnPropertyDescriptor(error, 'code')?.value; return typeof v === 'string' ? v : ''; } catch { return ''; } };
const denied = new Set(['principal_denied', 'principal_changed', 'work_not_enrolled', 'wrong_principal', 'return_not_found', 'inspection_denied', 'resume_denied', 'preparation_denied', 'cancel_denied', 'denied']);
const conflict = new Set(['reservation_mismatch', 'intent_conflict', 'intent-conflict', 'preparation_conflict', 'context_changed', 'revision_target', 'inspection_cursor', 'resume_cursor']);
const unsupported = new Set(['unsupported_work', 'revision_unsupported', 'unsupported_mapping']);
const uncertain = new Set(['commit_outcome_unknown', 'rollback_state_unknown', 'store_unavailable']);
function failure(error, tool) {
  const code = codeOf(error);
  if (denied.has(code) || /^denied_(?:authentication|grant|consent|context|work_scope|write_closed|recovery_closed|reservation_time|unsupported_mapping)$/.test(code)) return failed('denied', 'access-denied');
  if (conflict.has(code)) return failed('invalid', 'request-conflict');
  if (unsupported.has(code)) return failed('unsupported', 'unsupported-profile');
  if (uncertain.has(code)) return failed('unknown', 'outcome-unresolved');
  if (['return_capacity', 'inspection_capacity'].includes(code)) return failed('unavailable', 'capacity');
  // Never assert noncommit from a technical failure, or echo native messages,
  // unknown code strings, paths, credentials or driver diagnostics.
  return failed(['prepare_return', 'submit_expression', 'cancel_return', 'return_status'].includes(tool) ? 'unknown' : 'unavailable', 'operation-unavailable');
}
export function frameMcpResult(id, result) {
  const text = j({ jsonrpc: '2.0', id, result }); checkResultBudget(text); return text;
}
function toolFrame(id, tool, value) {
  const checked = validateToolResult(tool, j(value));
  const text = checked.processing === 'completed' ? `${tool}: completed. Recording, app treatment and rendering are separate claims.`
    : `${tool}: ${checked.processing}; ${checked.reason.value}. No new artistic refusal or noncommit is inferred.`;
  if (Buffer.byteLength(text) > ADAPTER_INFO.maxSummaryBytes) fail('summary_budget');
  return frameMcpResult(id, { content: [{ type: 'text', text }], structuredContent: checked, isError: checked.processing !== 'completed' });
}
function rawRequest(input) {
  const bytes = octets(input, ADAPTER_INFO.maxRequestBytes), text = new TextDecoder('utf-8', { fatal: true, ignoreBOM: true }).decode(bytes);
  const request = parseValidated(bytes, (v, c) => {
    c.object(v, ['jsonrpc', 'id', 'method'], ['params']); if (v.jsonrpc !== '2.0') fail('rpc_request');
    if (typeof v.id === 'string') c.text(v.id, 128); else c.uint(v.id, ['id']);
    c.text(v.method, 128);
  });
  return { request, text };
}
export function createParticipationAdapter({ resolver, works }) {
  if (!resolver || typeof resolver.check !== 'function' || typeof resolver.resolve !== 'function' || !Array.isArray(works)
    || !works.length || works.length > 32) fail('adapter_configuration');
  const routes = new Map(), identities = new Set();
  for (const route of works) {
    const value = parseValidated(j({ work: route.work, identity: route.identity }), (v, c) => {
      c.object(v, ['work', 'identity']); c.name(v.work); c.object(v.identity, ['work', 'binding', 'owner', 'receiver']);
      c.ref(v.identity.work, ['identity', 'work'], 'work'); c.ref(v.identity.binding, ['identity', 'binding'], 'binding');
      c.identifier(v.identity.owner); c.identifier(v.identity.receiver);
    });
    const identityKey = canonicalBytes(value.identity.work).toString();
    if (typeof route.getOwner !== 'function' || routes.has(value.work) || identities.has(identityKey)) fail('adapter_configuration');
    routes.set(value.work, { identity: value.identity, getOwner: route.getOwner }); identities.add(identityKey);
  }
  return Object.freeze({ info: ADAPTER_INFO, dispatch(input, trustedContext) {
    // Check the out-of-band handle first. No token/principal/caller is read from
    // tool args, MCP IDs, _meta, display names or a client's claimed verified flag.
    try { if (resolver.check(trustedContext) !== true) fail('principal_denied'); }
    catch { return rpcError(null, -32001, 'Authentication required.'); }
    let request, text;
    try { ({ request, text } = rawRequest(input)); }
    catch (error) { return rpcError(null, codeOf(error) === 'json' ? -32700 : -32600, 'Invalid request.'); }
    const { id, method } = request;
    if (!ADAPTER_INFO.methods.includes(method)) return rpcError(id, -32601, 'Method not supported.');
    const params = request.params ?? {};
    try {
      parseValidated(j(params), (v, c) => {
        c.object(v, method === 'tools/call' ? ['name', 'arguments'] : [], ['_meta']);
        if (Object.hasOwn(v, '_meta') && (!v._meta || typeof v._meta !== 'object' || Array.isArray(v._meta))) fail('rpc_params');
        if (method === 'tools/call') { c.name(v.name); if (!v.arguments || typeof v.arguments !== 'object' || Array.isArray(v.arguments)) fail('rpc_params'); }
      });
    } catch { return rpcError(id, -32602, 'Invalid parameters.'); }
    if (method === 'tools/list') return frameMcpResult(id, { tools: TOOL_CATALOG });
    const tool = params.name; if (!TOOL_CATALOG.some(t => t.name === tool)) return rpcError(id, -32602, 'Tool not supported.');
    let args;
    try {
      // Slice the original JSON, preserving integer tokens and duplicate-key
      // rejection instead of roundtripping vendor-decoded argument objects.
      const node = findNodeAtLocation(parseTree(text), ['params', 'arguments']);
      if (!node) fail('rpc_params'); args = validateToolArguments(tool, text.slice(node.offset, node.offset + node.length));
    } catch { return toolFrame(id, tool, failed('invalid', 'invalid-arguments')); }
    let value;
    try {
      const route = routes.get(args.work); if (!route) fail('principal_denied');
      const auth = () => resolver.resolve(trustedContext, args.work); auth();
      const owner = route.getOwner(); if (!owner || !equal(owner.describe().identity, route.identity)) fail('owner_route_unavailable');
      const session = owner.bind(auth);
      if (tool === 'resume_work') value = session.resume(j(Object.hasOwn(args, 'cursor') ? { cursor: args.cursor } : {}));
      if (tool === 'read_context') value = session.readContext();
      if (tool === 'prepare_return') value = session.prepare(j({ context: args.context, prepareId: args.prepareId, ...(args.revisionOf ? { revisionOf: args.revisionOf } : {}) }));
      if (tool === 'submit_expression') value = session.submit(args.returnHandle, j(args.expression), j(args.reservation));
      if (tool === 'return_status') value = session.status(args.returnHandle);
      if (tool === 'cancel_return') value = session.cancel(args.returnHandle);
      if (tool === 'inspect_process') value = session.inspect(j({ selection: args.selection, ...(args.cursor ? { cursor: args.cursor } : {}), ...(args.data ? { data: args.data } : {}) }));
      resolver.resolve(trustedContext, args.work); // final delivery check; no result cache
    } catch (error) { value = failure(error, tool); }
    try { return toolFrame(id, tool, value); }
    catch { // Framing failure is not a failed artistic operation. Never truncate.
      return toolFrame(id, tool, failed(['prepare_return', 'submit_expression', 'cancel_return', 'return_status'].includes(tool) ? 'unknown' : 'unavailable', 'result-unavailable'));
    }
  } });
}
