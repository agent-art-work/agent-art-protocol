// Test identity authority only. Opaque process-local handles are not OAuth
// tokens, persistent sessions, Work consent or evidence of Agent execution.
import { parseValidated, freeze, fail } from '../src/core.mjs';
const j = JSON.stringify;
export class InertPrincipalResolver {
  #members; #sessions = new WeakMap(); #clock; #highWater = 0;
  constructor({ membersJson, clock }) {
    this.#members = parseValidated(membersJson, (v, c) => {
      c.list(v, [], (x, p) => { c.object(x, ['subject', 'work', 'principal']); c.identifier(x.subject); c.name(x.work); c.identifier(x.principal); });
      const pairs = v.map(x => j([x.subject, x.work])); if (new Set(pairs).size !== pairs.length) fail('resolver_binding_conflict');
      const aliases = v.map(x => j([x.work, x.principal])); if (new Set(aliases).size !== aliases.length) fail('resolver_alias_conflict');
    });
    if (typeof clock !== 'function') fail('resolver_clock'); this.#clock = clock;
  }
  #now() {
    const time = parseValidated(j(this.#clock()), (v, c) => c.time(v)), n = Date.parse(time);
    if (n < this.#highWater) fail('resolver_clock_rollback'); this.#highWater = n; return time;
  }
  issue(input) {
    const v = parseValidated(input, (x, c) => { c.object(x, ['subject', 'notAfter']); c.identifier(x.subject); c.time(x.notAfter); });
    const at = this.#now();
    if (!this.#members.some(x => x.subject === v.subject) || at >= v.notAfter || Date.parse(v.notAfter) - Date.parse(at) > 3600000) fail('principal_denied');
    const context = Object.freeze(Object.create(null)); this.#sessions.set(context, v); return context;
  }
  revoke(context) { this.#sessions.delete(context); }
  check(context) {
    const v = this.#sessions.get(context); if (!v || this.#now() >= v.notAfter) fail('principal_denied');
    return true;
  }
  resolve(context, work) {
    this.check(context); const v = this.#sessions.get(context), member = this.#members.find(x => x.subject === v.subject && x.work === work);
    if (!member) fail('principal_denied');
    return j(freeze({ verified: true, principal: member.principal, notAfter: v.notAfter }));
  }
}
