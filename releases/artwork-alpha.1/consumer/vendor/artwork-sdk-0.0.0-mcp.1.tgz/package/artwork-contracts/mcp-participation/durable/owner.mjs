// Trusted, source-only owner. Its bound facade is not an authentication server.
// One versioned SQLite owner per Work; no listener, client or rendering adapter.
import { randomUUID, createHash } from 'node:crypto';
import { ParticipationStore, validateIdentity, preparationKey } from './store.mjs';
import { parseValidated, validateRecord, checkRecord, checkOperation, canonicalBytes, recordReference,
  requestDigest, equal, freeze, known, absent, fail } from '../src/core.mjs';
import { validateProfile, validateAuthority, authorize, authorizeWork, validateExpression,
  decidePreparation, compileReturn, expressionFingerprint, controlReference, descriptorPreparation,
  validateToolResult, checkResultBudget } from '../src/binding.mjs';
import { createReservationState, reduceReservation, projectReturn, planCancellation } from '../src/reservation.mjs';
import { projectInspection } from '../src/inspection.mjs';

const j = JSON.stringify, copy = structuredClone, stamp = n => new Date(n).toISOString();
const key = value => createHash('sha256').update(canonicalBytes(value)).digest('hex');
const ref = record => recordReference(j(record));
const minimum = (...times) => times.sort()[0];
const requireAllowed = decision => { if (!decision.allowed) fail('denied_' + decision.reason); return decision; };
const wrap = (tool, value) => validateToolResult(tool, j({ schema: 'aap.sdk.mcp-result.draft1', processing: 'completed', reason: absent(), value }));
const checkTime = input => parseValidated(j(input), (v, c) => c.time(v));

function checkPolicy(v, c, p) {
  c.object(v, ['writeMs', 'recordsMs', 'dataMs', 'recoveryMs', 'maxActive', 'maxEntries']);
  for (const name of Object.keys(v)) c.uint(v[name], [...p, name]);
  if (!v.writeMs || v.writeMs > 600000 || v.recordsMs < v.writeMs || v.dataMs < v.writeMs
    || v.recordsMs > 604800000 || v.dataMs > 604800000 || !v.recoveryMs || v.recoveryMs > 604800000
    || !v.maxActive || v.maxActive > 4 || v.maxEntries < v.maxActive || v.maxEntries > 1000) fail('owner_policy');
}
export function validateSetup(input) {
  const v = parseValidated(input, (x, c) => {
    c.object(x, ['work', 'binding', 'owner', 'receiver', 'mappingRules', 'relationRules', 'policy', 'bootstrapUntil']);
    checkRecord(x.work, c, ['work']); checkRecord(x.binding, c, ['binding']);
    if (x.work.type !== 'work' || x.binding.type !== 'binding') fail('setup_type');
    c.identifier(x.owner); c.identifier(x.receiver); c.rules(x.mappingRules, ['mappingRules']); c.rules(x.relationRules, ['relationRules']);
    checkPolicy(x.policy, c, ['policy']); c.time(x.bootstrapUntil);
    if (x.work.issuer !== x.owner || x.binding.issuer !== x.owner || !x.mappingRules.length
      || x.mappingRules.some(r => !x.work.body.actMappings.some(m => equal(r, m)))
      || !equal(x.binding.body.authorization, x.work.body.policies.authority)
      || !equal(x.binding.body.retention, x.work.body.policies.retention)) fail('setup_authority');
  });
  validateProfile(j(v.binding)); return v;
}
function checkRoot(input, identity) {
  return parseValidated(j(input), (v, c) => {
    c.object(v, ['schema', 'identity', 'namespace', 'epoch', 'mappingRules', 'relationRules', 'policy', 'authorityPolicy', 'retentionPolicy']);
    if (v.schema !== 'aap.sdk.mcp-owner.draft1' || !equal(v.identity, identity)) fail('owner_identity');
    validateIdentity(j(v.identity)); c.identifier(v.namespace); c.name(v.epoch);
    c.rules(v.mappingRules, ['mappingRules']); c.rules(v.relationRules, ['relationRules']); checkPolicy(v.policy, c, ['policy']);
    c.rule(v.authorityPolicy, ['authorityPolicy']); c.rule(v.retentionPolicy, ['retentionPolicy']);
  });
}
function checkEnrollment(input, root) {
  return parseValidated(j(input), (v, c) => {
    c.object(v, ['principal', 'participant', 'active', 'policy', 'sourceGrant', 'consent']);
    c.identifier(v.principal); c.ref(v.participant, ['participant'], 'participant'); c.bool(v.active);
    c.rule(v.policy, ['policy']); c.ref(v.sourceGrant, ['sourceGrant'], 'grant');
    c.object(v.consent, ['at', 'notAfter', 'terms', 'source']); c.time(v.consent.at); c.time(v.consent.notAfter);
    c.rule(v.consent.terms, ['consent', 'terms']);
    if (v.consent.source !== 'operator-declared' || !equal(v.policy, root.authorityPolicy)) fail('enrollment');
  });
}
function checkPublication(input, work) {
  return parseValidated(j(input), (v, c) => {
    c.object(v, ['work', 'context', 'manifest', 'readers', 'until', 'available']);
    c.ref(v.work, ['work'], 'work'); c.ref(v.context, ['context'], 'context'); c.ref(v.manifest, ['manifest'], 'manifest');
    c.list(v.readers, ['readers'], x => c.identifier(x), { set: true, min: 1 }); c.time(v.until); c.bool(v.available);
    if (!equal(v.work, work)) fail('work_scope');
  });
}
function checkSelection(input, work) {
  return parseValidated(j(input), (v, c) => {
    c.object(v, ['schema', 'selection', 'work', 'manifest', 'readers', 'until', 'available']);
    if (v.schema !== 'aap.sdk.mcp-selection.draft1') fail('schema');
    c.name(v.selection); c.ref(v.work, ['work'], 'work'); c.ref(v.manifest, ['manifest'], 'manifest');
    c.list(v.readers, ['readers'], x => c.identifier(x), { set: true, min: 1 }); c.time(v.until); c.bool(v.available);
    if (!equal(v.work, work)) fail('work_scope');
  });
}

export class ParticipationOwner {
  #store; #root; #clock; #identity;
  constructor(store, identity, clock) {
    this.#store = store; this.#identity = validateIdentity(j(identity)); this.#clock = clock ?? (() => new Date().toISOString());
    try { if (typeof this.#clock !== 'function') fail('clock'); this.#root = checkRoot(store.control('root'), identity); this.#validateControls(); }
    catch (error) { store.close(); throw error; }
  }
  static initialize({ directory, setupJson, clock, ...testing }) {
    const setup = validateSetup(setupJson), now = checkTime((clock ?? (() => new Date().toISOString()))());
    if (now >= setup.bootstrapUntil) fail('bootstrap_expired');
    const identity = { work: ref(setup.work), binding: ref(setup.binding), owner: setup.owner, receiver: setup.receiver };
    const root = { schema: 'aap.sdk.mcp-owner.draft1', identity, namespace: setup.work.identity.namespace,
      epoch: 'epoch-' + randomUUID(), mappingRules: setup.mappingRules, relationRules: setup.relationRules, policy: setup.policy,
      authorityPolicy: setup.work.body.policies.authority, retentionPolicy: setup.work.body.policies.retention };
    const store = ParticipationStore.initialize({ directory, identity, ...testing });
    try {
      store.transaction(() => {
        store.putControl('root', root); store.setHighWater(Date.parse(now));
        store.putRecord(j(setup.work), setup.bootstrapUntil); store.putRecord(j(setup.binding), setup.bootstrapUntil);
      });
      return new ParticipationOwner(store, identity, clock);
    } catch (error) { store.close(); throw error; }
  }
  static open({ directory, identityJson, clock, ...testing }) {
    const identity = validateIdentity(identityJson);
    return new ParticipationOwner(ParticipationStore.open({ directory, identity, ...testing }), identity, clock);
  }
  close() { this.#store.close(); }
  describe() { return freeze(copy({ identity: this.#identity, policy: this.#root.policy, format: 'aap.mcp-participation.store.v2', settings: this.#store.settings() })); }
  #now() {
    const now = checkTime(this.#clock()); if (Date.parse(now) < this.#store.highWater()) fail('clock_rollback'); return now;
  }
  #run(action, guard = () => {}) {
    let at;
    return this.#store.transaction(() => { at = this.#now(); this.#store.setHighWater(Date.parse(at)); return action(at); }, () => {
      const now = this.#now(); if (now < at) fail('clock_rollback'); guard(now); this.#store.setHighWater(Date.parse(now));
    });
  }
  #record(type, body, issuer, at, id = type + '-' + randomUUID()) {
    return validateRecord(j({ schema: 'aap.record.draft1', type, identity: { namespace: this.#root.namespace, id, revision: 'v1' },
      scope: { work: this.#identity.work }, issuer, issuedAt: at, provenance: { mode: 'observation', source: known(issuer),
        observedAt: at, material: [], coverage: [], gaps: ['operator-controlled', 'independent-origin-unverified'] }, body }));
  }
  #enrollment(principal) {
    const e = this.#store.control('enrollment:' + key(principal)); return e && checkEnrollment(e, this.#root);
  }
  #grant(reference) {
    const v = this.#store.control('grant:' + key(reference));
    if (!v) fail('grant_missing');
    return parseValidated(j(v), (x, c) => {
      c.object(x, ['record', 'target', 'revoked']); checkRecord(x.record, c, ['record']); c.bool(x.revoked);
      if (x.target !== null) checkOperation(x.target, c, ['target']);
      if (x.record.type !== 'grant' || x.record.issuer !== this.#identity.owner || !equal(ref(x.record), reference)
        || !equal(x.record.scope, { work: this.#identity.work }) || !equal(x.record.body.policy, this.#root.authorityPolicy)
        || (x.target && (!equal(x.target.scope, { work: this.#identity.work }) || !equal(x.target.binding, this.#identity.binding)
          || x.target.caller !== this.#identity.receiver))) fail('grant_binding');
    });
  }
  #saveGrant(principal, rights, participant, target, at, until) {
    const record = this.#record('grant', { principal, rights, attributions: [participant], policy: this.#root.authorityPolicy,
      notBefore: at, notAfter: until, delegation: absent() }, this.#identity.owner, at);
    const reference = this.#store.putRecord(j(record), until);
    this.#store.putControl('grant:' + key(reference), { record, target, revoked: false }); return reference;
  }
  #publication(context) {
    const p = this.#store.control('publication:' + key(context)); return p && checkPublication(p, this.#identity.work);
  }
  #auth(reader) {
    return parseValidated(typeof reader === 'function' ? reader() : reader, (v, c) => {
      c.object(v, ['verified', 'principal', 'notAfter']); c.bool(v.verified); c.identifier(v.principal); c.time(v.notAfter);
    });
  }
  #authority(reader, at, descriptor = null) {
    const auth = this.#auth(reader), e = this.#enrollment(auth.principal); if (!e) fail('work_not_enrolled');
    if (descriptor && descriptor.transmitter !== auth.principal) fail('wrong_principal');
    const current = descriptor?.context ?? this.#store.control('current:' + key(auth.principal));
    const p = current && this.#publication(current);
    const refs = descriptor ? [...descriptor.sourceGrants, ...descriptor.captureGrants, ...descriptor.recoveryGrants, ...descriptor.finalizationGrants] : [e.sourceGrant];
    const grants = [...new Map(refs.map(r => [key(r), r])).values()].map(r => this.#grant(r));
    return validateAuthority(j({ at, auth, enrollment: { scope: { work: this.#identity.work }, principal: e.principal,
      participant: e.participant, receiver: this.#identity.receiver, active: e.active, policy: e.policy }, trustedIssuers: [this.#identity.owner],
      grants, contextAvailable: !!p?.available && p.readers.includes(auth.principal), contextUntil: p?.until ?? at,
      mappingRules: this.#root.mappingRules, relationRules: this.#root.relationRules }));
  }
  #validateControls() {
    for (const { key: name, value } of this.#store.controls()) {
      if (name === 'root') continue;
      if (name.startsWith('enrollment:')) {
        const e = checkEnrollment(value, this.#root); if (name !== 'enrollment:' + key(e.principal)) fail('owner_control'); this.#grant(e.sourceGrant);
      } else if (name.startsWith('grant:')) this.#grant(ref(value.record));
      else if (name.startsWith('publication:')) {
        const p = checkPublication(value, this.#identity.work); if (name !== 'publication:' + key(p.context)) fail('owner_control');
      } else if (name.startsWith('current:')) {
        parseValidated(j(value), (v, c, p) => c.ref(v, p, 'context')); if (!this.#publication(value)) fail('owner_control');
      } else if (name.startsWith('selection:')) {
        const s = checkSelection(value, this.#identity.work); if (name !== 'selection:' + key(s.selection)) fail('owner_control');
      } else fail('owner_control');
    }
    for (const entry of this.#store.operations()) {
      const d = entry.state.descriptor, e = this.#enrollment(d.transmitter);
      if (!e || !equal(e.participant, d.contributor) || entry.sequence > 9007199254740991) fail('owner_control');
      for (const r of [...d.sourceGrants, ...d.captureGrants, ...d.recoveryGrants, ...d.finalizationGrants]) this.#grant(r);
    }
  }
  enroll(input) {
    const v = parseValidated(input, (x, c) => {
      c.object(x, ['principal', 'participant', 'terms', 'notAfter']); c.identifier(x.principal); checkRecord(x.participant, c, ['participant']);
      c.rule(x.terms, ['terms']); c.time(x.notAfter);
      if (x.participant.type !== 'participant' || x.participant.body.kind !== 'agent' || x.participant.issuer !== this.#identity.owner) fail('participant');
    });
    return this.#run(at => {
      if (at >= v.notAfter || this.#enrollment(v.principal)) fail('enrollment_conflict');
      if (this.#store.controls().filter(x => x.key.startsWith('enrollment:')).length >= 32) fail('enrollment_capacity');
      const participant = this.#store.putRecord(j(v.participant), v.notAfter);
      const sourceGrant = this.#saveGrant(v.principal, ['work.resume', 'context.read', 'return.prepare', 'return.submit', 'inspection.read', 'data.read'], participant, null, at, v.notAfter);
      const enrollment = { principal: v.principal, participant, active: true, policy: this.#root.authorityPolicy, sourceGrant,
        consent: { at, notAfter: v.notAfter, terms: v.terms, source: 'operator-declared' } };
      this.#store.putControl('enrollment:' + key(v.principal), enrollment); return freeze(enrollment);
    }, now => { if (now >= v.notAfter) fail('enrollment_expired'); });
  }
  setActive(principal, active) {
    parseValidated(j({ principal, active }), (v, c) => { c.identifier(v.principal); c.bool(v.active); });
    return this.#run(() => { const e = this.#enrollment(principal); if (!e) fail('work_not_enrolled');
      this.#store.putControl('enrollment:' + key(principal), { ...e, active }); });
  }
  revokeGrant(referenceJson) {
    const reference = parseValidated(referenceJson, (v, c, p) => c.ref(v, p, 'grant'));
    return this.#run(() => this.#store.putControl('grant:' + key(reference), { ...this.#grant(reference), revoked: true }));
  }
  publishContext(input) {
    const v = parseValidated(input, (x, c) => {
      c.object(x, ['package', 'readers', 'until']); c.list(x.readers, ['readers'], z => c.identifier(z), { min: 1, set: true }); c.time(x.until);
    });
    const packet = wrap('read_context', v.package).value; checkResultBudget(j(wrap('read_context', packet)));
    if (!equal(packet.work, this.#identity.work) || packet.manifest.issuer !== this.#identity.owner
      || packet.records.some(r => r.type === 'context' && r.issuer !== this.#identity.owner)) fail('context_owner');
    return this.#run(at => {
      if (at >= v.until) fail('context_expired');
      if (!this.#publication(packet.context) && this.#store.controls().filter(x => x.key.startsWith('publication:')).length >= 256) fail('context_capacity');
      for (const reader of v.readers) if (!this.#enrollment(reader)) fail('work_not_enrolled');
      const publication = { work: packet.work, context: packet.context, manifest: ref(packet.manifest), readers: v.readers, until: v.until, available: true };
      const old = this.#publication(packet.context);
      if (old && !equal(old, publication)) fail('context_conflict');
      this.#store.putRecord(j(packet.manifest), v.until);
      for (const r of packet.records) this.#store.putRecord(j(r), v.until);
      for (const c of packet.carriers) this.#store.putData(c.ref, Buffer.from(c.value, 'utf8'), v.until);
      this.#store.putControl('publication:' + key(packet.context), publication);
      for (const reader of v.readers) this.#store.putControl('current:' + key(reader), packet.context);
      return packet.context;
    }, now => { if (now >= v.until) fail('context_expired'); });
  }
  withdrawContext(contextJson) {
    const context = parseValidated(contextJson, (v, c, p) => c.ref(v, p, 'context'));
    return this.#run(() => { const p = this.#publication(context); if (!p) fail('context_missing');
      this.#store.putControl('publication:' + key(context), { ...p, available: false }); });
  }
  #packet(context, principal, at) {
    const p = this.#publication(context);
    if (!p?.available || !p.readers.includes(principal) || at >= p.until) fail('context_unavailable');
    const read = r => { const x = this.#store.record(r); if (!x?.record || at >= x.until) fail('context_unavailable'); return x.record; };
    const manifest = read(p.manifest);
    const packet = { work: p.work, context: p.context, manifest, records: manifest.body.records.map(read),
      carriers: manifest.body.data.map(reference => {
        const row = this.#store.data(reference); if (!row?.original || at >= row.until) fail('context_unavailable');
        const value = new TextDecoder('utf-8', { fatal: true, ignoreBOM: true }).decode(row.original);
        return { ref: reference, encoding: 'utf8', value };
      }) };
    return wrap('read_context', packet).value;
  }
  // This method accepts a trusted authenticated observation, not participant input.
  // A future transport must resolve the principal before binding this facade.
  bind(authReader) {
    const principal = this.#auth(authReader).principal;
    const reader = () => { const a = this.#auth(authReader); if (a.principal !== principal) fail('principal_changed'); return j(a); };
    return Object.freeze({ resume: (input = '{}') => this.#resume(reader, input), readContext: () => this.#readContext(reader),
      prepare: input => this.#prepare(reader, input), pin: (handle, input) => this.#pin(reader, handle, input),
      finish: handle => this.#finish(reader, handle), submit: (handle, input, reservationJson) => { this.#pin(reader, handle, input, reservationJson); return this.#finish(reader, handle); },
      status: handle => this.#status(reader, handle), cancel: handle => this.#cancel(reader, handle), inspect: input => this.#inspect(reader, input) });
  }
  #readContext(reader) {
    return this.#run(at => {
      const a = this.#authority(reader, at); requireAllowed(authorizeWork(j(this.#identity.work), j(a), 'context.read'));
      return wrap('read_context', this.#packet(this.#store.control('current:' + key(a.auth.principal)), a.auth.principal, at));
    }, now => requireAllowed(authorizeWork(j(this.#identity.work), j(this.#authority(reader, now)), 'context.read')));
  }
  #resume(reader, input) {
    const request = parseValidated(input, (v, c) => { c.object(v, [], ['cursor']); if (Object.hasOwn(v, 'cursor')) c.name(v.cursor); });
    return this.#run(at => {
      const a = this.#authority(reader, at), ordinary = authorizeWork(j(this.#identity.work), j(a), 'work.resume');
      const cursor = n => 'page-' + n + '-' + key({ work: this.#identity.work, binding: this.#identity.binding, principal: a.auth.principal, after: n });
      let after = 0;
      if (request.cursor) {
        const match = /^page-(0|[1-9][0-9]*)-[a-f0-9]{64}$/.exec(request.cursor); after = match ? Number(match[1]) : -1;
        if (!Number.isSafeInteger(after) || after < 0 || request.cursor !== cursor(after)) fail('resume_cursor');
      }
      const operations = this.#store.operations().filter(x => x.state.descriptor.transmitter === a.auth.principal
        && authorize(j(x.state.descriptor), j(this.#authority(reader, at, x.state.descriptor)), 'outcome.read').allowed);
      if (!ordinary.allowed && !operations.length) fail('resume_denied');
      const remaining = operations.filter(x => x.sequence > after), page = remaining.slice(0, 20);
      const context = ordinary.allowed && a.contextAvailable && at < a.contextUntil ? this.#store.control('current:' + key(a.auth.principal)) : null;
      const permissions = new Map();
      const summarize = (tool, decision, authority, ceiling) => {
        if (!decision.allowed) return;
        const ends = decision.grants.map(r => authority.grants.find(g => equal(ref(g.record), r)).record.body.notAfter).sort();
        const end = minimum(authority.auth.notAfter, ceiling, ends.at(-1));
        if (!permissions.has(tool) || permissions.get(tool) < end) permissions.set(tool, end);
      };
      for (const [tool, right] of [['resume_work', 'work.resume'], ['read_context', 'context.read'], ['prepare_return', 'return.prepare']])
        summarize(tool, authorizeWork(j(this.#identity.work), j(a), right), a,
          tool === 'resume_work' ? a.auth.notAfter : a.contextUntil);
      for (const x of operations) {
        const d = x.state.descriptor, current = this.#authority(reader, at, d);
        summarize('return_status', authorize(j(d), j(current), 'outcome.read'), current, d.recoveryUntil);
        summarize('cancel_return', authorize(j(d), j(current), 'return.cancel'), current, d.recoveryUntil);
        if (x.state.receipt.state !== 'known' && authorize(j(d), j(current), 'capture.record').allowed)
          summarize('submit_expression', authorize(j(d), j(current), 'return.submit'), current, d.validUntil);
      }
      for (const { key: name, value } of this.#store.controls()) if (name.startsWith('selection:')
        && value.available && at < value.until && value.readers.includes(a.auth.principal))
        summarize('inspect_process', authorizeWork(j(this.#identity.work), j(a), 'inspection.read'), a, value.until);
      return wrap('resume_work', { work: this.#identity.work, binding: this.#identity.binding, participant: known(a.enrollment.participant),
        context: context ? known(context) : absent('unavailable'), permissions: [...permissions].map(([operation, notAfter]) => ({ operation, notAfter })),
        operations: page.map(x => ({ returnHandle: x.handle,
          reservation: controlReference(x.state.descriptor), operation: x.state.descriptor.operation,
          validUntil: x.state.descriptor.validUntil, recoveryUntil: x.state.descriptor.recoveryUntil })),
        nextCursor: remaining.length > 20 ? known(cursor(page.at(-1).sequence)) : absent() });
    }, now => { const a = this.#authority(reader, now); if (!a.auth.verified || now >= a.auth.notAfter) fail('authentication_expired'); });
  }
  #entry(handle, reader, at, right) {
    parseValidated(j(handle), (v, c) => c.name(v)); const entry = this.#store.operation(handle); if (!entry) fail('return_not_found');
    const a = this.#authority(reader, at, entry.state.descriptor);
    if (right) requireAllowed(authorize(j(entry.state.descriptor), j(a), right)); return { entry, a };
  }
  #prepare(reader, input) {
    const v = parseValidated(input, (x, c) => {
      c.object(x, ['context', 'prepareId'], ['revisionOf']); c.ref(x.context, ['context'], 'context'); c.name(x.prepareId);
      if (Object.hasOwn(x, 'revisionOf')) c.ref(x.revisionOf, ['revisionOf'], 'act');
    });
    let selected, recovered = false;
    return this.#run(at => {
      const a = this.#authority(reader, at), id = this.#identity;
      const pk = preparationKey({ binding: id.binding, transmitter: a.auth.principal, scope: { work: id.work }, operation: { epoch: this.#root.epoch }, prepareId: v.prepareId });
      const prior = this.#store.prepared(pk);
      if (prior) {
        const d = prior.state.descriptor, candidate = { ...d, context: v.context };
        delete candidate.revisionOf; if (v.revisionOf) candidate.revisionOf = v.revisionOf;
        if (!equal(descriptorPreparation(candidate), descriptorPreparation(d))) fail('preparation_conflict');
        const current = this.#authority(reader, at, d);
        if (!authorize(j(d), j(current), 'return.prepare').allowed) requireAllowed(authorize(j(d), j(current), 'outcome.read'));
        selected = prior; recovered = true;
      } else {
        const permission = requireAllowed(authorizeWork(j(id.work), j(a), 'return.prepare'));
        if (!equal(v.context, this.#store.control('current:' + key(a.auth.principal)))) fail('context_changed');
        const mine = this.#store.operations().filter(x => x.state.descriptor.transmitter === a.auth.principal);
        if (mine.length >= this.#root.policy.maxEntries || mine.filter(x => x.state.receipt.state !== 'known'
          && x.state.closure.state !== 'known' && at < x.state.descriptor.validUntil).length >= this.#root.policy.maxActive) fail('return_capacity');
        const packet = this.#packet(v.context, a.auth.principal, at), policy = this.#root.policy;
        const validUntil = minimum(stamp(Date.parse(at) + policy.writeMs), a.contextUntil,
          ...permission.grants.map(r => this.#grant(r).record.body.notAfter));
        const recoveryUntil = stamp(Date.parse(validUntil) + policy.recoveryMs);
        const operation = { binding: id.binding, caller: id.receiver, scope: { work: id.work }, epoch: this.#root.epoch, id: 'return-' + randomUUID(), action: 'record' };
        const participant = a.enrollment.participant;
        const capture = this.#saveGrant(id.receiver, ['capture.record'], participant, operation, at, validUntil);
        const cancel = this.#saveGrant(a.auth.principal, ['return.cancel'], participant, operation, at, recoveryUntil);
        const recovery = this.#saveGrant(a.auth.principal, ['outcome.read'], participant, operation, at, recoveryUntil);
        const finalize = this.#saveGrant(id.receiver, ['receipt.finalize'], participant, operation, at, recoveryUntil);
        const d = { schema: 'aap.sdk.mcp-reservation.draft1', binding: id.binding, scope: { work: id.work }, transmitter: a.auth.principal,
          contributor: participant, receiver: id.receiver, context: v.context, manifest: ref(packet.manifest), mapping: this.#root.mappingRules[0],
          operation, actIdentity: { namespace: this.#root.namespace, id: 'act-' + randomUUID(), revision: 'v1' }, prepareId: v.prepareId,
          issuedAt: at, validUntil, recordsUntil: stamp(Date.parse(at) + policy.recordsMs), dataUntil: stamp(Date.parse(at) + policy.dataMs), recoveryUntil,
          captureGrants: [capture], sourceGrants: [...permission.grants, cancel], recoveryGrants: [recovery], finalizationGrants: [finalize],
          authorityPolicy: this.#root.authorityPolicy, retentionPolicy: this.#root.retentionPolicy };
        if (v.revisionOf) {
          if (!this.#root.relationRules.length) fail('revision_unsupported'); d.revisionOf = v.revisionOf; d.vocabulary = this.#root.relationRules[0];
          d.relationIdentity = { namespace: this.#root.namespace, id: 'relation-' + randomUUID(), revision: 'v1' };
        }
        const decision = decidePreparation(j({ descriptor: d, authority: this.#authority(reader, at, d), currentContext: v.context, existing: absent(), package: packet }));
        if (decision.decision !== 'reserve') fail('preparation_denied');
        selected = { handle: 'slot-' + randomUUID(), sequence: this.#store.sequence(), state: createReservationState(j(d)) };
        this.#store.putOperation(selected.handle, j(selected.state), selected.sequence);
      }
      return wrap('prepare_return', { descriptor: selected.state.descriptor, reservation: controlReference(selected.state.descriptor), returnHandle: selected.handle });
    }, now => {
      const d = selected.state.descriptor, a = this.#authority(reader, now, d);
      if (recovered && authorize(j(d), j(a), 'outcome.read').allowed) return;
      requireAllowed(authorize(j(d), j(a), 'return.prepare')); requireAllowed(authorize(j(d), j(a), 'capture.record'));
    });
  }
  #pin(reader, handle, input, reservationJson) {
    const expression = validateExpression(input), reservation = reservationJson === undefined ? null
      : parseValidated(reservationJson, (v, c, p) => c.data(v, p)); let recovering = false;
    return this.#run(at => {
      const { entry, a } = this.#entry(handle, reader, at), d = entry.state.descriptor;
      if (reservation && !equal(reservation, controlReference(d))) fail('reservation_mismatch');
      if (entry.state.intent.state === 'known' || entry.state.receipt.state === 'known') {
        const write = authorize(j(d), j(a), 'return.submit').allowed && authorize(j(d), j(a), 'capture.record').allowed;
        if (entry.state.receipt.state === 'known' || !write) requireAllowed(authorize(j(d), j(a), 'outcome.read'));
        if (entry.state.intent.state !== 'known' || !equal(entry.state.intent.value, expressionFingerprint(j(d), j(expression)))) fail('intent_conflict');
        recovering = true;
        return controlReference(entry.state.descriptor);
      }
      const next = reduceReservation(j(entry.state), j({ type: 'pin', at, expression, authority: a }));
      if (!['pinned', 'pin-recovered'].includes(next.decision)) fail(next.decision);
      const compiled = compileReturn(j(entry.state.descriptor), j(expression), at);
      this.#store.putOperation(handle, j(next.state), entry.sequence);
      for (const carrier of compiled.carriers) this.#store.stage(entry.state.descriptor.operation, carrier);
      return controlReference(next.state.descriptor);
    }, now => {
      const { entry, a } = this.#entry(handle, reader, now);
      if (recovering && authorize(j(entry.state.descriptor), j(a), 'outcome.read').allowed) return;
      else { requireAllowed(authorize(j(entry.state.descriptor), j(a), 'return.submit')); requireAllowed(authorize(j(entry.state.descriptor), j(a), 'capture.record')); }
    });
  }
  #finalization(d, at) {
    if (at >= d.recoveryUntil) fail('finalization_expired');
    for (const reference of d.finalizationGrants) {
      const g = this.#grant(reference);
      if (g.revoked || g.record.body.principal !== d.receiver || !equal(g.target, d.operation)
        || !g.record.body.rights.includes('receipt.finalize') || g.record.body.notBefore > at || at >= g.record.body.notAfter) fail('finalization_denied');
    }
  }
  #receipt(entry, outcome, at, reason, query = null) {
    const s = entry.state, d = s.descriptor, committed = outcome === 'committed';
    if (at >= d.recoveryUntil) fail('finalization_expired');
    if (!committed && !query) this.#finalization(d, at);
    const body = { operation: d.operation, requestDigest: s.request.state === 'known' ? known(requestDigest(j(s.request.value))) : absent(), outcome,
      recorded: committed ? s.request.value.records.map(ref) : [], retained: committed ? s.request.value.materials : [],
      authority: { principal: query ? query.caller : d.receiver, grants: query ? query.grants : committed ? d.captureGrants : d.finalizationGrants, policy: d.authorityPolicy },
      reason: known(reason), retention: { policy: d.retentionPolicy, recordsUntil: committed ? d.recordsUntil : [at, d.recordsUntil].sort().at(-1),
        ...(committed && s.request.value.materials.length ? { dataUntil: d.dataUntil } : {}), recoveryUntil: d.recoveryUntil } };
    const receipt = this.#record('receipt', body, d.receiver, at);
    this.#store.putRecord(j(receipt), d.recoveryUntil);
    const next = reduceReservation(j(s), j({ type: 'observe-terminal', at, receipt, nonCommitObserved: !committed, fenceObserved: !committed, ...(query ? { query } : {}) }));
    this.#store.putOperation(entry.handle, j(next.state), entry.sequence); this.#store.clearStaging(d.operation); return next.state;
  }
  #view(state, handle, at) {
    const terminal = state.receipt.state === 'known', d = state.descriptor;
    const status = { schema: 'aap.status.draft1', operation: d.operation, issuer: d.receiver, observedAt: at,
      state: terminal ? 'terminal' : state.request.state === 'known' ? 'pending' : 'not-seen',
      receipt: terminal ? known(ref(state.receipt.value)) : absent(), reason: absent() };
    return wrap('submit_expression', { reservation: controlReference(d), returnHandle: handle,
      slot: terminal ? 'terminal' : state.closure.state === 'known' ? 'closed' : state.request.state === 'known' ? 'bound' : 'reserved',
      status, receipt: terminal ? state.receipt : absent() });
  }
  #finish(reader, handle) {
    let committed = false, rejected = false, entry;
    return this.#run(at => {
      const selected = this.#entry(handle, reader, at); entry = selected.entry;
      if (entry.state.receipt.state === 'known') {
        requireAllowed(authorize(j(entry.state.descriptor), j(selected.a), 'outcome.read')); return this.#view(entry.state, handle, at);
      }
      if (entry.state.request.state !== 'known') fail('return_not_pinned');
      const d = entry.state.descriptor, a = this.#authority(reader, at, d);
      const write = authorize(j(d), j(a), 'return.submit'), capture = authorize(j(d), j(a), 'capture.record');
      if (!write.allowed || !capture.allowed || entry.state.closure.state === 'known') {
        requireAllowed(authorize(j(d), j(a), 'outcome.read')); rejected = true;
        return this.#view(this.#receipt(entry, 'rejected', at, 'write-closed'), handle, at);
      }
      const staged = this.#store.staged(d.operation), required = entry.state.request.value.materials;
      if (staged.length !== required.length || required.some(r => !staged.some(x => equal(x.ref, r)))) fail('staging_incomplete');
      for (const r of entry.state.request.value.records) this.#store.putRecord(j(r), d.recordsUntil);
      for (const material of staged) this.#store.putData(material.ref, material.original, d.dataUntil);
      committed = true; return this.#view(this.#receipt(entry, 'committed', at, 'recorded'), handle, at);
    }, now => {
      const d = entry.state.descriptor, a = this.#authority(reader, now, d);
      if (committed) { requireAllowed(authorize(j(d), j(a), 'return.submit')); requireAllowed(authorize(j(d), j(a), 'capture.record')); }
      else { requireAllowed(authorize(j(d), j(a), 'outcome.read')); if (rejected) this.#finalization(d, now); }
    });
  }
  #status(reader, handle) {
    let rejected = false;
    return this.#run(at => {
      const { entry, a } = this.#entry(handle, reader, at, 'outcome.read');
      let state = entry.state; const d = state.descriptor;
      if (state.receipt.state !== 'known' && (!authorize(j(d), j(a), 'return.submit').allowed || !authorize(j(d), j(a), 'capture.record').allowed)) {
        if (state.request.state === 'known') { state = this.#receipt(entry, 'rejected', at, 'write-closed'); rejected = true; }
        else {
          state = reduceReservation(j(state), j({ type: 'close', at, reason: at >= d.validUntil ? 'expired' : !a.contextAvailable ? 'withdrawn' : 'revoked',
            knownUncommitted: true, fenceObserved: true })).state;
          this.#store.putOperation(handle, j(state), entry.sequence);
        }
      }
      return projectReturn(j(state), j({ authority: a, availability: 'available', returnHandle: handle }));
    }, now => { const { entry } = this.#entry(handle, reader, now, 'outcome.read'); if (rejected) this.#finalization(entry.state.descriptor, now); });
  }
  #cancel(reader, handle) {
    let selected;
    return this.#run(at => {
      const { entry, a } = this.#entry(handle, reader, at, 'return.cancel'); selected = entry;
      const planned = planCancellation(j(entry.state.descriptor), j(a)); if (!planned.query) fail('cancel_denied');
      // The exclusive owner transaction observes the old outcome first. A known
      // commit wins; otherwise this same transaction writes a durable fence.
      const state = entry.state.receipt.state === 'known' ? entry.state : this.#receipt(entry, 'cancelled', at, 'cancelled', planned.query);
      return this.#view(state, handle, at);
    }, now => this.#entry(selected.handle, reader, now, 'return.cancel'));
  }
  appendAppReport(input, until) {
    const record = validateRecord(input); checkTime(until);
    if (record.type !== 'report' || record.issuer !== this.#identity.owner) fail('app_report');
    return this.#run(at => { if (at >= until) fail('retention_expired'); return this.#store.putRecord(j(record), until); });
  }
  publishInspection(input) {
    const v = parseValidated(input, (x, c) => {
      c.object(x, ['selection', 'manifest', 'readers', 'until']); c.name(x.selection); checkRecord(x.manifest, c, ['manifest']);
      c.list(x.readers, ['readers'], r => c.identifier(r), { set: true, min: 1 }); c.time(x.until);
      if (x.manifest.type !== 'manifest' || x.manifest.issuer !== this.#identity.owner
        || !equal(x.manifest.scope, { work: this.#identity.work })
        || x.manifest.body.records.length > 16 || x.manifest.body.data.length > 8) fail('inspection_manifest');
    });
    let selected;
    return this.#run(at => {
      if (at >= v.until || Date.parse(v.until) - Date.parse(at) > 300000) fail('inspection_time');
      const prior = this.#store.control('selection:' + key(v.selection));
      if (!prior && this.#store.controls().filter(x => x.key.startsWith('selection:')).length >= 256) fail('inspection_capacity');
      let until = v.until;
      for (const principal of v.readers) {
        const e = this.#enrollment(principal); if (!e?.active) fail('inspection_reader'); const g = this.#grant(e.sourceGrant);
        if (g.revoked || g.record.body.notBefore > at || !g.record.body.rights.includes('inspection.read')) fail('inspection_reader');
        until = minimum(until, g.record.body.notAfter);
      }
      for (const reference of v.manifest.body.records) {
        const row = this.#store.record(reference); if (!row?.record) fail('inspection_unavailable'); until = minimum(until, row.until);
      }
      for (const reference of v.manifest.body.data) {
        const row = this.#store.data(reference); if (!row?.original) fail('inspection_unavailable'); until = minimum(until, row.until);
      }
      if (at >= until) fail('inspection_unavailable');
      selected = { schema: 'aap.sdk.mcp-selection.draft1', selection: v.selection, work: this.#identity.work,
        manifest: ref(v.manifest), readers: v.readers, until, available: true };
      if (prior && !equal(prior, selected)) fail('inspection_conflict');
      this.#store.putRecord(j(v.manifest), until); this.#store.putControl('selection:' + key(v.selection), selected);
      // The owner stores only selection refs. Projection/data are read afresh.
      return freeze(selected);
    }, now => { if (now >= selected.until) fail('inspection_expired'); });
  }
  withdrawInspection(selectionJson) {
    const name = parseValidated(selectionJson, (v, c) => c.name(v));
    return this.#run(() => { const s = this.#store.control('selection:' + key(name)); if (!s) fail('inspection_denied');
      this.#store.putControl('selection:' + key(name), { ...s, available: false }); });
  }
  #inspect(reader, input) {
    const q = parseValidated(input, (v, c) => {
      c.object(v, ['selection'], ['cursor', 'data']); c.name(v.selection);
      if (Object.hasOwn(v, 'cursor')) c.name(v.cursor); if (Object.hasOwn(v, 'data')) c.data(v.data, ['data']);
      if (Object.hasOwn(v, 'cursor') && Object.hasOwn(v, 'data')) fail('inspection_mode');
    });
    const permission = at => {
      const a = this.#authority(reader, at); requireAllowed(authorizeWork(j(this.#identity.work), j(a), 'inspection.read'));
      if (q.data) requireAllowed(authorizeWork(j(this.#identity.work), j(a), 'data.read'));
      const raw = this.#store.control('selection:' + key(q.selection)), s = raw && checkSelection(raw, this.#identity.work);
      if (!s?.available || at >= s.until || !s.readers.includes(a.auth.principal)) fail('inspection_denied');
      return { a, s };
    };
    return this.#run(at => {
      const { a, s } = permission(at), row = this.#store.record(s.manifest);
      if (!row?.record || at >= row.until) fail('inspection_unavailable'); const manifest = row.record;
      if (q.data) {
        if (!manifest.body.data.some(r => equal(r, q.data))) fail('inspection_denied');
        const data = this.#store.data(q.data); if (!data?.original || at >= data.until) fail('inspection_unavailable');
        return wrap('inspect_process', { kind: 'data', manifest: s.manifest, carrier: { ref: q.data, encoding: 'utf8',
          value: new TextDecoder('utf-8', { fatal: true, ignoreBOM: true }).decode(data.original) } });
      }
      const cursor = n => 'view-' + n + '-' + key({ work: s.work, principal: a.auth.principal, selection: s.selection,
        manifest: s.manifest, epoch: this.#root.epoch, until: s.until, page: n });
      let index = 0;
      if (q.cursor) {
        const match = /^view-(0|[1-9][0-9]*)-[a-f0-9]{64}$/.exec(q.cursor); index = match ? Number(match[1]) : -1;
        if (!Number.isSafeInteger(index) || index < 0 || q.cursor !== cursor(index) || index >= manifest.body.records.length) fail('inspection_cursor');
      }
      const reference = manifest.body.records[index], source = reference ? this.#store.record(reference) : null;
      if (reference && (!source?.record || at >= source.until)) fail('inspection_unavailable');
      const record = source?.record ?? null;
      return wrap('inspect_process', { kind: 'page', manifest, records: record ? [record] : [], carriers: [],
        projection: projectInspection(record ? j(record) : null, j(s.manifest)),
        nextCursor: index + 1 < manifest.body.records.length ? known(cursor(index + 1)) : absent() });
    }, now => { permission(now); });
  }
  // Trusted owner inspection only; participant inspection selections are a later
  // adapter. Returned rows distinguish expired/missing/retired from original data.
  inspectRecord(referenceJson) {
    const r = parseValidated(referenceJson, (v, c, p) => c.ref(v, p)); const row = this.#store.record(r), at = this.#now();
    return row ? { ...row, record: at < row.until ? row.record : null } : null;
  }
  inspectData(referenceJson) {
    const r = parseValidated(referenceJson, (v, c, p) => c.data(v, p)); const row = this.#store.data(r), at = this.#now();
    return row ? { ...row, original: at < row.until ? row.original : null } : null;
  }
  retire(input) {
    const v = parseValidated(input, (x, c) => {
      c.object(x, ['subject', 'reason']); c.anyRef(x.subject, ['subject']); c.name(x.reason);
    });
    return this.#run(at => {
      const retirement = { at, actor: this.#identity.owner, policy: this.#root.retentionPolicy, reason: v.reason };
      // Pending payload copies cannot be silently purged. Close/finalize them
      // through their exact operation first; this is not a physical erase claim.
      if (v.subject.kind === 'data' && this.#store.operations().some(x => x.state.receipt.state !== 'known'
        && x.state.request.state === 'known' && x.state.request.value.materials.some(r => equal(r, v.subject)))) fail('pending_material');
      return v.subject.kind === 'data' ? this.#store.retireData(v.subject, retirement) : this.#store.retireRecord(v.subject, retirement);
    });
  }
}
