// Pure binding/control decisions. Supplied principal/authority observations are
// inert trusted inputs, not OAuth verification or a durable authorization store.
import { LIMITS, TYPES, parseValidated, checkRecord, checkRequest, checkOperation, checkStatus,
  checkCarrier, validateRecord, validateRequest, payloadReference, recordReference,
  requestDigest, canonicalBytes, equal, freeze, known, absent, fail } from './core.mjs';

export const TOOLS = Object.freeze(['resume_work', 'read_context', 'prepare_return',
  'submit_expression', 'return_status', 'cancel_return', 'inspect_process']);
export const RIGHTS = Object.freeze(['work.resume', 'context.read', 'return.prepare',
  'return.submit', 'outcome.read', 'return.cancel', 'inspection.read', 'data.read', 'capture.record']);
const json = JSON.stringify;
export const controlReference = value => payloadReference(canonicalBytes(value), 'application/json', LIMITS.maxEnvelopeBytes);
const metadata = v => ({ mode: 'capability-return', source: known(v.transmitter),
  material: [v.context, v.manifest, ...v.sourceGrants], coverage: [],
  gaps: ['model-origin-unverified', 'complete-context-unverified', 'operator-controlled'] });

export function checkExpression(v, c, p) {
  c.one(v?.form, ['material', 'refusal']);
  c.object(v, v.form === 'material' ? ['form', 'mediaType', 'text'] : ['form'], v.form === 'refusal' ? ['statement'] : []);
  if (v.form === 'material') {
    c.text(v.mediaType, 255); if (!v.mediaType.length) fail('media_label'); c.text(v.text, LIMITS.maxDataBytes);
  } else if (Object.hasOwn(v, 'statement')) c.text(v.statement, LIMITS.maxDataBytes);
}
export const validateExpression = input => parseValidated(input, checkExpression);
export function validateToolArguments(tool, input) {
  if (!TOOLS.includes(tool)) fail('tool');
  return parseValidated(input, (v, c, p) => {
    const required = { resume_work: ['work'], read_context: ['work'], prepare_return: ['work', 'context', 'prepareId'],
      submit_expression: ['work', 'returnHandle', 'reservation', 'expression'], return_status: ['work', 'returnHandle'],
      cancel_return: ['work', 'returnHandle'], inspect_process: ['work', 'selection'] };
    const optional = { resume_work: ['cursor'], prepare_return: ['revisionOf'], inspect_process: ['cursor', 'data'] };
    c.object(v, required[tool], optional[tool] ?? []); c.name(v.work);
    for (const k of ['returnHandle', 'prepareId', 'cursor', 'selection']) if (Object.hasOwn(v, k)) c.name(v[k]);
    if (tool === 'prepare_return') { c.ref(v.context, ['context'], 'context'); if (Object.hasOwn(v, 'revisionOf')) c.ref(v.revisionOf, ['revisionOf'], 'act'); }
    if (tool === 'submit_expression') { c.data(v.reservation, ['reservation']); checkExpression(v.expression, c, ['expression']); }
    if (tool === 'inspect_process') {
      if (Object.hasOwn(v, 'data')) c.data(v.data, ['data']);
      if (Object.hasOwn(v, 'data') && Object.hasOwn(v, 'cursor')) fail('inspection_mode');
    }
  });
}

export function checkDescriptor(v, c, p) {
  c.object(v, ['schema', 'binding', 'scope', 'transmitter', 'contributor', 'receiver', 'context', 'manifest', 'mapping',
    'operation', 'actIdentity', 'prepareId', 'issuedAt', 'validUntil', 'recordsUntil', 'dataUntil', 'recoveryUntil',
    'captureGrants', 'sourceGrants', 'recoveryGrants', 'finalizationGrants', 'authorityPolicy', 'retentionPolicy'], ['revisionOf', 'vocabulary', 'relationIdentity']);
  if (v.schema !== 'aap.sdk.mcp-reservation.draft1') fail('schema');
  c.ref(v.binding, [...p, 'binding'], 'binding'); c.scope(v.scope, [...p, 'scope']); if (v.scope.occurrence !== undefined) fail('unsupported_occurrence');
  c.identifier(v.transmitter); c.identifier(v.receiver); if (v.transmitter === v.receiver) fail('capture_identity');
  c.ref(v.contributor, [...p, 'contributor'], 'participant'); c.ref(v.context, [...p, 'context'], 'context'); c.ref(v.manifest, [...p, 'manifest'], 'manifest');
  c.rule(v.mapping, [...p, 'mapping']); c.identity(v.actIdentity); c.name(v.prepareId); checkOperation(v.operation, c, [...p, 'operation']);
  if (v.operation.caller !== v.receiver || !equal(v.binding, v.operation.binding) || !equal(v.scope, v.operation.scope)) fail('operation_binding');
  for (const k of ['captureGrants', 'sourceGrants', 'recoveryGrants', 'finalizationGrants']) c.refs(v[k], [...p, k], 'grant', true, 1);
  c.rule(v.authorityPolicy, [...p, 'authorityPolicy']); c.rule(v.retentionPolicy, [...p, 'retentionPolicy']);
  for (const k of ['issuedAt', 'validUntil', 'recordsUntil', 'dataUntil', 'recoveryUntil']) c.time(v[k]);
  const duration = Date.parse(v.validUntil) - Date.parse(v.issuedAt);
  if (duration <= 0 || duration > LIMITS.maxWriteValidityMs || v.recordsUntil < v.validUntil || v.dataUntil < v.validUntil
    || v.recoveryUntil < v.validUntil || Date.parse(v.recoveryUntil) - Date.parse(v.issuedAt) > LIMITS.maxRecoveryMs) fail('reservation_time');
  const revision = Object.hasOwn(v, 'revisionOf');
  if (revision !== Object.hasOwn(v, 'vocabulary') || revision !== Object.hasOwn(v, 'relationIdentity')) fail('revision_fields');
  if (revision) {
    c.ref(v.revisionOf, [...p, 'revisionOf'], 'act'); c.rule(v.vocabulary, [...p, 'vocabulary']); c.identity(v.relationIdentity);
    if (equal(v.actIdentity, v.relationIdentity)) fail('batch_identity');
  }
  if (canonicalBytes(v).length > LIMITS.maxRecordBytes) fail('reservation_bytes');
}
export const validateDescriptor = input => parseValidated(input, checkDescriptor);

export function preparationFingerprint(input) {
  const v = parseValidated(input, (x, c) => {
    c.object(x, ['binding', 'transmitter', 'work', 'epoch', 'prepareId', 'context'], ['revisionOf']);
    c.ref(x.binding, ['binding'], 'binding'); c.identifier(x.transmitter); c.ref(x.work, ['work'], 'work');
    c.name(x.epoch); c.name(x.prepareId); c.ref(x.context, ['context'], 'context'); if (Object.hasOwn(x, 'revisionOf')) c.ref(x.revisionOf, ['revisionOf'], 'act');
  });
  return controlReference({ schema: 'aap.sdk.mcp-prepare-intent.draft1', ...v });
}
export function descriptorPreparation(v) {
  return preparationFingerprint(json({ binding: v.binding, transmitter: v.transmitter, work: v.scope.work,
    epoch: v.operation.epoch, prepareId: v.prepareId, context: v.context, ...(v.revisionOf ? { revisionOf: v.revisionOf } : {}) }));
}
export function expressionFingerprint(descriptorInput, expressionInput) {
  const d = validateDescriptor(descriptorInput), expression = validateExpression(expressionInput);
  return controlReference({ schema: 'aap.sdk.mcp-intent.draft1', reservation: controlReference(d), expression });
}

export function checkAuthority(v, c, p) {
  c.object(v, ['at', 'auth', 'enrollment', 'trustedIssuers', 'grants', 'contextAvailable', 'contextUntil', 'mappingRules', 'relationRules']);
  c.time(v.at); c.object(v.auth, ['verified', 'principal', 'notAfter']); c.bool(v.auth.verified); c.identifier(v.auth.principal); c.time(v.auth.notAfter);
  c.object(v.enrollment, ['scope', 'principal', 'participant', 'receiver', 'active', 'policy']);
  c.scope(v.enrollment.scope, [...p, 'enrollment', 'scope']); c.identifier(v.enrollment.principal); c.identifier(v.enrollment.receiver);
  c.ref(v.enrollment.participant, [...p, 'enrollment', 'participant'], 'participant'); c.bool(v.enrollment.active); c.rule(v.enrollment.policy, [...p, 'enrollment', 'policy']);
  c.list(v.trustedIssuers, [...p, 'trustedIssuers'], x => c.identifier(x), { set: true }); c.bool(v.contextAvailable); c.time(v.contextUntil);
  c.rules(v.mappingRules, [...p, 'mappingRules']); c.rules(v.relationRules, [...p, 'relationRules']);
  c.list(v.grants, [...p, 'grants'], (g, q) => {
    c.object(g, ['record', 'target', 'revoked']); checkRecord(g.record, c, [...q, 'record']); if (g.record.type !== 'grant') fail('ref_type');
    if (g.target !== null) checkOperation(g.target, c, [...q, 'target']); c.bool(g.revoked);
  });
  if (new Set(v.grants.map(x => canonicalBytes(x.record.identity).toString())).size !== v.grants.length) fail('grant_duplicate');
}
export const validateAuthority = input => parseValidated(input, checkAuthority);

// Pre-reservation reads/setup use Work-scoped authority; no slot is needed.
export function authorizeWork(workInput, authorityInput, right) {
  if (!['work.resume', 'context.read', 'return.prepare', 'return.submit', 'inspection.read', 'data.read'].includes(right)) fail('work_right');
  const work = parseValidated(workInput, (x, c) => c.ref(x, [], 'work'));
  const a = validateAuthority(authorityInput), e = a.enrollment;
  const deny = reason => freeze({ allowed: false, reason, grants: [] });
  if (!a.auth.verified || a.at >= a.auth.notAfter || a.auth.principal !== e.principal) return deny('authentication');
  if (!equal(e.scope, { work })) return deny('work_scope');
  if (!e.active) return deny('consent');
  if (['context.read', 'return.prepare', 'return.submit'].includes(right) && (!a.contextAvailable || a.at >= a.contextUntil)) return deny('context');
  const matches = a.grants.filter(({ record: g, target, revoked }) => !target && !revoked
    && a.trustedIssuers.includes(g.issuer) && g.body.principal === e.principal && equal(g.scope, e.scope)
    && equal(g.body.policy, e.policy) && g.body.rights.includes(right) && g.body.notBefore <= a.at && a.at < g.body.notAfter
    && (!['return.prepare', 'return.submit'].includes(right) || g.body.attributions.some(r => equal(r, e.participant))));
  return matches.length ? freeze({ allowed: true, reason: 'authorized', grants: matches.map(g => recordReference(json(g.record))) }) : deny('grant');
}

// Returns a decision over supplied observations. It authenticates nobody.
export function authorize(descriptorInput, authorityInput, right) {
  if (!RIGHTS.includes(right)) fail('right');
  const d = validateDescriptor(descriptorInput), a = validateAuthority(authorityInput), e = a.enrollment;
  const deny = reason => freeze({ allowed: false, reason, grants: [] });
  if (a.at < d.issuedAt) return deny('reservation_time');
  if (!a.auth.verified || a.auth.notAfter <= a.at || a.auth.principal !== e.principal || e.principal !== d.transmitter) return deny('authentication');
  if (!equal(e.scope, d.scope) || !equal(e.participant, d.contributor) || e.receiver !== d.receiver || !equal(e.policy, d.authorityPolicy)) return deny('work_scope');
  if (['return.prepare', 'return.submit', 'capture.record'].includes(right)
    && (!a.mappingRules.some(r => equal(r, d.mapping)) || (d.vocabulary && !a.relationRules.some(r => equal(r, d.vocabulary))))) return deny('unsupported_mapping');
  const recovery = ['outcome.read', 'return.cancel'].includes(right);
  if (!e.active && right !== 'outcome.read') return deny('consent');
  if (!recovery && right !== 'inspection.read' && right !== 'data.read'
    && (!a.contextAvailable || a.at >= a.contextUntil || a.at >= d.validUntil)) return deny('write_closed');
  if (right === 'outcome.read' && a.at >= d.recoveryUntil) return deny('recovery_closed');
  const principal = right === 'capture.record' ? d.receiver : d.transmitter;
  const grantRefs = right === 'capture.record' ? d.captureGrants : right === 'outcome.read' ? d.recoveryGrants : d.sourceGrants;
  const matches = a.grants.filter(({ record: g, target, revoked }) => !revoked && a.trustedIssuers.includes(g.issuer)
    && g.body.principal === principal && equal(g.scope, d.scope) && equal(g.body.policy, d.authorityPolicy)
    && g.body.notBefore <= a.at && a.at < g.body.notAfter && g.body.rights.includes(right)
    && grantRefs.some(r => equal(r, recordReference(json(g))))
    && (recovery || right === 'capture.record' ? target !== null && equal(target, d.operation) : target === null || equal(target, d.operation))
    && (!['capture.record', 'return.submit', 'return.prepare'].includes(right) || g.body.attributions.some(r => equal(r, d.contributor)))
    && (right !== 'return.prepare' || (g.body.notAfter >= d.validUntil && a.contextUntil >= d.validUntil)));
  if (right === 'capture.record' && matches.length !== d.captureGrants.length) return deny('grant');
  return matches.length ? freeze({ allowed: true, reason: 'authorized', grants: matches.map(g => recordReference(json(g.record))) }) : deny('grant');
}

export function decidePreparation(input) {
  const v = parseValidated(input, (x, c, p) => {
    c.object(x, ['descriptor', 'authority', 'currentContext', 'existing'], ['package']); checkDescriptor(x.descriptor, c, ['descriptor']);
    checkAuthority(x.authority, c, ['authority']); c.ref(x.currentContext, ['currentContext'], 'context');
    c.fact(x.existing, ['existing'], (d, q) => checkDescriptor(d, c, q));
    if (!['known', 'not-recorded'].includes(x.existing.state)) fail('preparation_unknown');
  });
  const d = v.descriptor;
  if (v.existing.state === 'known') {
    const old = v.existing.value;
    if (!equal(descriptorPreparation(old), descriptorPreparation(d))) return freeze({ decision: 'conflict' });
    const write = authorize(json(old), json(v.authority), 'return.prepare');
    const recovery = authorize(json(old), json(v.authority), 'outcome.read');
    return freeze({ decision: write.allowed || recovery.allowed ? 'recover' : 'denied', ...(write.allowed || recovery.allowed ? { descriptor: old } : {}) });
  }
  const a = authorize(json(d), json(v.authority), 'return.prepare');
  if (!a.allowed) return freeze({ decision: 'denied' });
  if (!authorize(json(d), json(v.authority), 'capture.record').allowed
    || !authorize(json(d), json(v.authority), 'outcome.read').allowed) return freeze({ decision: 'denied' });
  for (const [refs, deadline] of [[d.captureGrants, d.validUntil], [d.recoveryGrants, d.recoveryUntil]]) {
    if (refs.some(ref => !v.authority.grants.some(g => equal(ref, recordReference(json(g.record))) && g.record.body.notAfter >= deadline)))
      return freeze({ decision: 'denied' });
  }
  if (v.authority.at < d.issuedAt) return freeze({ decision: 'denied' });
  if (!equal(v.currentContext, d.context)) return freeze({ decision: 'context-changed' });
  if (!Object.hasOwn(v, 'package')) fail('context_dependency');
  validateContextBinding(json(d), json(v.package));
  // Future owner must execute this reservation effect atomically; no map is kept here.
  return freeze({ decision: 'reserve', descriptor: d });
}

export function compileReturn(descriptorInput, expressionInput, capturedAt) {
  const d = validateDescriptor(descriptorInput), expression = validateExpression(expressionInput);
  parseValidated(json(capturedAt), (x, c) => c.time(x));
  if (capturedAt < d.issuedAt || capturedAt >= d.validUntil) fail('capture_time');
  const hasBytes = expression.form === 'material' || Object.hasOwn(expression, 'statement');
  const text = expression.form === 'material' ? expression.text : expression.statement;
  const media = expression.form === 'material' ? expression.mediaType : 'text/plain;charset=utf-8';
  const original = hasBytes ? payloadReference(text, media) : null;
  const provenance = { ...metadata(d), observedAt: capturedAt };
  const act = { schema: 'aap.record.draft1', type: 'act', identity: d.actIdentity, scope: d.scope,
    issuer: d.receiver, issuedAt: capturedAt, provenance, body: { contributor: d.contributor, mapping: d.mapping,
      expression: known(expression.form === 'material' ? { form: 'material', items: [original] }
        : { form: 'refusal', ...(hasBytes ? { statement: original } : {}) }),
      basis: known([d.context]), transmitter: known(d.transmitter) } };
  const records = [act];
  if (d.revisionOf) records.push({ schema: 'aap.record.draft1', type: 'relation', identity: d.relationIdentity,
    scope: d.scope, issuer: d.receiver, issuedAt: capturedAt, provenance,
    body: { vocabulary: d.vocabulary, members: [{ role: 'revision', subject: recordReference(json(act)) },
      { role: 'original', subject: d.revisionOf }], agreement: known([]) } });
  const request = validateRequest(json({ schema: 'aap.request.draft1', binding: d.binding, action: 'record',
    operation: { epoch: d.operation.epoch, id: d.operation.id }, caller: d.receiver, scope: d.scope,
    basis: known([d.context]), grants: d.captureGrants, validUntil: d.validUntil, preconditions: [], records,
    materials: original ? [original] : [] }));
  return freeze({ intent: expressionFingerprint(descriptorInput, expressionInput), request,
    requestDigest: requestDigest(json(request)), carriers: original ? [{ ref: original, encoding: 'utf8', value: text }] : [] });
}

export function validateProfile(input) {
  const v = validateRecord(input); if (v.type !== 'binding') fail('ref_type');
  const b = v.body;
  if (!equal([...b.capabilities].sort(), ['exchange', 'inspect', 'record']) || !equal(b.encodings, ['utf8'])
    || b.extensions.length || !equal([...b.recordTypes].sort(), [...TYPES].sort()) || !equal(b.limits, LIMITS)) fail('binding_profile');
  return v;
}

export function checkReturnView(v, c, p) {
  c.object(v, ['reservation', 'returnHandle', 'slot', 'status', 'receipt']); c.data(v.reservation, [...p, 'reservation']); c.name(v.returnHandle);
  c.one(v.slot, ['reserved', 'bound', 'closed', 'terminal', 'unknown']); checkStatus(v.status, c, [...p, 'status']);
  c.fact(v.receipt, [...p, 'receipt'], (x, q) => { checkRecord(x, c, q); if (x.type !== 'receipt') fail('ref_type'); });
  if (v.status.state === 'terminal') {
    if (v.slot !== 'terminal' || v.receipt.state !== 'known' || !equal(v.status.receipt.value, recordReference(json(v.receipt.value)))
      || !equal(v.status.operation, v.receipt.value.body.operation)) fail('terminal_body');
  } else if (v.receipt.state === 'known' || v.slot === 'terminal') fail('terminal_body');
}
export function validateToolResult(tool, input) {
  if (!TOOLS.includes(tool)) fail('tool');
  return parseValidated(input, (v, c, p) => {
    c.object(v, ['schema', 'processing', 'reason', 'value']); if (v.schema !== 'aap.sdk.mcp-result.draft1') fail('schema');
    c.one(v.processing, ['completed', 'denied', 'invalid', 'unsupported', 'unavailable', 'unknown']);
    c.fact(v.reason, ['reason'], x => c.name(x));
    if (v.processing !== 'completed') { if (v.value !== null) fail('failure_value'); return; }
    if (['submit_expression', 'return_status', 'cancel_return'].includes(tool)) return checkReturnView(v.value, c, ['value']);
    const x = v.value, q = ['value'];
    if (tool === 'prepare_return') {
      c.object(x, ['descriptor', 'reservation', 'returnHandle']); checkDescriptor(x.descriptor, c, [...q, 'descriptor']); c.data(x.reservation, [...q, 'reservation']); c.name(x.returnHandle);
      if (!equal(controlReference(x.descriptor), x.reservation)) fail('reservation_digest'); return;
    }
    if (tool === 'resume_work') {
      c.object(x, ['work', 'binding', 'participant', 'context', 'permissions', 'operations', 'nextCursor']);
      c.ref(x.work, [...q, 'work'], 'work'); c.ref(x.binding, [...q, 'binding'], 'binding');
      c.fact(x.participant, [...q, 'participant'], (z, r) => c.ref(z, r, 'participant')); c.fact(x.context, [...q, 'context'], (z, r) => c.ref(z, r, 'context'));
      c.list(x.permissions, [...q, 'permissions'], z => { c.object(z, ['operation', 'notAfter']); c.one(z.operation, TOOLS); c.time(z.notAfter); });
      c.list(x.operations, [...q, 'operations'], (z, r) => {
        c.object(z, ['returnHandle', 'reservation', 'operation', 'validUntil', 'recoveryUntil']); c.name(z.returnHandle); c.data(z.reservation, [...r, 'reservation']);
        checkOperation(z.operation, c, [...r, 'operation']); if (!equal(z.operation.scope.work, x.work)) fail('work_scope'); c.time(z.validUntil); c.time(z.recoveryUntil);
      }, { max: 20 }); c.fact(x.nextCursor, [...q, 'nextCursor'], z => c.name(z)); return;
    }
    if (tool === 'read_context') {
      checkContextPackage(x, c, q); return;
    }
    c.one(x?.kind, ['page', 'data']);
    if (x.kind === 'data') {
      c.object(x, ['kind', 'manifest', 'carrier']); c.ref(x.manifest, [...q, 'manifest'], 'manifest'); checkCarrier(x.carrier, c, [...q, 'carrier']);
    } else {
      c.object(x, ['kind', 'manifest', 'records', 'carriers', 'projection', 'nextCursor']); checkPackage(x, c, q, true);
      checkCarrier(x.projection, c, [...q, 'projection']); c.fact(x.nextCursor, [...q, 'nextCursor'], z => c.name(z));
    }
  }, 1048576);
}
function checkPackage(x, c, p, partial) {
  checkRecord(x.manifest, c, [...p, 'manifest']); if (x.manifest.type !== 'manifest') fail('ref_type');
  c.list(x.records, [...p, 'records'], (z, r) => checkRecord(z, c, r), { max: 16 });
  c.list(x.carriers, [...p, 'carriers'], (z, r) => { checkCarrier(z, c, r); if (z.encoding !== 'utf8') fail('unsupported_encoding'); }, { max: 8 });
  if (x.carriers.reduce((n, z) => n + Buffer.byteLength(z.value), 0) > LIMITS.maxTotalDataBytes) fail('carrier_total');
  const mr = x.manifest.body.records, md = x.manifest.body.data;
  if (x.records.some(z => !mr.some(r => equal(r, recordReference(json(z))))) || x.carriers.some(z => !md.some(r => equal(r, z.ref)))) fail('manifest_membership');
  if (!partial && (mr.length !== x.records.length || md.length !== x.carriers.length)) fail('package_incomplete');
  if (new Set(x.records.map(z => json(z.identity))).size !== x.records.length || new Set(x.carriers.map(z => canonicalBytes(z.ref).toString())).size !== x.carriers.length) fail('package_duplicate');
  const scope = x.manifest.scope;
  if (x.records.some(z => z.scope ? !equal(z.scope, scope) : z.type === 'work' && !equal(recordReference(json(z)), scope.work))) fail('package_scope');
  if (x.work && !equal(x.work, scope.work)) fail('package_scope');
}
function checkContextPackage(x, c, p) {
  c.object(x, ['work', 'context', 'manifest', 'records', 'carriers']);
  c.ref(x.work, [...p, 'work'], 'work'); c.ref(x.context, [...p, 'context'], 'context');
  checkPackage(x, c, p, false);
  if (![x.work, x.context].every(r => x.records.some(z => equal(recordReference(json(z)), r)))) fail('context_dependency');
}

export function validateContextBinding(descriptorInput, packageInput) {
  const d = validateDescriptor(descriptorInput);
  const b = parseValidated(packageInput, checkContextPackage, 1048576);
  if (!equal(b.work, d.scope.work) || !equal(b.context, d.context) || !equal(recordReference(json(b.manifest)), d.manifest)) fail('context_binding');
  const find = ref => b.records.find(r => equal(recordReference(json(r)), ref));
  const has = ref => ref.kind === 'data' ? b.carriers.some(x => equal(x.ref, ref)) : !!find(ref);
  const work = find(d.scope.work), context = find(d.context), participant = find(d.contributor);
  if (!work || !context || !participant || participant.type !== 'participant' || participant.body.kind !== 'agent'
    || !work.body.actMappings.some(r => equal(r, d.mapping))) fail('capture_mapping');
  if (work.body.previous || work.body.capabilities.some(cap => !['record', 'exchange', 'inspect'].includes(cap))) fail('unsupported_work');
  for (const framed of work.body.framing) if (!has(framed)) fail('context_dependency');
  for (const rule of [d.mapping, ...Object.values(work.body.policies), ...context.body.conditions]) if (!has(rule.definition)) fail('context_dependency');
  for (const offered of context.body.offered) if (offered.mode === 'exact' && !has(offered.subject)) fail('context_dependency');
  if (d.revisionOf) {
    const target = find(d.revisionOf);
    if (!target || target.type !== 'act' || !equal(target.body.contributor, d.contributor)
      || !context.body.offered.some(o => o.mode === 'exact' && equal(o.subject, d.revisionOf))) fail('revision_target');
    if (!has(d.vocabulary.definition)) fail('context_dependency');
  }
  return b;
}

export function validateCarriage(input) {
  return parseValidated(input, (v, c, p) => {
    c.object(v, ['request', 'carriers']); // A pure completeness check, never authority or storage.
    checkRequest(v.request, c, ['request']); const request = v.request;
    c.list(v.carriers, ['carriers'], (x, q) => checkCarrier(x, c, q), { max: 8 });
    let encoded = 0n, decoded = 0n;
    for (const carrier of v.carriers) {
      encoded += BigInt(Buffer.byteLength(carrier.value)); decoded += BigInt(carrier.ref.length);
      if (carrier.encoding !== 'utf8') fail('unsupported_encoding');
      if (!request.materials.some(m => equal(m, carrier.ref))) fail('carrier_extra');
    }
    if (encoded > 131072n || decoded > 131072n) fail('carrier_total');
    for (const material of request.materials) if (!v.carriers.some(x => equal(x.ref, material))) fail('carrier_missing');
  });
}

// Later adapters must apply this to the actual serialized result/frame, not just
// its inner value. This is byte/JSON admission, not an MCP wire-version validator.
export function checkResultBudget(input) {
  parseValidated(input, () => {}, 1048576); return true;
}
