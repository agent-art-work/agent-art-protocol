// Pure candidate schema/byte contracts. No storage, clocks, randomness or clients.
import { createHash } from 'node:crypto';
import canonicalize from 'canonicalize';
import { visit } from 'jsonc-parser';

export const LIMITS = Object.freeze({ maxEnvelopeBytes: 2097152, maxRecordBytes: 65536,
  maxRequestBytes: 262144, maxDataBytes: 65536, maxTotalDataBytes: 131072,
  maxRecordsPerRequest: 16, maxMaterialsPerRequest: 8, maxArrayItems: 256,
  maxTextBytes: 131072, maxDepth: 64, maxReferenceDepth: 32,
  maxWriteValidityMs: 600000, maxRecoveryMs: 605400000 });
export const TYPES = Object.freeze(['work', 'participant', 'act', 'relation', 'context',
  'grant', 'receipt', 'report', 'claim', 'assessment', 'manifest', 'binding']);
export const DOMAINS = Object.freeze({ payload: 'payload-octets-v1',
  record: 'aap-record-jcs-draft1', request: 'aap-request-jcs-draft1' });
const CAPABILITIES = ['record', 'exchange', 'inspect', 'check', 'handoff'];
export class ParticipationContractError extends Error {
  constructor(code) { super(code); this.name = 'ParticipationContractError'; this.code = code; }
}
export const fail = code => { throw new ParticipationContractError(code); };
export const freeze = value => {
  if (value !== null && typeof value === 'object') {
    Object.values(value).forEach(freeze); Object.freeze(value);
  }
  return value;
};
export const equal = (a, b) => canonicalize(a) === canonicalize(b);
export const known = value => ({ state: 'known', value });
export const absent = (state = 'not-recorded') => ({ state });
export const canonicalBytes = value => Buffer.from(canonicalize(value), 'utf8');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const unicode = value => {
  if (typeof value !== 'string') fail('text');
  for (let i = 0; i < value.length; i++) {
    const n = value.charCodeAt(i);
    if (n >= 0xd800 && n <= 0xdbff) {
      const next = value.charCodeAt(++i); if (!(next >= 0xdc00 && next <= 0xdfff)) fail('unicode');
    } else if (n >= 0xdc00 && n <= 0xdfff) fail('unicode');
  }
};
const typed = Object.getPrototypeOf(Uint8Array.prototype);
const byteLength = Object.getOwnPropertyDescriptor(typed, 'byteLength').get;
const byteOffset = Object.getOwnPropertyDescriptor(typed, 'byteOffset').get;
const byteBuffer = Object.getOwnPropertyDescriptor(typed, 'buffer').get;
const byteName = Object.getOwnPropertyDescriptor(typed, Symbol.toStringTag).get;
const decoder = new TextDecoder('utf-8', { fatal: true, ignoreBOM: true });
export function octets(input, max = LIMITS.maxDataBytes) {
  if (typeof input === 'string') {
    if (input.length > max) fail('byte_limit'); unicode(input);
    if (Buffer.byteLength(input) > max) fail('byte_limit'); return Buffer.from(input, 'utf8');
  }
  if (!ArrayBuffer.isView(input) || byteName.call(input) !== 'Uint8Array') fail('byte_input');
  try {
    const n = byteLength.call(input); if (n > max) fail('byte_limit');
    const out = Buffer.alloc(n);
    out.set(new Uint8Array(byteBuffer.call(input), byteOffset.call(input), n)); return out;
  } catch (error) { if (error instanceof ParticipationContractError) throw error; fail('byte_input'); }
}

export class Reader {
  constructor(tokens) { this.tokens = tokens; }
  object(v, keys, optional = []) {
    if (!v || typeof v !== 'object' || Array.isArray(v)
      || keys.some(k => !Object.hasOwn(v, k))
      || Object.keys(v).some(k => !keys.includes(k) && !optional.includes(k))) fail('closed_object');
  }
  text(v, max = LIMITS.maxTextBytes) { unicode(v); if (Buffer.byteLength(v) > max) fail('text_limit'); }
  name(v) { this.text(v, 128); if (!/^[A-Za-z0-9][A-Za-z0-9._:-]*$/.test(v)) fail('name'); }
  identifier(v) { this.text(v, 512); if (!/^[A-Za-z][A-Za-z0-9+.-]*:[!-~]+$/.test(v)) fail('identifier'); }
  uint(v, p) {
    const token = this.tokens.get(JSON.stringify(p));
    if (!token || !/^(0|[1-9][0-9]*)$/.test(token) || !Number.isSafeInteger(v) || v < 0) fail('uint_token');
  }
  time(v) {
    if (typeof v !== 'string' || !/^(?!0000)\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(v)
      || !Number.isFinite(Date.parse(v)) || new Date(Date.parse(v)).toISOString() !== v) fail('timestamp');
  }
  one(v, values) { if (!values.includes(v)) fail('enum'); }
  bool(v) { if (typeof v !== 'boolean') fail('boolean'); }
  list(v, p, fn, { max = LIMITS.maxArrayItems, min = 0, set = false } = {}) {
    if (!Array.isArray(v) || v.length < min || v.length > max) fail('array_limit');
    v.forEach((x, i) => fn(x, [...p, i]));
    if (set && new Set(v.map(x => canonicalize(x))).size !== v.length) fail('duplicate_set');
  }
  fact(v, p, fn) {
    this.object(v, ['state'], v?.state === 'known' ? ['value'] : []);
    this.one(v.state, ['known', 'unknown', 'withheld', 'unavailable', 'not-recorded']);
    if (v.state === 'known') { if (!Object.hasOwn(v, 'value')) fail('fact'); fn(v.value, [...p, 'value']); }
  }
  identity(v) { this.object(v, ['namespace', 'id', 'revision']); this.identifier(v.namespace); this.name(v.id); this.name(v.revision); }
  digest(v, domain) {
    this.object(v, ['algorithm', 'domain', 'value']);
    if (v.algorithm !== 'sha-256' || v.domain !== domain || !/^[a-f0-9]{64}$/.test(v.value)) fail('digest');
  }
  ref(v, p, type) {
    this.object(v, ['kind', 'type', 'identity', 'digest']);
    if (v.kind !== 'record' || (type && v.type !== type)) fail('ref_type');
    this.one(v.type, TYPES); this.identity(v.identity); this.digest(v.digest, DOMAINS.record);
  }
  data(v, p) {
    this.object(v, ['kind', 'digest', 'length', 'mediaType']);
    if (v.kind !== 'data') fail('ref_type'); this.digest(v.digest, DOMAINS.payload);
    this.uint(v.length, [...p, 'length']); this.text(v.mediaType, 255);
    if (!v.mediaType.length) fail('media_label');
  }
  anyRef(v, p) { v?.kind === 'data' ? this.data(v, p) : this.ref(v, p); }
  rule(v, p) { this.object(v, ['id', 'revision', 'definition']); this.identifier(v.id); this.name(v.revision); this.anyRef(v.definition, [...p, 'definition']); }
  scope(v, p) {
    this.object(v, ['work'], ['occurrence']); this.ref(v.work, [...p, 'work'], 'work');
    if (Object.hasOwn(v, 'occurrence')) this.name(v.occurrence);
  }
  refs(v, p, type, set = false, min = 0) { this.list(v, p, (x, q) => this.ref(x, q, type), { set, min }); }
  dataRefs(v, p, set = false) { this.list(v, p, (x, q) => this.data(x, q), { set }); }
  rules(v, p) { this.list(v, p, (x, q) => this.rule(x, q)); }
  names(v, p, set = false) { this.list(v, p, x => this.name(x), { set }); }
  extensions(v, p) {
    if (Object.hasOwn(v, 'extensions')) {
      if (!v.extensions || Array.isArray(v.extensions) || typeof v.extensions !== 'object') fail('extensions');
      Object.keys(v.extensions).forEach(k => this.identifier(k));
    }
    if (Object.hasOwn(v, 'requires')) {
      this.list(v.requires, [...p, 'requires'], x => this.identifier(x), { set: true });
      if (v.requires.some(k => !Object.hasOwn(v.extensions ?? {}, k))) fail('requires_missing');
      if (v.requires.length) fail('unsupported_extension'); // This source cohort advertises none.
    }
  }
}

export function parseValidated(input, validate, maxBytes = LIMITS.maxEnvelopeBytes) {
  const bytes = octets(input, maxBytes); let text;
  try { text = decoder.decode(bytes); } catch { fail('utf8'); }
  if (text.charCodeAt(0) === 0xfeff) fail('envelope_bom');
  const stack = [], tokens = new Map();
  const begin = type => {
    if (stack.length >= LIMITS.maxDepth) fail('depth_limit');
    stack.push({ type, keys: new Set() });
  };
  try {
    visit(text, {
      onObjectBegin: () => begin('object'), onArrayBegin: () => begin('array'),
      onObjectEnd: () => { stack.pop(); }, onArrayEnd: () => { stack.pop(); },
      onObjectProperty: key => {
        unicode(key); const frame = stack.at(-1);
        if (frame?.type !== 'object' || frame.keys.has(key)) fail('duplicate_key'); frame.keys.add(key);
      },
      onLiteralValue: (v, offset, length, _line, _character, path) => {
        if (typeof v === 'string') unicode(v);
        if (typeof v === 'number') {
          if (!Number.isFinite(v)) fail('finite_number'); tokens.set(JSON.stringify(path()), text.slice(offset, offset + length));
        }
      },
      onError: () => fail('json'),
    }, { disallowComments: true, allowTrailingComma: false, allowEmptyContent: false });
    const value = JSON.parse(text), reader = new Reader(tokens);
    const budget = v => {
      if (typeof v === 'string') reader.text(v);
      else if (v && typeof v === 'object') {
        if (Array.isArray(v) && v.length > LIMITS.maxArrayItems) fail('array_limit');
        for (const [k, x] of Object.entries(v)) { reader.text(k); budget(x); }
      }
    };
    budget(value); validate(value, reader, []); return freeze(value);
  } catch (error) { if (error instanceof ParticipationContractError) throw error; fail('json'); }
}

const caps = (c, v, p) => c.list(v, p, x => c.one(x, CAPABILITIES), { set: true });
const sameIdentity = (a, b) => equal(a.identity, b.identity);
export function checkOperation(v, c, p) {
  c.object(v, ['binding', 'caller', 'scope', 'epoch', 'id', 'action']);
  c.ref(v.binding, [...p, 'binding'], 'binding'); c.identifier(v.caller); c.scope(v.scope, [...p, 'scope']);
  c.name(v.epoch); c.name(v.id); if (v.action !== 'record') fail('action');
}
export function checkRecord(v, c, p) {
  c.object(v, ['schema', 'type', 'identity', 'issuer', 'provenance', 'body'], ['scope', 'issuedAt', 'extensions', 'requires']);
  if (v.schema !== 'aap.record.draft1') fail('schema'); c.one(v.type, TYPES); c.identity(v.identity); c.identifier(v.issuer);
  if (['work', 'binding'].includes(v.type)) { if (Object.hasOwn(v, 'scope')) fail('record_scope'); }
  else { if (!Object.hasOwn(v, 'scope')) fail('record_scope'); c.scope(v.scope, [...p, 'scope']); }
  if (Object.hasOwn(v, 'issuedAt')) c.time(v.issuedAt);
  const pr = v.provenance, pp = [...p, 'provenance'];
  c.object(pr, ['mode', 'source', 'material', 'coverage', 'gaps'], ['eventAt', 'observedAt']);
  c.one(pr.mode, ['declaration', 'observation', 'capability-return', 'import']);
  c.fact(pr.source, [...pp, 'source'], x => c.identifier(x)); c.list(pr.material, [...pp, 'material'], (x, q) => c.anyRef(x, q));
  c.dataRefs(pr.coverage, [...pp, 'coverage']); c.names(pr.gaps, [...pp, 'gaps'], true);
  for (const key of ['eventAt', 'observedAt']) if (Object.hasOwn(pr, key)) c.time(pr[key]);
  c.extensions(v, p);
  const b = v.body, q = [...p, 'body'];
  const refs = (key, type, set = false, min = 0) => c.refs(b[key], [...q, key], type, set, min);
  const data = (key, set = false) => c.dataRefs(b[key], [...q, key], set);
  const rules = key => c.rules(b[key], [...q, key]);
  switch (v.type) {
    case 'work':
      c.object(b, ['framing', 'actMappings', 'appRules', 'policies', 'capabilities'], ['previous']);
      data('framing'); rules('actMappings'); rules('appRules'); c.object(b.policies, ['authority', 'retention', 'disclosure']);
      for (const k of ['authority', 'retention', 'disclosure']) c.rule(b.policies[k], [...q, 'policies', k]);
      caps(c, b.capabilities, [...q, 'capabilities']); if (Object.hasOwn(b, 'previous')) c.ref(b.previous, [...q, 'previous'], 'work'); break;
    case 'participant':
      c.object(b, ['party', 'kind', 'roles', 'controllers', 'description']); c.identifier(b.party);
      c.one(b.kind, ['human', 'agent', 'collective', 'service', 'unknown']); c.names(b.roles, [...q, 'roles'], true);
      c.fact(b.controllers, [...q, 'controllers'], (x, r) => c.list(x, r, y => c.identifier(y))); data('description'); break;
    case 'act':
      c.object(b, ['contributor', 'mapping', 'expression', 'basis', 'transmitter']);
      c.ref(b.contributor, [...q, 'contributor'], 'participant'); c.rule(b.mapping, [...q, 'mapping']);
      c.fact(b.basis, [...q, 'basis'], (x, r) => c.refs(x, r, 'context'));
      c.fact(b.transmitter, [...q, 'transmitter'], x => c.identifier(x));
      c.fact(b.expression, [...q, 'expression'], (e, r) => {
        c.one(e?.form, ['material', 'choice', 'refusal']);
        if (e.form === 'material') { c.object(e, ['form', 'items']); c.list(e.items, [...r, 'items'], (x, t) => c.data(x, t), { min: 1 }); }
        if (e.form === 'refusal') { c.object(e, ['form'], ['statement']); if (Object.hasOwn(e, 'statement')) c.data(e.statement, [...r, 'statement']); }
        if (e.form === 'choice') {
          c.object(e, ['form', 'options', 'selected']); c.list(e.options, [...r, 'options'], (x, t) => c.anyRef(x, t), { min: 1 });
          c.list(e.selected, [...r, 'selected'], (x, t) => { c.uint(x, t); if (x >= e.options.length) fail('choice_index'); }, { set: true });
        }
      }); break;
    case 'relation':
      c.object(b, ['vocabulary', 'members', 'agreement']); c.rule(b.vocabulary, [...q, 'vocabulary']);
      c.list(b.members, [...q, 'members'], (x, r) => { c.object(x, ['role', 'subject']); c.name(x.role); c.anyRef(x.subject, [...r, 'subject']); }, { min: 1 });
      c.fact(b.agreement, [...q, 'agreement'], (x, r) => c.refs(x, r, 'report')); break;
    case 'context':
      c.object(b, ['offered', 'conditions', 'gaps']); rules('conditions'); c.names(b.gaps, [...q, 'gaps']);
      c.list(b.offered, [...q, 'offered'], (x, r) => {
        c.one(x?.mode, ['exact', 'locator']); c.object(x, x.mode === 'exact' ? ['mode', 'subject'] : ['mode', 'uri']);
        x.mode === 'exact' ? c.anyRef(x.subject, [...r, 'subject']) : c.identifier(x.uri);
      }); break;
    case 'grant':
      c.object(b, ['principal', 'rights', 'attributions', 'policy', 'notBefore', 'notAfter', 'delegation']);
      c.identifier(b.principal); c.names(b.rights, [...q, 'rights'], true); refs('attributions', 'participant'); c.rule(b.policy, [...q, 'policy']);
      c.time(b.notBefore); c.time(b.notAfter); if (b.notAfter <= b.notBefore) fail('grant_time');
      c.fact(b.delegation, [...q, 'delegation'], (x, r) => c.ref(x, r, 'grant')); break;
    case 'receipt': {
      if (!v.issuedAt) fail('receipt_time');
      c.object(b, ['operation', 'requestDigest', 'outcome', 'recorded', 'retained', 'authority', 'reason', 'retention']);
      checkOperation(b.operation, c, [...q, 'operation']); if (!equal(v.scope, b.operation.scope)) fail('receipt_scope');
      c.fact(b.requestDigest, [...q, 'requestDigest'], x => c.digest(x, DOMAINS.request));
      c.one(b.outcome, ['committed', 'rejected', 'cancelled']);
      if ((b.outcome !== 'cancelled' && b.requestDigest.state !== 'known')
        || (b.outcome === 'cancelled' && !['known', 'not-recorded'].includes(b.requestDigest.state))) fail('receipt_request');
      refs('recorded', undefined, true); data('retained', true);
      if (b.outcome !== 'committed' && (b.recorded.length || b.retained.length)) fail('receipt_batch');
      if (b.recorded.some(x => sameIdentity(x, v))) fail('receipt_self');
      c.object(b.authority, ['principal', 'grants', 'policy']); c.identifier(b.authority.principal);
      c.refs(b.authority.grants, [...q, 'authority', 'grants'], 'grant'); c.rule(b.authority.policy, [...q, 'authority', 'policy']);
      if (b.outcome !== 'cancelled' && b.authority.principal !== b.operation.caller) fail('receipt_caller');
      c.fact(b.reason, [...q, 'reason'], x => c.name(x));
      c.object(b.retention, ['policy', 'recordsUntil', 'recoveryUntil'], ['dataUntil']); c.rule(b.retention.policy, [...q, 'retention', 'policy']);
      if (b.retained.length && !Object.hasOwn(b.retention, 'dataUntil')) fail('receipt_data_time');
      for (const k of ['recordsUntil', 'recoveryUntil', 'dataUntil']) if (Object.hasOwn(b.retention, k)) {
        c.time(b.retention[k]); if (b.retention[k] < v.issuedAt) fail('receipt_time');
      }
      break;
    }
    case 'report':
      c.object(b, ['category', 'subjects', 'actor', 'rule', 'outcome', 'outputs', 'basis', 'supersedes']);
      c.one(b.category, ['validation', 'acceptance', 'selection', 'transformation', 'rendering', 'display', 'availability', 'authority', 'correction']);
      c.list(b.subjects, [...q, 'subjects'], (x, r) => c.anyRef(x, r), { min: 1 });
      c.fact(b.actor, [...q, 'actor'], x => c.identifier(x)); c.fact(b.rule, [...q, 'rule'], (x, r) => c.rule(x, r)); c.name(b.outcome);
      for (const k of ['outputs', 'basis']) c.list(b[k], [...q, k], (x, r) => c.anyRef(x, r)); refs('supersedes', 'report'); break;
    case 'claim':
      c.object(b, ['predicate', 'subjects', 'conditions']); c.rule(b.predicate, [...q, 'predicate']);
      c.list(b.subjects, [...q, 'subjects'], (x, r) => c.anyRef(x, r), { min: 1 }); c.list(b.conditions, [...q, 'conditions'], (x, r) => c.anyRef(x, r)); break;
    case 'assessment':
      c.object(b, ['claim', 'method', 'trust', 'material', 'performed', 'omitted', 'processing', 'finding']);
      c.ref(b.claim, [...q, 'claim'], 'claim'); c.rule(b.method, [...q, 'method']); c.rule(b.trust, [...q, 'trust']);
      c.list(b.material, [...q, 'material'], (x, r) => c.anyRef(x, r)); c.names(b.performed, [...q, 'performed']); c.names(b.omitted, [...q, 'omitted']);
      c.one(b.processing, ['complete', 'partial', 'unsupported', 'unavailable', 'invalid', 'failed']); c.one(b.finding, ['supported', 'contradicted', 'not-established']);
      if (b.processing !== 'complete' && b.finding !== 'not-established') fail('assessment_finding'); break;
    case 'manifest':
      c.object(b, ['records', 'data', 'coverage', 'omissions', 'availability', 'policy']);
      refs('records', undefined, true); for (const k of ['data', 'coverage', 'omissions']) data(k, k === 'data'); refs('availability', 'report'); c.rule(b.policy, [...q, 'policy']);
      if (b.records.some(x => sameIdentity(x, v))) fail('manifest_self'); break;
    case 'binding':
      c.object(b, ['serialization', 'capabilities', 'recordTypes', 'encodings', 'extensions', 'transport', 'authentication', 'authorization', 'persistence', 'recovery', 'retention', 'inspection', 'limits']);
      if (b.serialization !== 'aap-json-jcs-draft1') fail('serialization'); caps(c, b.capabilities, [...q, 'capabilities']);
      c.list(b.recordTypes, [...q, 'recordTypes'], x => c.one(x, TYPES), { set: true }); c.list(b.encodings, [...q, 'encodings'], x => c.one(x, ['utf8', 'base64']), { set: true, min: 1 });
      c.list(b.extensions, [...q, 'extensions'], x => c.identifier(x), { set: true });
      for (const k of ['transport', 'authentication', 'authorization', 'persistence', 'recovery', 'retention', 'inspection']) c.rule(b[k], [...q, k]);
      c.object(b.limits, Object.keys(LIMITS)); for (const k of Object.keys(LIMITS)) c.uint(b.limits[k], [...q, 'limits', k]);
      if (b.capabilities.includes('exchange') && (!b.capabilities.includes('record') || !['work', 'binding', 'receipt'].every(x => b.recordTypes.includes(x))
        || ['maxEnvelopeBytes', 'maxRecordBytes', 'maxRequestBytes', 'maxRecordsPerRequest', 'maxWriteValidityMs', 'maxRecoveryMs'].some(k => !b.limits[k]))) fail('binding_consistency');
      break;
  }
  if (canonicalBytes(v).length > LIMITS.maxRecordBytes) fail('record_byte_limit');
}

export function checkRequest(v, c, p) {
  c.object(v, ['schema', 'binding', 'action', 'operation', 'caller', 'scope', 'basis', 'grants', 'validUntil', 'preconditions', 'records', 'materials'], ['extensions', 'requires']);
  if (v.schema !== 'aap.request.draft1' || v.action !== 'record') fail('schema');
  c.ref(v.binding, [...p, 'binding'], 'binding'); c.object(v.operation, ['epoch', 'id']); c.name(v.operation.epoch); c.name(v.operation.id);
  c.identifier(v.caller); c.scope(v.scope, [...p, 'scope']); if (v.scope.occurrence !== undefined) fail('unsupported_occurrence');
  c.fact(v.basis, [...p, 'basis'], (x, q) => c.refs(x, q, 'context')); c.refs(v.grants, [...p, 'grants'], 'grant', true); c.time(v.validUntil);
  c.refs(v.preconditions, [...p, 'preconditions'], undefined, true); if (v.preconditions.length) fail('unsupported_precondition');
  c.list(v.records, [...p, 'records'], (x, q) => { checkRecord(x, c, q); if (x.scope && !equal(x.scope, v.scope)) fail('batch_scope'); }, { max: LIMITS.maxRecordsPerRequest });
  if (new Set(v.records.map(x => canonicalize(x.identity))).size !== v.records.length) fail('batch_identity');
  c.list(v.materials, [...p, 'materials'], (x, q) => c.data(x, q), { set: true, max: LIMITS.maxMaterialsPerRequest });
  if (v.materials.some(x => x.length > LIMITS.maxDataBytes) || v.materials.reduce((n, x) => n + BigInt(x.length), 0n) > BigInt(LIMITS.maxTotalDataBytes)) fail('material_byte_limit');
  c.extensions(v, p); if (canonicalBytes(v).length > LIMITS.maxRequestBytes) fail('request_byte_limit');
}
export function checkStatus(v, c, p) {
  c.object(v, ['schema', 'operation', 'issuer', 'observedAt', 'state', 'receipt', 'reason']);
  if (v.schema !== 'aap.status.draft1') fail('schema'); checkOperation(v.operation, c, [...p, 'operation']); c.identifier(v.issuer); c.time(v.observedAt);
  c.one(v.state, ['terminal', 'pending', 'not-seen', 'unavailable', 'unknown']);
  c.fact(v.receipt, [...p, 'receipt'], (x, q) => c.ref(x, q, 'receipt')); c.fact(v.reason, [...p, 'reason'], x => c.name(x));
  if ((v.state === 'terminal') !== (v.receipt.state === 'known')) fail('status_receipt');
}
export function checkQuery(v, c, p) {
  c.object(v, ['schema', 'action', 'caller', 'target', 'grants', 'validUntil']); if (v.schema !== 'aap.query.draft1') fail('schema');
  c.one(v.action, ['status', 'cancel']); c.identifier(v.caller); checkOperation(v.target, c, [...p, 'target']); c.refs(v.grants, [...p, 'grants'], 'grant', true); c.time(v.validUntil);
}
export const validateRecord = input => parseValidated(input, checkRecord, LIMITS.maxRecordBytes);
export const validateRequest = input => parseValidated(input, checkRequest, LIMITS.maxRequestBytes);
export const validateQuery = input => parseValidated(input, checkQuery);
export const validateStatus = input => parseValidated(input, checkStatus);
export function payloadReference(input, mediaType, max = LIMITS.maxDataBytes) {
  if (!Number.isSafeInteger(max) || max < 0 || max > LIMITS.maxEnvelopeBytes) fail('byte_limit');
  const b = octets(input, max); new Reader(new Map()).text(mediaType, 255); if (!mediaType.length) fail('media_label');
  return freeze({ kind: 'data', digest: { algorithm: 'sha-256', domain: DOMAINS.payload, value: sha(b) }, length: b.length, mediaType });
}
export function recordReference(input) {
  const v = validateRecord(input);
  return freeze({ kind: 'record', type: v.type, identity: v.identity, digest: { algorithm: 'sha-256', domain: DOMAINS.record,
    value: sha(Buffer.concat([Buffer.from('AAP\0record\0draft1\0'), canonicalBytes(v)])) } });
}
export function requestDigest(input) {
  const v = validateRequest(input); return freeze({ algorithm: 'sha-256', domain: DOMAINS.request,
    value: sha(Buffer.concat([Buffer.from('AAP\0request\0draft1\0'), canonicalBytes(v)])) });
}
export function checkCarrier(v, c, p) {
  c.object(v, ['ref', 'encoding', 'value']); c.data(v.ref, [...p, 'ref']); c.one(v.encoding, ['utf8', 'base64']); c.text(v.value);
  let b;
  if (v.encoding === 'utf8') b = octets(v.value);
  else {
    if (Buffer.byteLength(v.value) > 131072 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(v.value)) fail('base64');
    b = Buffer.from(v.value, 'base64'); if (b.toString('base64') !== v.value) fail('base64');
  }
  if (b.length > LIMITS.maxDataBytes || !equal(payloadReference(b, v.ref.mediaType), v.ref)) fail('carrier_mismatch');
}
export const validateCarrier = input => parseValidated(input, checkCarrier);
export const operationKey = request => ({ binding: request.binding, caller: request.caller, scope: request.scope,
  epoch: request.operation.epoch, id: request.operation.id, action: 'record' });
