// Pure admission of supplied plans, decisions and source values. No live ports.
import { LIMITS, parseValidated, checkRecord, checkCarrier, equal, recordReference, canonicalBytes, fail }
  from '../../mcp-participation/src/core.mjs';
import { validateToolResult } from '../../mcp-participation/src/binding.mjs';

export const PLAN_SCHEMA = 'aap.sdk.selected-snapshot-plan.draft1';
export const OWNER_READ_SCHEMA = 'aap.sdk.owner-snapshot-read.draft1';
export const PERMISSION_SCHEMA = 'aap.sdk.collection-permission.draft1';
export const COLLECTOR_LIMITS = Object.freeze({ maxReads: 26, maxWindowMs: 60000,
  maxResponseBytes: LIMITS.maxEnvelopeBytes, maxTotalResponseBytes: 4194304 });
export class CollectionStop extends Error {
  constructor(reason) { super(reason); this.name = 'CollectionStop'; this.reason = reason; }
}
export const stop = reason => { throw new CollectionStop(reason); };
export const reference = record => recordReference(JSON.stringify(record));

export function validateCollectionPlan(input) {
  return parseValidated(input, (v, c, p) => {
    c.object(v, ['schema', 'source', 'work', 'manifest', 'recipient', 'deadline', 'omissions'], ['selection']);
    c.one(v.schema, [PLAN_SCHEMA]); c.one(v.source, ['owner', 'inspection']);
    c.ref(v.work, [...p, 'work'], 'work'); c.ref(v.manifest, [...p, 'manifest'], 'manifest');
    c.identifier(v.recipient); c.time(v.deadline);
    if (v.source === 'inspection') c.name(v.selection);
    else if (Object.hasOwn(v, 'selection')) fail('collection_plan');
    c.list(v.omissions, [...p, 'omissions'], (g, path) => {
      c.object(g, ['subject', 'reason']); c.anyRef(g.subject, [...path, 'subject']);
      // Do not fetch an inspection page to discover that a record was withheld.
      // Unselected record dependencies remain the assembler's inert gaps.
      if (g.subject.kind !== 'data') fail('collection_plan');
      c.one(g.reason, ['not-included', 'unavailable', 'withheld', 'unsupported']);
    }, { max: 128 });
    const subjects = v.omissions.map(g => canonicalBytes(g.subject).toString('utf8'));
    if (new Set(subjects).size !== subjects.length) fail('collection_plan');
  });
}

export function admitPermission(input) {
  return parseValidated(input, (v, c) => {
    c.one(v?.state, ['allow', 'deny', 'unavailable', 'unsupported']);
    c.object(v, v.state === 'allow' ? ['schema', 'state', 'principal', 'source', 'notAfter'] : ['schema', 'state']);
    c.one(v.schema, [PERMISSION_SCHEMA]);
    if (v.state === 'allow') { c.identifier(v.principal); c.identifier(v.source); c.time(v.notAfter); }
  });
}

export function admitOwnerRead(input, expected) {
  const v = parseValidated(input, (v, c, p) => {
    c.object(v, ['schema', 'subject', 'state', 'notAfter', 'value']);
    c.one(v.schema, [OWNER_READ_SCHEMA]); c.anyRef(v.subject, [...p, 'subject']);
    c.one(v.state, ['available', 'unavailable']); c.fact(v.notAfter, [...p, 'notAfter'], x => c.time(x));
    if (v.state === 'unavailable') { if (v.value !== null) fail('source_shape'); }
    else {
      if (v.notAfter.state !== 'known') fail('source_expiry');
      if (v.subject.kind === 'record') checkRecord(v.value, c, [...p, 'value']);
      else checkCarrier(v.value, c, [...p, 'value']);
    }
  });
  if (!equal(v.subject, expected)) stop('selection-changed');
  if (v.state === 'available') {
    const actual = expected.kind === 'record' ? reference(v.value) : v.value.ref;
    if (!equal(actual, expected)) stop('integrity-mismatch');
    if (expected.kind === 'data' && v.value.encoding !== 'utf8') stop('unsupported-source');
  }
  return v;
}

export function admitInspectionRead(input, kind) {
  const v = validateToolResult('inspect_process', input);
  if (v.processing === 'denied') stop('access-stopped');
  if (v.processing === 'unsupported') stop('unsupported-source');
  if (v.processing !== 'completed') stop('read-unresolved');
  if (v.value.kind !== kind) stop('selection-changed');
  return v.value;
}

export function checkManifest(manifest, plan) {
  if (manifest.type !== 'manifest' || !equal(reference(manifest), plan.manifest)
    || !equal(manifest.scope.work, plan.work)) stop('selection-changed');
  if (Object.hasOwn(manifest.scope, 'occurrence')) stop('unsupported-source');
  if (manifest.body.records.length > 16 || manifest.body.data.length > 8) stop('limit-exceeded');
}

export function checkPage(page, plan, index) {
  checkManifest(page.manifest, plan);
  const count = page.manifest.body.records.length, expected = page.manifest.body.records[index];
  if (page.carriers.length || page.projection.encoding !== 'utf8'
    || page.records.length !== (count ? 1 : 0) || (count && !equal(reference(page.records[0]), expected))) stop('selection-changed');
  if (index + 1 < count ? page.nextCursor.state !== 'known' : page.nextCursor.state !== 'not-recorded') stop('selection-changed');
}
