// Injected orchestration only. No native source, timer, authentication or I/O.
import { parseValidated, octets, canonicalBytes, payloadReference, equal, freeze }
  from '../../mcp-participation/src/core.mjs';
import { assembleParticipationAccount, ACCOUNT_SCHEMA } from '../../participation-account/src/index.mjs';
import { validateCollectionPlan, admitPermission, admitOwnerRead, admitInspectionRead,
  checkManifest, checkPage, CollectionStop, stop, COLLECTOR_LIMITS } from './contracts.mjs';
const j = JSON.stringify;
const STOP_REASONS = new Set(['invalid-plan', 'access-stopped', 'source-unavailable', 'read-unresolved',
  'selection-changed', 'integrity-mismatch', 'unsupported-source', 'limit-exceeded', 'clock-invalid', 'cancelled']);
function stoppedReason(error) {
  try {
    const value = Object.getOwnPropertyDescriptor(error, 'reason')?.value;
    return error instanceof CollectionStop && STOP_REASONS.has(value) ? value : 'read-unresolved';
  } catch { return 'read-unresolved'; }
}

function sourceMethods(source, names) {
  if (!source || Object.keys(source).length !== names.length) stop('invalid-plan');
  return Object.fromEntries(names.map(name => {
    const method = Object.getOwnPropertyDescriptor(source, name)?.value;
    if (typeof method !== 'function') stop('invalid-plan'); return [name, method];
  }));
}
function admissionFailure(error) {
  if (error instanceof CollectionStop) throw error;
  if (['byte_limit', 'record_byte_limit', 'array_limit', 'depth_limit', 'text_limit', 'carrier_total'].includes(error?.code)) stop('limit-exceeded');
  if (error?.code === 'carrier_mismatch') stop('integrity-mismatch');
  if (['unsupported_extension', 'unsupported_encoding'].includes(error?.code)) stop('unsupported-source');
  stop('read-unresolved');
}

export async function collectSelectedSnapshot(input, ports) {
  let reads = 0, pending = 'none', records = [], carriers = [], gaps = [], result;
  try {
    let plan;
    try { plan = validateCollectionPlan(input); } catch { stop('invalid-plan'); }
    const { source, gate, clock, signal } = ports ?? {};
    if (typeof gate !== 'function' || typeof clock !== 'function' || !signal
      || typeof signal.addEventListener !== 'function' || typeof signal.removeEventListener !== 'function') stop('invalid-plan');
    const methods = sourceMethods(source, plan.source === 'owner' ? ['readRecord', 'readData'] : ['readPage', 'readData']);
    let lastTime, startTime, sourceExpiry = Infinity, permissionExpiry = Infinity, context, totalBytes = 0;
    const tick = () => {
      if (signal.aborted) stop('cancelled');
      let text;
      try {
        text = clock(); if (typeof text !== 'string') stop('clock-invalid');
        parseValidated(j(text), (v, c) => c.time(v));
      } catch { stop('clock-invalid'); }
      const time = Date.parse(text);
      if (lastTime !== undefined && time < lastTime) stop('clock-invalid');
      lastTime = time; startTime ??= time;
      if (time >= Math.min(Date.parse(plan.deadline), startTime + COLLECTOR_LIMITS.maxWindowMs)) stop('limit-exceeded');
      if (time >= Math.min(sourceExpiry, permissionExpiry)) stop('access-stopped');
      return text;
    };
    const awaitPort = (kind, invoke, failure) => new Promise((resolve, reject) => {
      if (signal.aborted) { reject(new CollectionStop('cancelled')); return; }
      let done = false; pending = kind;
      const abort = () => { if (!done) { done = true; signal.removeEventListener('abort', abort); reject(new CollectionStop('cancelled')); } };
      signal.addEventListener('abort', abort, { once: true });
      const settle = (value, rejected) => {
        pending = 'none'; signal.removeEventListener('abort', abort);
        if (done) return; done = true;
        if (rejected) reject(new CollectionStop(failure)); else resolve(value);
      };
      try { Promise.resolve(invoke()).then(v => settle(v, false), () => settle(null, true)); }
      catch { settle(null, true); }
    });
    const guard = async (phase, subject = null, unavailable = false, account = null) => {
      tick();
      const request = freeze({ phase, plan, subject, unavailable, account });
      const raw = await awaitPort('gate', () => gate(request, signal), 'access-stopped');
      tick();
      let decision;
      try { decision = admitPermission(raw); } catch { stop('access-stopped'); }
      if (decision.state === 'unsupported') stop('unsupported-source');
      if (decision.state !== 'allow') stop('access-stopped');
      const next = [decision.principal, decision.source];
      if (context && !equal(context, next)) stop('access-stopped'); context ??= next;
      permissionExpiry = Math.min(permissionExpiry, Date.parse(decision.notAfter)); tick();
    };
    const read = async (method, query, subject, kind) => {
      await guard('before-read', subject);
      tick(); if (reads >= COLLECTOR_LIMITS.maxReads) stop('limit-exceeded'); reads++;
      const raw = await awaitPort('read', () => methods[method](j(query), signal), 'read-unresolved');
      tick();
      let value;
      try {
        const bytes = octets(raw, COLLECTOR_LIMITS.maxResponseBytes);
        totalBytes += bytes.length; if (totalBytes > COLLECTOR_LIMITS.maxTotalResponseBytes) stop('limit-exceeded');
        value = plan.source === 'owner' ? admitOwnerRead(bytes, subject) : admitInspectionRead(bytes, kind);
      } catch (error) { admissionFailure(error); }
      if (plan.source === 'owner' && value.state === 'available') {
        sourceExpiry = Math.min(sourceExpiry, Date.parse(value.notAfter.value)); tick();
      }
      await guard('after-read', subject, plan.source === 'owner' && value.state === 'unavailable');
      return value;
    };
    await guard('begin');
    const first = plan.source === 'owner'
      ? await read('readRecord', plan.manifest, plan.manifest)
      : await read('readPage', { selection: plan.selection }, plan.manifest, 'page');
    if (plan.source === 'owner' && first.state !== 'available') stop('source-unavailable');
    const manifest = plan.source === 'owner' ? first.value : first.manifest;
    checkManifest(manifest, plan);
    if (plan.omissions.some(g => manifest.body.records.some(r => equal(r, g.subject)))) stop('invalid-plan');
    gaps = [...plan.omissions];
    if (plan.source === 'owner') {
      for (const target of manifest.body.records) {
        const v = await read('readRecord', target, target);
        if (v.state === 'unavailable') gaps.push({ subject: target, reason: 'unavailable' }); else records.push(v.value);
      }
    } else {
      let page = first; const seen = new Set();
      for (let index = 0; index < Math.max(1, manifest.body.records.length); index++) {
        if (index) {
          const cursor = page.nextCursor.value;
          if (seen.has(cursor)) stop('selection-changed'); seen.add(cursor);
          page = await read('readPage', { selection: plan.selection, cursor }, plan.manifest, 'page');
        }
        checkPage(page, plan, index); records.push(...page.records);
      }
    }
    for (const target of manifest.body.data) {
      if (gaps.some(g => equal(g.subject, target))) continue;
      const v = await read('readData', plan.source === 'owner' ? target : { selection: plan.selection, data: target }, target, 'data');
      if (plan.source === 'owner') {
        if (v.state === 'unavailable') gaps.push({ subject: target, reason: 'unavailable' }); else carriers.push(v.value);
      } else {
        if (!equal(v.manifest, plan.manifest) || !equal(v.carrier.ref, target)) stop('selection-changed');
        if (v.carrier.encoding !== 'utf8') stop('unsupported-source'); carriers.push(v.carrier);
      }
    }
    if (plan.source === 'owner') {
      const final = await read('readRecord', plan.manifest, plan.manifest);
      if (final.state !== 'available') stop('source-unavailable'); checkManifest(final.value, plan);
    } else {
      const final = await read('readPage', { selection: plan.selection }, plan.manifest, 'page'); checkPage(final, plan, 0);
    }
    const asOf = tick();
    try { result = assembleParticipationAccount(j({ schema: ACCOUNT_SCHEMA, asOf, manifest, records, carriers, gaps })); }
    catch (error) {
      const reasons = { limit_exceeded: 'limit-exceeded', integrity_mismatch: 'integrity-mismatch',
        unsupported_profile: 'unsupported-source', selection_mismatch: 'selection-changed' };
      stop(reasons[error?.code] ?? 'read-unresolved');
    }
    const accountRef = payloadReference(canonicalBytes(result.account), 'application/json', COLLECTOR_LIMITS.maxResponseBytes);
    await guard('release', plan.manifest, false, accountRef); tick();
    return freeze({ state: 'collected', reads, pending: 'none', result });
  } catch (error) {
    return freeze({ state: 'stopped', reads, pending, reason: stoppedReason(error) });
  } finally { records = []; carriers = []; gaps = []; result = undefined; }
}
