// Supplied JSON only. No owner, persistence, current clock, rendering or I/O.
import { LIMITS, ParticipationContractError, parseValidated, checkRecord, checkCarrier,
  recordReference, payloadReference, canonicalBytes, equal, freeze, fail as coreFail }
  from '../../mcp-participation/src/core.mjs';
import { references } from './references.mjs';

export const ACCOUNT_SCHEMA = 'aap.sdk.participation-account.draft1';
export const VIEW_SCHEMA = 'aap.sdk.participation-view.draft1';
export const ACCOUNT_LIMITS = freeze({ ...LIMITS, maxRecords: 16, maxData: 8, maxGaps: 128,
  maxLinks: LIMITS.maxArrayItems, maxProjectionBytes: LIMITS.maxDataBytes });
export const TRUST_LIMITS = freeze(['selected-account-not-complete-history', 'model-origin-unverified',
  'issuer-authority-unverified', 'report-truth-unverified', 'display-not-independently-verified']);
const REASONS = ['not-included', 'unavailable', 'withheld', 'unsupported'];
const j = JSON.stringify;
const key = value => canonicalBytes(value).toString('utf8');
const identityKey = reference => key(reference.identity);
const ref = record => recordReference(j(record));

export class ParticipationAccountError extends Error {
  constructor(code) { super(code); this.name = 'ParticipationAccountError'; this.code = code; }
}
const fail = code => { throw new ParticipationAccountError(code); };
const LIMIT_ERRORS = new Set(['byte_limit', 'text_limit', 'array_limit', 'depth_limit', 'record_byte_limit', 'account_data_limit']);
function translate(error) {
  if (error instanceof ParticipationAccountError) throw error;
  if (error instanceof ParticipationContractError) {
    if (LIMIT_ERRORS.has(error.code)) fail('limit_exceeded');
    if (error.code === 'carrier_mismatch') fail('integrity_mismatch');
    if (error.code === 'unsupported_extension' || error.code === 'account_encoding') fail('unsupported_profile');
  }
  fail('invalid_admission');
}

function envelope(input) {
  return parseValidated(input, (v, c, p) => {
    c.object(v, ['schema', 'asOf', 'manifest', 'records', 'carriers', 'gaps']);
    c.one(v.schema, [ACCOUNT_SCHEMA]); c.time(v.asOf);
    checkRecord(v.manifest, c, [...p, 'manifest']); c.one(v.manifest.type, ['manifest']);
    if (v.manifest.body.records.length > ACCOUNT_LIMITS.maxRecords || v.manifest.body.data.length > ACCOUNT_LIMITS.maxData)
      coreFail('array_limit');
    c.list(v.records, [...p, 'records'], (r, path) => checkRecord(r, c, path), { max: ACCOUNT_LIMITS.maxRecords });
    let bytes = 0n;
    c.list(v.carriers, [...p, 'carriers'], (carrier, path) => {
      if (carrier?.encoding === 'base64') coreFail('account_encoding');
      checkCarrier(carrier, c, path);
      bytes += BigInt(carrier.ref.length);
      if (bytes > BigInt(LIMITS.maxTotalDataBytes)) coreFail('account_data_limit');
    }, { max: ACCOUNT_LIMITS.maxData });
    c.list(v.gaps, [...p, 'gaps'], (g, path) => {
      c.object(g, ['subject', 'reason']); c.anyRef(g.subject, [...path, 'subject']); c.one(g.reason, REASONS);
    }, { max: ACCOUNT_LIMITS.maxGaps });
  });
}

function selected(account) {
  const m = account.manifest, root = m.scope.work;
  if (Object.hasOwn(m.scope, 'occurrence')) fail('unsupported_profile');
  const sources = new Map(), identities = new Map(), wanted = new Map(), carriers = new Map(), gaps = new Map();
  const manifestRef = ref(m), refs = new Map([[m, manifestRef]]);
  const addIdentity = reference => {
    const id = identityKey(reference), previous = identities.get(id);
    if (previous && !equal(previous, reference)) fail('integrity_mismatch');
    identities.set(id, reference);
  };
  addIdentity(manifestRef);
  for (const r of m.body.records) { addIdentity(r); wanted.set(key(r), r); }
  for (const r of m.body.data) wanted.set(key(r), r);
  for (const record of account.records) {
    const r = ref(record), k = key(r);
    addIdentity(r);
    if (!wanted.has(k) || sources.has(k)) fail('selection_mismatch');
    if (record.scope && (Object.hasOwn(record.scope, 'occurrence') || !equal(record.scope.work, root))) fail('unsupported_profile');
    if (record.type === 'work' && !equal(r, root)) fail('unsupported_profile');
    sources.set(k, record); refs.set(record, r);
  }
  for (const carrier of account.carriers) {
    const k = key(carrier.ref);
    if (!wanted.has(k) || carriers.has(k)) fail('selection_mismatch');
    carriers.set(k, carrier);
  }
  // Schema-order, not transport arrival order. The root Manifest is not in records.
  const records = [m, ...m.body.records.map(r => sources.get(key(r))).filter(Boolean)];
  const edges = [];
  for (const record of records) for (const edge of references(record)) {
    if (edges.length >= ACCOUNT_LIMITS.maxLinks) fail('limit_exceeded');
    edges.push({ from: refs.get(record), ...edge });
  }
  const known = new Set([...wanted.keys(), ...edges.map(e => key(e.to))]);
  for (const g of account.gaps) {
    const k = key(g.subject);
    if (!known.has(k) || gaps.has(k) || sources.has(k) || carriers.has(k) || equal(g.subject, manifestRef)) fail('selection_mismatch');
    gaps.set(k, g);
  }
  for (const k of wanted.keys()) if (!sources.has(k) && !carriers.has(k) && !gaps.has(k)) fail('selection_mismatch');
  // Check all disclosed references against disclosed identities, including gaps.
  // A different digest for a supplied identity is corruption, not missing data.
  for (const e of edges) if (e.to.kind === 'record') addIdentity(e.to);
  const work = sources.get(key(root));
  if (work) for (const record of records) {
    if (record.type === 'act' && !work.body.actMappings.some(r => equal(r, record.body.mapping))) fail('integrity_mismatch');
  }
  return { records, refs, manifestRef, sources, carriers, gaps, edges, root };
}

function projection(account, selection) {
  const { records, refs, manifestRef, sources, carriers, gaps, edges, root } = selection;
  const missing = new Map(gaps), rootKey = key(manifestRef);
  const links = edges.map(({ from, to, path }) => {
    const k = key(to);
    let check;
    if (to.kind === 'record' && to.type === 'work' && !equal(to, root)) check = 'unsupported';
    else check = k === rootKey || sources.has(k) || carriers.has(k) ? 'matched' : 'unresolved';
    if (check !== 'matched' && !missing.has(k)) missing.set(k, { subject: to, reason: check === 'unsupported' ? 'unsupported' : 'not-included' });
    return { from, to, path, check };
  });
  if (missing.size > ACCOUNT_LIMITS.maxGaps) fail('limit_exceeded');
  const view = { schema: VIEW_SCHEMA, manifest: manifestRef, asOf: account.asOf,
    items: records.map(record => ({ source: refs.get(record), type: record.type, issuer: record.issuer, provenance: record.provenance })),
    links, gaps: [...missing.values()], limits: [...TRUST_LIMITS] };
  const bytes = canonicalBytes(view);
  if (bytes.length > ACCOUNT_LIMITS.maxProjectionBytes) fail('limit_exceeded');
  return { ref: payloadReference(bytes, 'application/json'), encoding: 'utf8', value: bytes.toString('utf8') };
}

export function assembleParticipationAccount(input) {
  try {
    const account = envelope(input), selection = selected(account);
    if (canonicalBytes(account).length > LIMITS.maxEnvelopeBytes) fail('limit_exceeded');
    return freeze({ account, projection: projection(account, selection) });
  } catch (error) { translate(error); }
}
