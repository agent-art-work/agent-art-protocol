// Typed, schema-ordered references only. Extension contents and locators are inert.
export function references(record) {
  const out = [], b = record.body;
  const add = (to, ...path) => out.push({ to, path });
  const list = (values, path) => values.forEach((to, i) => add(to, ...path, i));
  const rule = (value, path) => add(value.definition, ...path, 'definition');
  const rules = (values, path) => values.forEach((value, i) => rule(value, [...path, i]));
  const fact = (value, path, read) => { if (value.state === 'known') read(value.value, [...path, 'value']); };
  if (record.scope) add(record.scope.work, 'scope', 'work');
  list(record.provenance.material, ['provenance', 'material']);
  list(record.provenance.coverage, ['provenance', 'coverage']);
  switch (record.type) {
    case 'work':
      list(b.framing, ['body', 'framing']); rules(b.actMappings, ['body', 'actMappings']);
      rules(b.appRules, ['body', 'appRules']);
      for (const k of ['authority', 'retention', 'disclosure']) rule(b.policies[k], ['body', 'policies', k]);
      if (b.previous) add(b.previous, 'body', 'previous');
      break;
    case 'participant': list(b.description, ['body', 'description']); break;
    case 'act':
      add(b.contributor, 'body', 'contributor'); rule(b.mapping, ['body', 'mapping']);
      fact(b.expression, ['body', 'expression'], (e, path) => {
        if (e.form === 'material') list(e.items, [...path, 'items']);
        if (e.form === 'choice') list(e.options, [...path, 'options']);
        if (e.form === 'refusal' && e.statement) add(e.statement, ...path, 'statement');
      });
      fact(b.basis, ['body', 'basis'], list); break;
    case 'relation':
      rule(b.vocabulary, ['body', 'vocabulary']);
      b.members.forEach((m, i) => add(m.subject, 'body', 'members', i, 'subject'));
      fact(b.agreement, ['body', 'agreement'], list); break;
    case 'context':
      b.offered.forEach((o, i) => { if (o.mode === 'exact') add(o.subject, 'body', 'offered', i, 'subject'); });
      rules(b.conditions, ['body', 'conditions']); break;
    case 'grant':
      list(b.attributions, ['body', 'attributions']); rule(b.policy, ['body', 'policy']);
      fact(b.delegation, ['body', 'delegation'], (v, path) => add(v, ...path)); break;
    case 'receipt':
      add(b.operation.binding, 'body', 'operation', 'binding');
      add(b.operation.scope.work, 'body', 'operation', 'scope', 'work');
      list(b.recorded, ['body', 'recorded']); list(b.retained, ['body', 'retained']);
      list(b.authority.grants, ['body', 'authority', 'grants']);
      rule(b.authority.policy, ['body', 'authority', 'policy']);
      rule(b.retention.policy, ['body', 'retention', 'policy']); break;
    case 'report':
      list(b.subjects, ['body', 'subjects']); fact(b.rule, ['body', 'rule'], rule);
      for (const k of ['outputs', 'basis', 'supersedes']) list(b[k], ['body', k]);
      break;
    case 'claim':
      rule(b.predicate, ['body', 'predicate']);
      for (const k of ['subjects', 'conditions']) list(b[k], ['body', k]);
      break;
    case 'assessment':
      add(b.claim, 'body', 'claim');
      for (const k of ['method', 'trust']) rule(b[k], ['body', k]);
      list(b.material, ['body', 'material']); break;
    case 'manifest':
      for (const k of ['records', 'data', 'coverage', 'omissions', 'availability']) list(b[k], ['body', k]);
      rule(b.policy, ['body', 'policy']); break;
    case 'binding':
      for (const k of ['transport', 'authentication', 'authorization', 'persistence', 'recovery', 'retention', 'inspection'])
        rule(b[k], ['body', k]);
      break;
  }
  return out;
}
