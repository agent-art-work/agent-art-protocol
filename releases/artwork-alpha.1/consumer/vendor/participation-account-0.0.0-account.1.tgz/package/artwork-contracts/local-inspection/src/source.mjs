// Trusted local object adaptation only. No owner/SQLite, network or timer import.
import { parseValidated, equal, recordReference, freeze } from '../../mcp-participation/src/core.mjs';
import { validateToolResult } from '../../mcp-participation/src/binding.mjs';

export const SCOPE_SCHEMA = 'aap.sdk.local-inspection-scope.draft1';
const j = JSON.stringify;
const failure = (processing, reason) => j({ schema: 'aap.sdk.mcp-result.draft1', processing,
  reason: { state: 'known', value: reason }, value: null });
const unavailable = () => failure('unavailable', 'operation-unavailable');
const denied = () => failure('denied', 'access-denied');
const invalid = () => failure('invalid', 'request-conflict');
const unsupported = () => failure('unsupported', 'unsupported-profile');
const DENIALS = new Set(['principal_denied', 'principal_changed', 'wrong_principal', 'work_not_enrolled',
  'inspection_denied', 'authentication_expired', 'denied_authentication', 'denied_grant', 'denied_consent', 'denied_work_scope']);
function nativeFailure(error) {
  let code;
  try { code = Object.getOwnPropertyDescriptor(error, 'code')?.value; } catch {}
  if (DENIALS.has(code)) return denied();
  if (code === 'inspection_cursor') return invalid();
  return unavailable();
}

export class LocalInspectionSourceError extends Error {
  constructor() { super('invalid-configuration'); this.name = 'LocalInspectionSourceError'; this.code = 'invalid-configuration'; }
}

export function createLocalInspectionSource(options) {
  let scope, inspect;
  try {
    const { scopeJson } = options ?? {};
    inspect = options?.inspect;
    if (typeof inspect !== 'function') throw new LocalInspectionSourceError();
    scope = parseValidated(scopeJson, (v, c, p) => {
      c.object(v, ['schema', 'work', 'manifest', 'selection']); c.one(v.schema, [SCOPE_SCHEMA]);
      c.ref(v.work, [...p, 'work'], 'work'); c.ref(v.manifest, [...p, 'manifest'], 'manifest'); c.name(v.selection);
    });
  } catch { throw new LocalInspectionSourceError(); }
  const read = (kind, raw, signal) => {
    if (signal?.aborted) return denied();
    let query;
    try {
      query = parseValidated(raw, (v, c, p) => {
        c.object(v, kind === 'page' ? ['selection'] : ['selection', 'data'], kind === 'page' ? ['cursor'] : []);
        c.name(v.selection);
        if (kind === 'page' && Object.hasOwn(v, 'cursor')) c.name(v.cursor);
        if (kind === 'data') c.data(v.data, [...p, 'data']);
      });
    } catch { return invalid(); }
    if (query.selection !== scope.selection) return denied();
    let local;
    try { local = inspect(j(query)); } catch (error) { return nativeFailure(error); }
    // The commissioned native method is synchronous. Observe a rejected Promise
    // without accepting it as native data or allowing an unhandled rejection.
    if (local instanceof Promise) {
      Promise.prototype.then.call(local, () => {}, () => {});
      return signal?.aborted ? denied() : unsupported();
    }
    if (signal?.aborted) return denied();
    try {
      if (!local || typeof local !== 'object' || Array.isArray(local)) return unavailable();
      const result = validateToolResult('inspect_process', j(local));
      if (result.processing !== 'completed') {
        if (result.processing === 'denied') return denied();
        if (result.processing === 'invalid') return invalid();
        if (result.processing === 'unsupported') return unsupported();
        return unavailable();
      }
      const value = result.value;
      if (value.kind !== kind) return invalid();
      if (kind === 'page') {
        if (!equal(recordReference(j(value.manifest)), scope.manifest)
          || !equal(value.manifest.scope, { work: scope.work })) return invalid();
        if (value.records.length > 1 || value.carriers.length || value.projection.encoding !== 'utf8') return invalid();
      } else {
        if (!equal(value.manifest, scope.manifest) || !equal(value.carrier.ref, query.data)) return invalid();
        if (value.carrier.encoding !== 'utf8') return unsupported();
      }
      return j(result);
    } catch { return unavailable(); }
  };
  return freeze({ readPage: (raw, signal) => read('page', raw, signal), readData: (raw, signal) => read('data', raw, signal) });
}
