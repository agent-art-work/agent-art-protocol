export { createLocalInspectionSource, LocalInspectionSourceError, SCOPE_SCHEMA } from './source.mjs';
