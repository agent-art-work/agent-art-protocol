export * from '../../../artwork-contracts/participation-account/src/index.mjs';
