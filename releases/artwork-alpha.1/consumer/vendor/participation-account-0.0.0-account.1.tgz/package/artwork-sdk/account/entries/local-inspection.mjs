export * from '../../../artwork-contracts/local-inspection/src/index.mjs';
