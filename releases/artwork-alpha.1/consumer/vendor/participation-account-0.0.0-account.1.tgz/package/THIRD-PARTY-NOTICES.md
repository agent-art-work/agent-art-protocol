# Bundled dependency notices

Original account companion code is MIT. Dependencies retain their included terms.

## canonicalize@5.1.0

License: Apache-2.0.

- [node_modules/canonicalize/LICENSE](node_modules/canonicalize/LICENSE)

## jsonc-parser@3.3.1

License: MIT.

- [node_modules/jsonc-parser/LICENSE.md](node_modules/jsonc-parser/LICENSE.md)
