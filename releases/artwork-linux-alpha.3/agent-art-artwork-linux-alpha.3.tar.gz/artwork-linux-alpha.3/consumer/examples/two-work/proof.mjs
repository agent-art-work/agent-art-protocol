import assert from 'node:assert/strict';
import { existsSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { test } from 'node:test';
import { isDeepStrictEqual } from 'node:util';
import { LIMITS, TYPES, payloadReference, recordReference } from '@agent-art/artwork-sdk';
import { ParticipationOwner } from '@agent-art/artwork-sdk/owner';
import { collectSelectedSnapshot, PLAN_SCHEMA, PERMISSION_SCHEMA } from '@agent-art/participation-account/collect';
import { createLocalInspectionSource, SCOPE_SCHEMA } from '@agent-art/participation-account/local-inspection';

const json = JSON.stringify;
const ref = record => recordReference(json(record));
const known = value => ({ state: 'known', value });
const exact = subject => ({ mode: 'exact', subject });
const carrier = (value, mediaType = 'text/plain') => ({
  ref: payloadReference(value, mediaType), encoding: 'utf8', value,
});
const epoch = Date.parse('2026-11-19T00:00:00.000Z');
const at = offset => new Date(epoch + offset).toISOString();
const ends = at(60_000);
const statement = carrier('I wanted the underline to feel like a loose thread.');
const glyph = '<path d="M8 4v24m0-12h16m0-12v24" fill="none" stroke="#222"/>';
const underline = '<path d="M8 29h6m2 0h4m2 0h2" fill="none" stroke="#526477"/>';
const svg = paths => carrier(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">${paths}</svg>\n`, 'image/svg+xml');
const baseline = svg(glyph);
const bInstruction = carrier('Choose the original mark or a broken underline. The prior statement is optional Context.');

function openWork(directory, label, clock, definitionText) {
  const namespace = `urn:fixture:two-work-intention:${label}`;
  const artist = `${namespace}:artist`;
  const receiver = `${namespace}:receiver`;
  const definition = carrier(definitionText);
  const rule = name => ({ id: `${namespace}:rule:${name}`, revision: 'v1', definition: definition.ref });
  const mapping = rule('expression');
  const derive = rule('derive');
  const authority = rule('authority');
  const disclosure = rule('disclosure');
  const capabilities = ['record', 'exchange', 'inspect'];
  let workRef;
  const record = (type, id, body) => ({
    schema: 'aap.record.draft1', type, identity: { namespace, id, revision: 'v1' },
    ...(!['work', 'binding'].includes(type) ? { scope: { work: workRef } } : {}),
    issuer: artist, issuedAt: clock(),
    provenance: { mode: 'declaration', source: known(artist), material: [], coverage: [], gaps: ['synthetic-fixture'] },
    body,
  });
  const work = record('work', 'work', { framing: [definition.ref], actMappings: [mapping], appRules: [derive],
    policies: { authority, retention: rule('retention'), disclosure }, capabilities });
  workRef = ref(work);
  const binding = record('binding', 'binding', {
    serialization: 'aap-json-jcs-draft1', capabilities, recordTypes: [...TYPES], encodings: ['utf8'], extensions: [],
    limits: structuredClone(LIMITS), authorization: authority,
    ...Object.fromEntries(['transport', 'authentication', 'persistence', 'recovery', 'retention', 'inspection'].map(key => [key, rule(key)])),
  });
  const setup = { work, binding, owner: artist, receiver, mappingRules: [mapping], relationRules: [], bootstrapUntil: ends,
    policy: { writeMs: 300000, recordsMs: 3600000, dataMs: 3600000, recoveryMs: 604800000, maxActive: 4, maxEntries: 20 } };
  const owner = ParticipationOwner.initialize({ directory, setupJson: json(setup), clock });

  const bind = principal => owner.bind(() => json({ verified: true, principal, notAfter: ends }));
  // The released owner enrolls Agent seats. For the importer and audience,
  // the fixture uses separate principals and exercises only selected reads.
  const enroll = name => {
    const principal = `${namespace}:principal:${name}`;
    const participant = record('participant', name, { party: `${namespace}:party:${name}`, kind: 'agent',
      roles: ['participant'], controllers: known([principal]), description: [] });
    owner.enroll(json({ principal, participant, terms: rule('fixture-enrollment'), notAfter: ends }));
    return { principal, participant, session: bind(principal) };
  };
  const manifestFor = (id, records, data) => record('manifest', id, {
    records: records.map(ref), data: data.map(item => item.ref), coverage: [], omissions: [], availability: [], policy: disclosure,
  });
  const publish = (id, reader, data) => {
    const context = record('context', id, { offered: data.map(item => exact(item.ref)), conditions: [], gaps: ['synthetic-fixture'] });
    const records = [work, reader.participant, context];
    const carriers = [definition, ...data];
    const manifest = manifestFor(`${id}-manifest`, records, carriers);
    owner.publishContext(json({ package: { work: workRef, context: ref(context), manifest, records, carriers },
      readers: [reader.principal], until: ends }));
    return context;
  };
  const select = (id, reader, records, data) => {
    const manifest = manifestFor(`${id}-manifest`, records, data);
    owner.publishInspection(json({ selection: id, manifest, readers: [reader.principal], until: ends }));
    return { id, manifest: ref(manifest) };
  };
  const collect = ({ id: selection, manifest }, reader) => collectSelectedSnapshot(json({ schema: PLAN_SCHEMA,
    source: 'inspection', work: workRef, selection, manifest, recipient: reader.principal, deadline: ends, omissions: [],
  }), { clock, signal: new AbortController().signal, source: createLocalInspectionSource({
    scopeJson: json({ schema: SCOPE_SCHEMA, work: workRef, selection, manifest }), inspect: raw => reader.session.inspect(raw),
  }), gate: () => json({ schema: PERMISSION_SCHEMA, state: 'allow', principal: reader.principal, source: artist, notAfter: ends }) });
  return { artist, receiver, work, workRef, owner, definition, derive, bind, enroll, publish, record, select, collect };
}

function capture(work, agent, id, context, item) {
  const { returnHandle, reservation } = agent.session.prepare(json({ context: ref(context), prepareId: id })).value;
  const receipt = agent.session.submit(returnHandle, json({ form: 'material', mediaType: item.ref.mediaType, text: item.value }),
    json(reservation)).value.receipt.value;
  const { record: act } = work.owner.inspectRecord(json(receipt.body.recorded[0]));
  assert.equal(receipt.body.outcome, 'committed');
  assert.equal(receipt.issuer, work.receiver);
  assert.deepEqual(receipt.body.recorded, [ref(act)]);
  assert.deepEqual(receipt.body.retained, [item.ref]);
  assert.deepEqual(act.scope, { work: work.workRef });
  assert.deepEqual(act.body.contributor, ref(agent.participant));
  assert.deepEqual(act.body.basis, known([ref(context)]));
  assert.deepEqual(work.owner.inspectData(json(item.ref)).original, Buffer.from(item.value));
  return { act, receipt };
}

function findCarrier(account, reference) {
  const item = account.carriers.find(candidate => isDeepStrictEqual(candidate.ref, reference));
  assert.ok(item, 'selected carrier is present');
  assert.deepEqual(payloadReference(item.value, item.ref.mediaType), reference);
  return item;
}

function findRecord(account, reference) {
  const record = account.records.find(candidate => isDeepStrictEqual(ref(candidate), reference));
  assert.ok(record, 'selected record matches identity, revision and digest');
  return record;
}

function describeSource(account, scope, actRef, receiptRef) {
  const work = findRecord(account, scope.sourceWork);
  const act = findRecord(account, actRef);
  const receipt = findRecord(account, receiptRef);
  const participant = findRecord(account, act.body.contributor);
  const quote = findCarrier(account, scope.statement);
  assert.deepEqual(ref(account.manifest), scope.sourceManifest);
  assert.deepEqual(act.scope, { work: ref(work) });
  assert.deepEqual(receipt.scope, act.scope);
  assert.deepEqual(participant.scope, act.scope);
  assert.equal(participant.body.kind, 'agent');
  assert.equal(receipt.body.outcome, 'committed');
  assert.deepEqual(receipt.body.recorded, [ref(act)]);
  assert.deepEqual(receipt.body.retained, [quote.ref]);
  assert.deepEqual(act.body.expression.value.items, [quote.ref]);
  return { work: ref(work), manifest: scope.sourceManifest, act: ref(act), receipt: ref(receipt),
    participant: ref(participant), recordedAt: act.issuedAt, statement: quote.ref };
}

function authorizeCopy(grant, scope, issuer, clock, code) {
  if (grant?.issuer !== issuer || !(Date.parse(clock()) < Date.parse(grant.until))
    || !isDeepStrictEqual(grant.scope, scope)) {
    throw Object.assign(new Error(code), { code });
  }
}

test('a later Work offers a separately permitted statement and records two inspectable outcomes', async () => {
  const scratch = mkdtempSync(join(process.cwd(), '.two-work-'));
  const directories = ['a', 'b'].map(label => join(scratch, label));
  let a, b, retained;
  let now = 1;
  const clock = () => at(now);

  try {
    a = openWork(directories[0], 'a', clock, 'Record an exact standalone statement of intention.');
    b = openWork(directories[1], 'b', clock, 'Keep the exact baseline or append the broken underline path under derive/v1.');
    const aAgent = a.enroll('agent');
    const importer = a.enroll('import-reader');
    const bAgent = b.enroll('agent');
    const reader = b.enroll('account-reader');
    const bBaseline = b.publish('initial-mark', bAgent, [baseline]);
    const sourceOffer = a.publish('statement-invitation', aAgent, [carrier('What did you intend the underline to feel like?')]);
    now = 10;
    const source = capture(a, aAgent, 'statement', sourceOffer, statement);
    const sourceSelection = a.select('source-statement', importer, [a.work, aAgent.participant, source.act, source.receipt],
      [a.definition, statement]);
    const scope = { sourceWork: a.workRef, sourceManifest: sourceSelection.manifest, statement: statement.ref,
      importer: importer.principal, destination: b.workRef };
    const reuse = { issuer: a.artist, scope, until: at(1000) };
    const admission = { issuer: b.artist, scope, until: at(2000) };
    const importStatement = async (exportGrant, importGrant) => {
      authorizeCopy(exportGrant, scope, a.artist, clock, 'reuse_denied');
      authorizeCopy(importGrant, scope, b.artist, clock, 'import_denied');
      const selected = await a.collect(sourceSelection, importer);
      assert.equal(selected.state, 'collected');
      const { account } = selected.result;
      const provenance = describeSource(account, scope, ref(source.act), ref(source.receipt));
      const quote = findCarrier(account, provenance.statement);
      const note = carrier(json({ use: 'optional-context', source: provenance, destination: b.workRef,
        importedBy: importer.principal, importedAt: clock() }), 'application/json');
      // Both grants are app policy. The SDK receives an ordinary B Context.
      authorizeCopy(exportGrant, scope, a.artist, clock, 'reuse_denied');
      authorizeCopy(importGrant, scope, b.artist, clock, 'import_denied');
      const offer = b.publish('prior-statement-offer', bAgent, [baseline, bInstruction, quote, note]);
      return { offer, quote, note, sourceAccount: account };
    };

    now = 20;
    const selectedA = await a.collect(sourceSelection, importer);
    assert.equal(selectedA.state, 'collected');
    assert.deepEqual(findCarrier(selectedA.result.account, statement.ref), statement);
    assert.throws(() => a.bind(bAgent.principal).inspect(json({ selection: sourceSelection.id, data: statement.ref })),
      { code: 'work_not_enrolled' });
    const deniedCopies = [
      [null, admission, 'reuse_denied'],
      [reuse, null, 'import_denied'],
      [{ ...reuse, scope: { ...scope, destination: a.workRef } }, admission, 'reuse_denied'],
      [{ ...reuse, scope: { ...scope, statement: bInstruction.ref } }, admission, 'reuse_denied'],
      [{ ...reuse, until: clock() }, admission, 'reuse_denied'],
    ];
    for (const [exportGrant, importGrant, code] of deniedCopies) {
      await assert.rejects(importStatement(exportGrant, importGrant), { code });
      assert.deepEqual(bAgent.session.readContext().value.context, ref(bBaseline));
      assert.equal(b.owner.inspectData(json(statement.ref)), null);
    }
    now = 30;
    const imported = await importStatement(reuse, admission);
    const { offer, quote, note } = imported;
    assert.deepEqual(quote, statement);
    assert.equal(offer.issuer, b.artist);

    now = 40;
    const choices = [
      { id: 'adapt', mark: 'broken-underline', use: 'adapted', note: note.ref,
        explanation: 'I turned the loose thread into a broken underline.' },
      { id: 'keep', mark: 'original', use: 'not-used' },
    ];
    const results = choices.map(({ id, ...choice }) => {
      const packet = bAgent.session.readContext().value;
      assert.deepEqual(packet.context, ref(offer));
      assert.deepEqual(packet.records.find(item => item.type === 'context').body.offered,
        [baseline, bInstruction, quote, note].map(item => exact(item.ref)));
      const input = carrier(json(choice), 'application/json');
      const captured = capture(b, bAgent, id, offer, input);
      const sourceMark = findCarrier(packet, baseline.ref);
      const returned = JSON.parse(b.owner.inspectData(json(input.ref)).original.toString('utf8'));
      const output = returned.mark === 'broken-underline'
        ? carrier(sourceMark.value.replace('</svg>', `${underline}</svg>`), 'image/svg+xml') : sourceMark;
      const report = b.record('report', `${id}-effect`, { category: 'transformation',
        subjects: [ref(captured.act), sourceMark.ref, input.ref], actor: known(b.artist), rule: known(b.derive),
        outcome: 'derived', outputs: [output.ref], basis: [ref(offer), ref(captured.act)], supersedes: [] });
      b.owner.appendAppReport(json(report), ends);
      return { ...captured, input, output, report };
    });
    const [adapted, unchanged] = results;
    assert.deepEqual(adapted.output, svg(glyph + underline));
    assert.deepEqual(unchanged.output, baseline);
    assert.notDeepEqual(adapted.output.ref, unchanged.output.ref);
    assert.notDeepEqual(ref(adapted.act), ref(unchanged.act));
    assert.notDeepEqual(ref(adapted.receipt), ref(unchanged.receipt));

    now = 50;
    b.publish('result-material', reader, [adapted.output]);
    const records = [b.work, bAgent.participant, offer, ...results.flatMap(r => [r.act, r.receipt, r.report])];
    const data = [b.definition, baseline, bInstruction, quote, note, adapted.input, unchanged.input, adapted.output];
    const selection = b.select('two-work-account', reader, records, data);
    assert.throws(() => bAgent.session.inspect(json({ selection: selection.id })), { code: 'inspection_denied' });
    for (const item of [quote, note, adapted.output]) {
      assert.throws(() => bAgent.session.inspect(json({ selection: selection.id, data: item.ref })), { code: 'inspection_denied' });
    }
    const view = await b.collect(selection, reader);
    assert.equal(view.state, 'collected');
    const { account, projection } = view.result;
    for (const item of data) assert.deepEqual(findCarrier(account, item.ref), item);
    for (const record of records) assert.deepEqual(findRecord(account, ref(record)), record);
    assert.ok(account.records.every(record => record.scope
      ? isDeepStrictEqual(record.scope.work, b.workRef) : isDeepStrictEqual(ref(record), b.workRef)));
    const selectedNote = JSON.parse(findCarrier(account, note.ref).value);
    assert.deepEqual(selectedNote, { use: 'optional-context', source: describeSource(imported.sourceAccount, scope,
      ref(source.act), ref(source.receipt)), destination: b.workRef, importedBy: importer.principal, importedAt: at(30) });
    assert.ok(selectedNote.source.recordedAt < selectedNote.importedAt);
    const declared = results.map(result => JSON.parse(findCarrier(account, result.input.ref).value));
    assert.equal(declared[0].use, 'adapted');
    assert.deepEqual(declared[0].note, note.ref);
    assert.equal(declared[1].use, 'not-used');
    assert.equal(Object.hasOwn(declared[1], 'note'), false);
    const { links, limits } = JSON.parse(projection.value);
    const linked = (from, to) => assert.ok(links.some(link => link.check === 'matched'
      && isDeepStrictEqual(link.from, ref(from)) && isDeepStrictEqual(link.to, to)));
    for (const item of [quote, note]) linked(offer, item.ref);
    for (const result of results) {
      linked(result.receipt, ref(result.act));
      linked(result.act, ref(offer));
      for (const subject of [ref(result.act), baseline.ref, result.input.ref, result.output.ref]) linked(result.report, subject);
    }
    assert.ok(limits.includes('model-origin-unverified'));
    assert.deepEqual(a.owner.inspectData(json(statement.ref)).original, Buffer.from(statement.value));
    assert.deepEqual(a.owner.inspectRecord(json(ref(source.act))).record, source.act);
    assert.deepEqual(a.owner.inspectRecord(json(ref(source.receipt))).record, source.receipt);
    retained = { source: imported.sourceAccount, laterWork: account, projection };
  } finally {
    try {
      b?.owner.close();
    } finally {
      try { a?.owner.close(); } finally { rmSync(scratch, { recursive: true, force: true }); }
    }
  }
  assert.ok(directories.every(directory => !existsSync(directory)));
  if (process.env.AAP_TWO_WORK_EVIDENCE) {
    writeFileSync(process.env.AAP_TWO_WORK_EVIDENCE, `${JSON.stringify(retained, null, 2)}\n`, { flag: 'wx', mode: 0o600 });
  }
});
